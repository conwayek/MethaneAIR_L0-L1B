from setuptools import setup

setup(name='pysplat',
      version='0.1',
      description='Utility Routines for SPLAT-VLIDORT',
      url='',
      author='Chris Chan Miller',
      author_email='cmiller@cfa.harvard.edu',
      license='MIT',
      packages=['pysplat'],
      package_data={'pysplat': ['lib/*.exe']},
      zip_safe=False)
