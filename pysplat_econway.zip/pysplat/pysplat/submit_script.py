# -*- coding: iso-8859-1 -*-

# Container for 
class slurm( object ):
    
    def __init__( self, outdir, run_name, template_infile, time=120,mem=4500,queue='serial_requeue',lib=''):
        
        import numpy as  np
        
        self.outdir   = outdir
        self.run_name = run_name
        self.template = template_infile
        self.varname = []
        self.values  = []
        self.varidx  = []
        self.out_name= []
        self.mem     = str(mem)
        self.time    = str(time)
        self.queue   = queue
        self.lib     = lib

        if(self.outdir[-1] != '/'):
            self.outdir += '/'
        
    def add_var( self, varname, values, out_name=None ):
        
        import numpy as  np
        
        self.varname.append(varname)
        self.values.append(values)
        self.varidx.append(np.arange(len(values),dtype=np.int))
        if( out_name is None ):
            self.out_name.append( [str(i).zfill(3) for i in range(len(self.values[-1]))] )
            
        else:
            self.out_name.append(out_name)
    
    def submit_job( self ):
        
        import os
        import itertools
        
        # Create list of runs
        self.create_runlist()
        
        # Create the job script
        self.create_jobscript()
        
        # Submit the job
        os.system('sbatch --array=1-'+str(self.njob)+' job_array.sbatch')
        
    def get_outpre( self ):
        
        import itertools
        
        out_var = list(itertools.product(*self.out_name))
        
        self.outpre = []
        for run in out_var:
            
            outfile = self.outdir + self.run_name + '_'
            
            for v in range(len(run)):
                
                outfile += self.varname[v] + '-'+run[v] +'_'
                
            self.outpre.append( outfile )
            
    def create_runlist( self ):
        
        import itertools
        
        # Output file names
        self.get_outpre()
        
        # Output file name
        simulation_outfile = 'simulations.list'
        
        self.runlist = list(itertools.product(*self.values))
        self.runidx  = list(itertools.product(*self.varidx))
        self.njob    = len(self.runlist)
        
        # Get number of variables
        nvar = len(self.varname)
        
        # Open file for write
        f = open(simulation_outfile, 'w')
        
        for n in range(self.njob):
          
            line = ''
            for i in range(nvar):
                line += str(self.runlist[n][i]) + ' '
            
            # Add the output file name
            line += self.outpre[n]
            
            line += '\n'
            
            # write line
            f.write( line )
        
        # Close file
        f.close()
        
    def create_jobscript( self ):
        
        # Create output script
        outfile = 'job_array.sbatch'
         
        # Open file for write
        f = open(outfile, 'w')
        
        # Write header
        f.write( '#!/bin/bash\n\n' )
        
        # Write slurm settings
        f.write( '#SBATCH -n 1\n'                      ) # Number of CPUs
        f.write( '#SBATCH -N 1\n'                      ) # Number of CPUs per node
        f.write( '#SBATCH -t '+self.time+'\n'          ) # Wall time maximum [min]
        f.write( '#SBATCH -p '+self.queue+'\n'         ) # Queue (partition) name
        f.write( '#SBATCH --job-name="splatRT"\n'      ) # Job Name
        f.write( '#SBATCH --mem-per-cpu='+self.mem+'\n') # Memory in MB
        f.write( '#SBATCH -o logs/slurm_%A_%a.out\n'   ) # Output log
        f.write( '#SBATCH -e logs/slurm_%A_%a.err\n\n' ) # Error log
        
        # Set libraries
        f.write('# set user defined libraries \n')
        f.write('export LD_LIBRARY_PATH='+self.lib+':${LD_LIBRARY_PATH} \n\n')

        # Read the appropriate script line
        f.write('# Read list of parameters\n')
        f.write('line=`awk "NR==${SLURM_ARRAY_TASK_ID}" simulations.list`\n\n')
        
        # Read the variable strings
        f.write('# Read parameters for run\n')
        nvar = len(self.varname)
        for n in range( nvar ):
            line = self.varname[n] + "=`echo ${line} | awk '{print $"+str(n+1)+"}'`"
            f.write( line + '\n' )
        f.write("OutFilePre=`echo ${line} | awk '{print $"+str(nvar+1)+"}'`\n\n")
        
        # Input file name
        f.write('# Input file name\n')
        f.write('GCInpFile=inputs/input.gc.${SLURM_JOB_ID}_${SLURM_ARRAY_TASK_ID}\n\n')
        
        # Sed the input file
        f.write('# Write input file\n')
        f.write('sed -e "s=%'+self.varname[0]+'%=${'+self.varname[0]+'}=g" '    )
        for n in range(1,nvar):
            f.write('-e "s=%'+self.varname[n]+'%=${'+self.varname[n]+'}=g" ')
        f.write('-e "s=%OutFilePre%=${OutFilePre}=g " '+self.template+' > ${GCInpFile}\n\n')
        
        # Run the tool
        f.write('# Run SPlAt\n')
        f.write('./spv.exe ${GCInpFile} \n\n')
        
        # Remove input file
        f.write('# Remove input file\n')
        f.write('rm -f ${GCInpFile}')
        
        # Close file
        f.close()
    
    def clear_output_directory( self ):
        
        import os
        
        # Temporarily create a dummy directory
        os.system( 'mkdir ./empty_dir' )
        
        # Use rsync to sync with the empty directory (faster than rm)
        os.system( 'rsync -a --delete empty_dir/ ' + self.outdir )
        
        # Remove temporary empty directory
        os.system( 'rm -rf ./empty_dir' )
    
    def run_job( self ):
        
        import os
        
        # Create the run list
        self.create_runlist()
        
        # Number of variables
        nvar = len(self.varname)
        
        # Loop over jobs
        for j in range(self.njob):
            
            # Create sed command
            inpfile = 'inputs/input.gc.'+str(j)
            
            cmd = 'sed -e "s=%'+str(self.varname[0])+'%='+str(self.runlist[j][0])+'=g" '
            for n in range(1,nvar):
                cmd += '-e "s=%'+str(self.varname[n])+'%='+str(self.runlist[j][n])+'=g" '
            cmd += '-e "s=%OutFilePre%='+self.outpre[j]+'=g " '+self.template+' > ' + inpfile
            
            # Make input file
            os.system( cmd )
            
            print('=======================')
            print(str(j) +' / '+ str(self.njob))
            print('=======================')
            
            # Do Run
            os.system( './spv.exe ' + inpfile )
            
            # Remove input file
            os.system( 'rm -rf ' + inpfile )
    
    def generate_lut( self, outfile, fldname ):
        
        import numpy as  np
        from netCDF4 import Dataset
        
        # Create the run list
        self.create_runlist()
        
        # Number of variables
        nvar = len(self.varname)
        nfld = len(fldname)
        
        # Variable dimensions
        vardim = []
        for v in self.values:
            vardim.append( len(v) )
        
        # Loop over files
        fld_dim = []
        nfld_dim = []
        dim_vec = []
        dim_reshape = []
        self.data = {}
        for j in range(self.njob):
            
            if( np.mod(j,100) == 0): print(j,'/',self.njob)
            
            infile = self.outpre[j] + 'GC_upwelling_output.nc'
            
            # open file
            ncid = Dataset( infile, 'r' )
            
            # Get the dimensions
            if( j == 0 ):
                for f in range(nfld):
                    
                    # Get dimensions of field
                    dim = np.array( ncid.variables[fldname[f]][:].squeeze().shape, dtype=np.int)
                    ndim = len(dim)
                    
                    # Archive dimensions for array resizing
                    fld_dim.append( dim )
                    nfld_dim.append( ndim )
                    
                    # We need to vectorize the output
                    dim_vec.append( dim.prod() )
                    
                    # Compute dimensions for variable
                    dim_out = np.zeros( nvar+1,dtype=np.int )
                    dim_out[0:nvar] = vardim
                    dim_out[nvar]   = dim_vec[f]
                    
                    # Reshape dims
                    tmp = np.zeros( nvar+ndim,dtype=np.int )
                    tmp[0:nvar] = vardim
                    if( ndim > 0 ): tmp[nvar:nvar+ndim] = dim
                    dim_reshape.append(tmp)
                    
                    # Define output array
                    self.data[fldname[f]] = np.zeros( dim_out )
                    
            # Read data
            for f in range(nfld):
                
                # read field
                ts = np.reshape( ncid.variables[fldname[f]][:], dim_vec[f] )
                
                # Index
                self.data[fldname[f]][self.runidx[j]] = ts
                
            # Close file
            ncid.close()
        
        
        # Reshape arrays
        for f in range(nfld):
            self.data[fldname[f]] = np.reshape( self.data[fldname[f]], dim_reshape[f] )
        
        # Create LUT Output file
        # ----------------------
        self.dim_reshape = dim_reshape
        # Open output file
        ncid = Dataset( outfile, 'w' )
        
        # Get unique indices
        nc_dim = np.unique(dim_reshape)
        
        nc_dimname = []
        for n in range(len(nc_dim)):
            
            # Append dimension anem
            nc_dimname.append( 'dim' + str(n))
            
            # Create the dimension
            ncid.createDimension( nc_dimname[n], nc_dim[n] )
            
            
        
        # Write the Splat Output
        for f in range(nfld):
            
            # Match field dimensions
            fld_nc_dim = []
            for v in dim_reshape[f]:
                
                # Match index
                fld_nc_dim.append( nc_dimname[ np.where(nc_dim==v)[0][0] ] )
                
            fld_nc_dim = tuple( fld_nc_dim )
            
            
            # Create variable
            ncid.createVariable(fldname[f],self.data[fldname[f]].dtype, fld_nc_dim )
            
            # Write
            ncid.variables[fldname[f]][:] = self.data[fldname[f]][:]
            
        
        # Write the variable grid
        for v in range(nvar):
            
            n = len(self.values[v][:])
            print(n)
            
            fld_nc_dim =  nc_dimname[ np.where(nc_dim==n)[0][0] ] 
            
            print(fld_nc_dim)
            
            # Create variable
            ncid.createVariable(self.varname[v],self.values[v].dtype, fld_nc_dim )
            
            # Write
            ncid.variables[self.varname[v]][:] = self.values[v][:]
            
        
        # Close Output file
        ncid.close()
        
'''
# ==================================================================================
# Main script starts here
# ==================================================================================

# -------------------------------------------
# Settings
# -------------------------------------------
template_infile = 'templates/input_O2D.gc'
output_dir      = 'aerosol_test/'
run_name        = 'O2D_test_'

# -------------------------------------------
# Initialize input file
# -------------------------------------------
inp = input_file( output_dir, run_name, template_infile,lib='/n/home01/cmiller/lib/gnu/lib',mem=12000 )

# -------------------------------------------
# Add variables
# -------------------------------------------
inp.add_var('SZA',[0],out_name=['50'])
inp.add_var('VZA',[0],out_name=['45'])
inp.add_var('RefSpc',['../data/ReflSpectra/conifer_ASTER.dat'],\
            out_name=['conifer'])
inp.add_var('AOD',[0.0,0.5,1.0,5.0])

# -------------------------------------------
# Submit the job
# -------------------------------------------
inp.submit_job()
'''

