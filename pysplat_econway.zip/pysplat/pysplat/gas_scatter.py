# -*- coding: iso-8859-1 -*-


class rayleigh_optprop(object):

    ''' The gas scatter class contains routines for writing gas scattering optical properties
        
        To create a optical property file
          (1) Initialize file object
          (2) Add RI information (using add_ri_table or add_ri_funcpar
          (3) Add King factor information (using add_king_table or add_king_funcpar)
          (4) Write file (using write_optprop)
          
        OPTIONAL:
          Raman line parameters can be added to the file using add_raman_linepars
    '''
    
    def __init__(self,outfile):

        ''' Initialize gas scattering object with name of desired output file
            
        ARGS:
            outfile ('str'): output NetCDF file name  

        '''

        self.outfile = outfile

        # Initialize type indices for refractive index and king factor
        self.ri_type      = -1
        self.ri_ref       = ''
        self.F_type       = -1
        self.F_ref        = ''
        self.raman_type   = -1
        self.raman_ref    = ''
        self.file_written = False
        
    def add_ri_table(self,wvl,ri,std_ad,reference=''):

        ''' Add a wavelength vs ri relationship to the output file
        
        ARGS:
            wvl[w] ('numpy float'): Wavelength grid [nm]
            ri[w] ('numpy float'): Real part of refractive index 
            std_ad ('numpy float'): Reference air density corresp. to R.I. [molec/cm3]
            where the dimensions correspond to:
              w: Wavelength

        OPTIONAL ARGS:
            reference (str): Paper to cite for data

        '''

        # Check for exceptions
        if(self.file_written):
            raise Exception('Optical Property file has already been created')
        if(self.ri_type > 0):
            raise Exception('Refractive index has already been defined')
        if(len(wvl.shape) != 1):
            raise Exception('Input wavelength grid should only have 1 dimension')
        if(len(ri.shape) != 1):
            raise Exception('Input refractive index should only have 1 dimension')
        if(wvl.shape[0] != ri.shape[0]):
            raise Exception('Wavelength and refractive index dimensions are different')
        
        self.std_ad  = std_ad
        self.ri_wvl  = wvl
        self.ri      = ri
        self.ri_type = 1
        self.ri_ref  = reference
    
    def add_ri_funcpar(self,funcstr,std_ad,c=None,reference=''):
        
        ''' Add a refractive index dispersion relation with function str 
            parsed to program at runtime
        
        ARGS:
            funcstr (str): The function string (fortran-ish syntax, see notes below)
            std_ad ('numpy float'): Reference air density corresp. to R.I. [molec/cm3]
            
        OPTIONAL ARGS:
            c[n] ('numpy float'): Coefficients to pass to function
            reference (str): Paper to cite for data
        
        where the dimensions correspond to:
              n: Number of parameters in function string
              
        NOTES on funcstr syntax
            
            The RI relations can be specified symbolically via using the fparser module
            
            The RI are specified in the function string
            Let (1) wm = Wavelength in MICRONS <============================================ !!!!!!!!
                (2) ci = c[i] for i=1..n (n<=9)
            
            For example consider a typical dispersion relation parameterization for the RI
            
            n = 1 + 3.2e-2/(144.0-1/wm)
            
            This expression can be parsed to splat by setting
            
            c=None
            funcstr = '1+3.2e-2/(144.0-1.0/wm)'
            
            Alternatively you can use the optional coefficients
            
            c = [3.2e-2,144.0]
            funcstr = '1+c0/(c1-1.0/wm)'
            
            This can be more convenient if you are defining multiple species with the 
            same dispersion relationship
            
            -----------------------------
            More notes on fparser syntax
            -----------------------------
            
            Although they have to be passed as array elements of the same declared
            length (Fortran 90 restriction), the variable names can be of arbitrary
            actual length for the parser. Parsing for variables is case sensitive.

            The syntax of the function string is similar to the Fortran convention.
            Mathematical Operators recognized are +, -, *, /, ** or alternatively ^,
            whereas symbols for brackets must be ().

            The function parser recognizes the (single argument) Fortran 90 intrinsic
            functions abs, exp, log10, log, sqrt, sinh, cosh, tanh, sin, cos, tan, asin,
            acos, atan. Parsing for intrinsic functions is case INsensitive.

            Operations are evaluated in the correct order:

              ()          expressions in brackets first
              -A          unary minus (or plus)
              A**B A^B    exponentiation (A raised to the power B)
              A*B  A/B    multiplication and division
              A+B  A-B    addition and subtraction

            The function string can contain integer or real constants. To be recognized
            as explicit constants these must conform to the format

            [+|-][nnn][.nnn][e|E|d|D[+|-]nnn]

            where nnn means any number of digits. The mantissa must contain at least
            one digit before or following an optional decimal point. Valid exponent
            identifiers are 'e', 'E', 'd' or 'D'. If they appear they must be followed
            by a valid exponent!
            
        '''
        # Check for exceptions
        if(self.file_written):
            raise Exception('Optical Property file has already been created')
        if(self.ri_type > 0):
            raise Exception('Refractive index has already been defined')
        
        # Check that all parameters are in function string
        if(not c is None):
            for n in range(c):
                cpar = 'c' + str(n)
                if(cpar not in funcstr):
                    raise Exception(cpar+' is was not found in RI function string definition')
        
        # Store relations
        self.std_ad  = std_ad
        self.ri_funcstr  = funcstr
        self.ri_c = c
        self.ri_type = 2
        self.ri_ref  = reference
        
    def add_king_table(self,wvl,F,reference=''):

        ''' Add a wavelength vs ri relationship to the output file
        
        ARGS:
            wvl[w] ('numpy float'): Wavelength grid [nm]
            F[w] ('numpy float'): King factor
            where the dimensions correspond to:
              w: Wavelength

        OPTIONAL ARGS:
            reference (str): Paper to cite for data

        '''

        # Check for exceptions
        if(self.file_written):
            raise Exception('Optical Property file has already been created')
        if(self.F_type > 0):
            raise Exception('King Factor has already been defined')
        if(len(wvl.shape) != 1):
            raise Exception('Input wavelength grid should only have 1 dimension')
        if(len(F.shape) != 1):
            raise Exception('Input King Factor should only have 1 dimension')
        if(wvl.shape[0] != F.shape[0]):
            raise Exception('Wavelength and King factor dimensions are different')
        
        self.F_wvl  = wvl
        self.F      = F
        self.F_type = 1
        self.F_ref  = reference
    
    def add_king_funcpar(self,funcstr,c=None,reference=''):
        
        ''' Add a refractive index dispersion relation with function str 
            parsed to program at runtime
        
        ARGS:
            funcstr (str): The function string (fortran-ish syntax, see notes below)
            
        OPTIONAL ARGS:
            c[n] ('numpy float'): Coefficients to pass to function
            reference (str): Paper to cite for data
        
        where the dimensions correspond to:
              n: Number of parameters in function string
              
        NOTES on funcstr syntax
            
            The RI relations can be specified symbolically via using the fparser module
            
            The RI are specified in the function string
            Let (1) wm = Wavelength in MICRONS <============================================ !!!!!!!!
                (2) ci = c[i] for i=1..n
            
            For example consider a typical dispersion relation parameterization for the RI
            
            n(wm) = 1 + 3.2e-2/(144.0-1/wm)
            
            This expression can be parsed to splat by setting
            
            c=None
            funcstr = '1+3.2e-2/(144.0-1.0/wm)'
            
            Alternatively you can use the optional coefficients
            
            c = [3.2e-2,144.0]
            funcstr = '1+c0/(c1-1.0/wm)'
            
            This can be more convenient if you are defining multiple species with the 
            same dispersion relationship
            
            
            -----------------------------
            More notes on fparser syntax
            -----------------------------
            
            Although they have to be passed as array elements of the same declared
            length (Fortran 90 restriction), the variable names can be of arbitrary
            actual length for the parser. Parsing for variables is case sensitive.

            The syntax of the function string is similar to the Fortran convention.
            Mathematical Operators recognized are +, -, *, /, ** or alternatively ^,
            whereas symbols for brackets must be ().

            The function parser recognizes the (single argument) Fortran 90 intrinsic
            functions abs, exp, log10, log, sqrt, sinh, cosh, tanh, sin, cos, tan, asin,
            acos, atan. Parsing for intrinsic functions is case INsensitive.

            Operations are evaluated in the correct order:

              ()          expressions in brackets first
              -A          unary minus (or plus)
              A**B A^B    exponentiation (A raised to the power B)
              A*B  A/B    multiplication and division
              A+B  A-B    addition and subtraction

            The function string can contain integer or real constants. To be recognized
            as explicit constants these must conform to the format

            [+|-][nnn][.nnn][e|E|d|D[+|-]nnn]

            where nnn means any number of digits. The mantissa must contain at least
            one digit before or following an optional decimal point. Valid exponent
            identifiers are 'e', 'E', 'd' or 'D'. If they appear they must be followed
            by a valid exponent!
        
        '''
        
        # Check for exceptions
        if(self.file_written):
            raise Exception('Optical Property file has already been created')
        if(self.ri_type > 0):
            raise Exception('Refractive index has already been defined')
        
        # Check that all parameters are in function string
        if(not c is None):
            for n in range(c):
                cpar = 'c' + str(n)
                if(cpar not in funcstr):
                    raise Exception(cpar+' is was not found in King factor function string definition')
        
        
        # Store relations
        self.F_funcstr  = funcstr
        self.F_c = c
        self.F_type = 2
        self.F_ref  = reference

    def add_raman_linepars(self,Q_funcstr,p_Q,p_L,dwvl_L,rho_PT,reference=''):

        ''' Add line parameters to simulate Rotational Raman Scattering

        ARGS:
          Q_funcstr (str): function string for evaluate term in partition function sum (fortran-ish syntax, see notes below)
          p_Q[n,p] (numpy float): Parameters to pass to Q summing over all states 
          p_L[l,p] (numpy float): Parameters to pass to Q for individual Raman transitions
          dwvl_L[l] (numpy float): Wavelength transitions for the lines
          rho_PT[l] (numpy float): Placzek-Teller Coefficients for the lines
        
        OPT ARGS:
          reference (str): Optional reference to include for metadata purposes

          The dimensions are
            n: Total number of terms in the partition sum
            l: Total number of Raman transitions
            p: Number of parameters in partition sum function
        
        The gas scattering code uses Q_funcstr combined with p_Q and p_L to compute the population fractions of the energy states (f_N)
        The RI/King Factor relations are used to compute the anisotropy of polarization (gamma)
        The cross sections for the transition from state l0 (wavenumber sigma) to l xs[l0,l] are computed as
          xs[l] = 256/27*pi^5*f_N*rho_pT*gamma^2*sigma^4
        
        NOTES on funcstr syntax
            
            The Q(T) relations can be specified symbolically via using the fparser module
            
            

            The RI are specified in the function string
            Let (1) T = Temperature [K]
                (2) pi = p_Q[i] for i=1..n
            
            E.g. consider the following for the Jth rotational line with 2J+1 degenerate states,
            with the transition occuring at wavelength sigma
            The individual term in the partition function is

            q(i) = (2*J+1)*exp(c2/T*sig)
            
            To implement the function string we pass the following
              funcstr = '(2.0*p1+1)*EXP(p2/T)'
              where p1 = J
                    p2 = c2*sig
            
            The code will compute Q(T) as sum q_i for i=1..n
            For line l the code will them use the same function string to compute the population fraction
            
            -----------------------------
            More notes on fparser syntax
            -----------------------------
            
            Although they have to be passed as array elements of the same declared
            length (Fortran 90 restriction), the variable names can be of arbitrary
            actual length for the parser. Parsing for variables is case sensitive.

            The syntax of the function string is similar to the Fortran convention.
            Mathematical Operators recognized are +, -, *, /, ** or alternatively ^,
            whereas symbols for brackets must be ().

            The function parser recognizes the (single argument) Fortran 90 intrinsic
            functions abs, exp, log10, log, sqrt, sinh, cosh, tanh, sin, cos, tan, asin,
            acos, atan. Parsing for intrinsic functions is case INsensitive.

            Operations are evaluated in the correct order:

              ()          expressions in brackets first
              -A          unary minus (or plus)
              A**B A^B    exponentiation (A raised to the power B)
              A*B  A/B    multiplication and division
              A+B  A-B    addition and subtraction

            The function string can contain integer or real constants. To be recognized
            as explicit constants these must conform to the format

            [+|-][nnn][.nnn][e|E|d|D[+|-]nnn]

            where nnn means any number of digits. The mantissa must contain at least
            one digit before or following an optional decimal point. Valid exponent
            identifiers are 'e', 'E', 'd' or 'D'. If they appear they must be followed
            by a valid exponent!
        

        '''
        

        # Check for exceptions
        if(self.file_written):
            raise Exception('Optical Property file has already been created')
        if(self.raman_type > 0):
            raise Exception('Refractive index has already been defined')
        
        

        # # Check that all parameters are in function string
        # if(not c is None):
        #     for n in range(c):
        #         cpar = 'p' + str(n)
        #         if(cpar not in funcstr):
        #             raise Exception(cpar+' is was not found in King factor function string definition')

        # Set Raman input type
        self.raman_type = 1
        
        # Store relations
        self.Q_funcstr  = Q_funcstr
        self.p_Q = p_Q
        self.p_L = p_L
        self.dwvl_L = dwvl_L
        self.rho_PT = rho_PT
        self.raman_ref = reference


        pass
        
    def write_optprop(self):
        
        ''' Finish writing optical properties in netcdf file
            
        '''
        
        from netCDF4 import Dataset, stringtochar
        import numpy as np

        # Check if everything is set
        if(self.ri_type <= 0):
            raise Exception('Cannot write: Still need to set Ref. Index')
        if(self.F_type <= 0):
            raise Exception('Cannot write: Still need to set King Factor')

        # Open optical property file
        ncid = Dataset(self.outfile,'w')
        
        # Define Dimensions
        ncid.createDimension('o',1)
        ncid.createDimension('str_dim', 1)

        # RI LUT
        if(self.ri_type == 1):
            ncid.createDimension('w_r',self.ri_wvl.shape[0])
        # RI Function String
        elif(self.ri_type == 2):
            nchar = len(self.ri_funcstr) ; fmt_r = 'S'+str(nchar)
            ncid.createDimension('nchar_r',nchar)
            funcstr_ri = stringtochar(np.array([self.ri_funcstr], fmt_r))
            if(self.ri_c is None):
                nc_ri = 0
            else:
                nc_ri = len(self.ri_c)
                ncid.createDimension('c_r',nc_ri)
        else:
            raise Exception('self.ri_type outside valid range')
        
        # King Factor LUT
        if(self.F_type == 1):
            ncid.createDimension('w_k',self.F_wvl.shape[0])
        # King Factor Function String
        elif(self.F_type == 2):
            nchar = len(self.F_funcstr) ; fmt_F = 'S'+str(nchar)
            ncid.createDimension('nchar_F',nchar)
            funcstr_F = stringtochar(np.array([self.F_funcstr], fmt_F))
            if(self.ri_c is None):
                nc_F = 0
            else:
                nc_F = len(self.F_c)
                ncid.createDimension('c_F',nc_F)

            if(not self.F_c is None):
                ncid.createDimension('c_F',len(self.F_c))
        else:
            raise Exception('self.F_type outside valid range')
        
        # Create Variables for refractive index
        nc_ritype = ncid.createVariable('RI_TypeIndex',np.int16,('o'))
        nc_ad = ncid.createVariable('RefAirDensity',np.float64,('o'))
        nc_ritype[:] = self.ri_type
        nc_ad[:] = self.std_ad
        if(self.ri_type == 1):
            nc_wvl = ncid.createVariable('RI_Wavelength',np.float64,('w_r')) ; nc_wvl[:] = self.ri_wvl
            nc_ri = ncid.createVariable('RI_Value',np.float64,('w_r')) ; nc_ri[:] = self.ri
        elif(self.ri_type == 2):
            ncid.createVariable('RI_nCoeff',np.int16,('o'))
            ncid.variables['RI_nCoeff'][:] = nc_ri
            if(nc_ri > 0):
                v = ncid.createVariable('RI_Coeff',np.float64,('c_r')) ; v[:] = self.ri_c
            nc_ri = ncid.createVariable('RI_FuncStr','S1',('nchar_r')) ; nc_ri[:] = funcstr_ri
            nc_ri.funcstr = self.ri_funcstr
        else:
            raise Exception('self.ri_type outside valid range')
        nc_ri.reference = self.ri_ref


        # Create Variables for the King Correction Factor
        nc_Ftype = ncid.createVariable('FTypeIndex',np.int16,('o'))
        nc_Ftype[:] = self.F_type
        if(self.F_type == 1):
            nc_wvl = ncid.createVariable('F_Wavelength',np.float64,('w_F')) ; nc_wvl[:] = self.F_wvl
            nc_F = ncid.createVariable('F_Value',np.float64,('w_F')) ; nc_F[:] = self.F
        elif(self.F_type == 2):
            ncid.createVariable('F_nCoeff',np.int16,('o'))
            ncid.variables['F_nCoeff'][:] = nc_F
            if(nc_F > 0):
                v = ncid.createVariable('F_Coeff',np.float64,('c_F')) ; v[:] = self.F_c
            nc_F = ncid.createVariable('F_FuncStr','S1',('nchar_F')) ; nc_F[:] = funcstr_F
            nc_F.funcstr = self.F_funcstr
        else:
            raise Exception('self.F_type outside valid range')
        nc_F.reference = self.F_ref

        # Check for optional Raman 
        if(self.raman_type > 0):
            
            v = ncid.createVariable('RamanTypeIndex',np.int16,('o'))
            v[:] = self.raman_type
            if(self.raman_type == 1):
                ncid.createDimension('Qn',self.p_Q.shape[0])
                ncid.createDimension('Qp',self.p_Q.shape[1])
                ncid.createDimension('Ql',self.dwvl_L.shape[0])

                # Write variables
                v = ncid.createVariable('par_Qtot',np.float64,('Qn','Qp'))
                v[:] = self.p_Q
                v = ncid.createVariable('par_Qline',np.float64,('Ql','Qp'))
                v[:] = self.p_L
                v = ncid.createVariable('DeltaWavenumber',np.float64,('Ql'))
                v[:] = self.dwvl_L
                v.reference = self.raman_ref
                v = ncid.createVariable('PlaczekTellerCoeff',np.float64,('Ql'))
                v[:] = self.rho_PT

                # write the function string
                nchar = len(self.Q_funcstr) ; fmt_Q = 'S'+str(nchar)
                ncid.createDimension('nchar_Q',nchar)
                funcstr_Q = stringtochar(np.array([self.Q_funcstr], fmt_Q))
                nc_Q = ncid.createVariable('Q_FuncStr','S1',('nchar_Q')) ; nc_Q[:] = funcstr_Q
                nc_Q.funcstr = self.Q_funcstr
            else:
                raise Exception('self.raman_type outside valid range')
                
        # Close optical property file
        ncid.close()
        