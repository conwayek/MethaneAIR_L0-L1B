def write_sif_spec(outfile,wvl,sif_rad):

    ''' Write spectrum to be used for SIF scaling. Must contain overlap with 734nm

        ARGS:
          outfile (str): Ouput file path
          wvl[w] (numpy float): Array of wavelength [nm]
          sif_rad[w] (numpy float): SIF Radiance [**]

        ** SIF units dont matter - routine normalizes them to 1.0 @ 734nm

    '''

    import numpy as np 
    from netCDF4 import Dataset

    # Remove unit dimensions
    wvl_out = wvl.squeeze()
    sif_rad_out = sif_rad.squeeze()

    # Check inputs
    if(len(wvl.shape) != 1): 
        raise Exception('wavelength dimensions (='+str(len(wvl.shape))+') incorrect. Must be 1')
    if(wvl.shape[0] != sif_rad.shape[0]):
        tmpstr = '('+str(wvl.shape[0]) + ' and ' + str(sif_rad.shape[0])+' respectively)'
        raise Exception('Wavelength/SIF radiance sizes must be equal')
    if(wvl.min() > 734.0 or wvl.max() < 734.0):
        raise Exception('Wavelength window must cover 734 nm')
    
    
    # Rescale spectrum to 1.0nm at 734nm
    rad_734nm = np.interp(734.0,wvl_out,sif_rad_out)
    sif_rad_out = sif_rad_out/rad_734nm

    # Open file
    d = Dataset(outfile,'w')

    # Define dimensions
    d.createDimension('w',len(wvl))
    d.createDimension('o',1)
    
    # Write variables
    v = d.createVariable('SIF_Type_Index',np.int16,('o')) ; v[:] = 1
    v = d.createVariable('Wavelength',np.float,('w')) ; v[:] = wvl_out
    v = d.createVariable('SIF_Radiance',np.float,('w')) ; v[:] = sif_rad_out

    # Close file
    d.close()