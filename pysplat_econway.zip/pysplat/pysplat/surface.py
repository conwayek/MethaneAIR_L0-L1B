

# -*- coding: iso-8859-1 -*-

class fa_brdf(object):
    
    '''
    The fa_brdf class produces a BRDF climatology suitable for use with the 
    Factor analysis hyperspectral interpolation routine
    
    '''
    
    def __init__(self,basedir,lon,lat, wvl, rsr,climatology=False):
        
        ''' Initialize the fa_brdf class type for generating the FA-BRDF climatology
        
        
        ARGS:
            basedir: The base directory name for the climatology
            lon[x] ('numpy float'): Longitude midpoints [degrees]
            lat[x] ('numpy float'): Latitude midpoints [degrees]
            wvl[w] ('numpy float'): Wavelength grid for instrument relative response function
            rsr[w,b] ('numpy float'): Relative response function for imager
        OPTIONAL:
            climatology: Flag that SPLAT interprets to ignore year when doing time interpolation
            
            where the dimensions are
                x - Longitude
                y - Latitude
                w - Wavelength
                b - Band
            
            
        '''
        import numpy as np
        from pyhdf import SD
        from netCDF4 import Dataset
        import os

        # Store dimensions
        self.imx = lon.shape[0] ; self.lon = lon
        self.jmx = lat.shape[0] ; self.lat = lat
        self.kmx = 3 # Kernel number
        
        # Save the wavelength grid information
        self.wmx = wvl.shape[0] ; self.wvl = wvl
        self.bmx = rsr.shape[1] ; self.rsr = rsr
        
        # Initialize time variable
        self.tmx = 0
        self.time = np.array([])
        
        # Save climatology option
        self.climatology = climatology
        
        # Create base directory if it has not been
        if(not os.path.exists(basedir)):
            os.makedirs(basedir)
        
        # Save base directory
        self.basedir = basedir
        
        # To hold geographic extents of valid data for each snapshot
        self.lat_min = np.array([])
        self.lat_max = np.array([])
        
    def check_brdf_dim(self,brdf):
        
        ''' Makes sure input BRDF array is the correct dimension
            
            
            ARGS:
                brdf[x,y,b]: brdf arrray input to add_brdf_snapshot
           
        '''
        
        pass
    
    def check_lat_lim(self,brdf,valid_range=[0.0,1.0]):
        
        ''' Checks the lower and upper limits where brdf has data
            
            
            ARGS:
                brdf[x,y,b]: brdf arrray input to add_brdf_snapshot
            RETURNS:
                minlat: Minimum latitude where there is data
                maxlat: Maximum latitude where there is data
        '''
        
        import numpy as np

        # Get the max indices at every latitutde
        ts = brdf.max(axis=0) ; ts = ts.max(axis=1)
        idv = ts > 0

        # Get the bounds
        minlat = np.min(self.lat[idv])
        maxlat = np.max(self.lat[idv])
        
        return minlat,maxlat
       

    def get_hdf_sds_dim(self,sds):
        
        ''' Get the dimensions from a pyhdf SDS object
            
            ARGS:
                SDS: The pyhdf SDS object
            
            RETURNS:
                outdim: A list of dimensions associated with the data field of SDS
        '''

        # Read the dimensions
        ndim = len( sds.dimensions() )
    
        # Read the dimensions
        outdim = []
        for n in range(ndim):
            outdim.append(sds.dim(n).length())
        
        return outdim
        
    def add_brdf_snapshot(self,brdf_iso,brdf_vol,brdf_geo,time):
        
        ''' Add a time sample to the climatology
            
            ARGS:
                brdf_iso[x,y,b] ('numpy float'): Isotropic BRDF Kernel amplitude 
                brdf_vol[x,y,b] ('numpy float'): Volumetric (RossThick) BRDF Kernel amplitude 
                brdf_geo[x,y,b] ('numpy float'): Geometric (LiSparse) BRDF Kernel amplitude 
                time: time of snapshot (GEOS Tau time - hours since 1/1/1985 00:00 UTC)
                
                where the dimensions are
                x - Longitude
                y - Latitude
                b - Band
                
                Note that the time of the added snapshot must be greater than those of previous 
                snapshots added to the climatology

                Missing data is interpretted for brdf_iso < 0.0
                
        '''
        
        import numpy as np
        from netCDF4 import Dataset

        # Check the brdf dimensions
        self.check_brdf_dim(brdf_iso)
        self.check_brdf_dim(brdf_vol)
        self.check_brdf_dim(brdf_geo)
        
        # Check that time is ascending
        if(any(t >= time for t in self.time)):
            raise Exception('Snapshots must ascend in time (this one does not)')
        
        # Increment time
        self.tmx += 1 ; self.time = np.append(self.time,time)
        
        # Determine the max/min latitude for sample with valid data
        minlat,maxlat = self.check_lat_lim(brdf_iso,valid_range=[0.0,1.0e3])
        self.lat_min = np.append(self.lat_min,minlat)
        self.lat_max = np.append(self.lat_max,maxlat)

        fill_value = -32767
        # Write the output files
        for b in range(self.bmx):
            
            # Output file name
            outfile = self.basedir + 'BRDF_Band' + str(b+1) + '_Time' + str(self.tmx) + '.nc'
            
            # Kernels
            f_iso = np.array( np.round( brdf_iso[:,:,b].squeeze()*1000.0 ),dtype=np.int16).T
            f_vol = np.array( np.round( brdf_vol[:,:,b].squeeze()*1000.0 ),dtype=np.int16).T
            f_geo = np.array( np.round( brdf_geo[:,:,b].squeeze()*1000.0 ),dtype=np.int16).T
            
            # Insert fill values
            f_iso[f_iso<0] = fill_value
            f_vol[f_vol<0] = fill_value
            f_geo[f_geo<0] = fill_value
            
            # Create file
            ncid = Dataset(outfile,'w')
            
            # Ensure filling is on
            ncid.set_fill_on()

            # Define dimensions
            ncid.createDimension('x',self.imx)
            ncid.createDimension('y',self.jmx)
            
            # Create variables
            ncid.createVariable('f_iso',np.int16,('y','x'),fill_value=fill_value,zlib=True)
            ncid.createVariable('f_vol',np.int16,('y','x'),fill_value=fill_value,zlib=True)
            ncid.createVariable('f_geo',np.int16,('y','x'),fill_value=fill_value,zlib=True)
            
            # Write variables
            ncid.variables['f_iso'][:] = f_iso[:]
            ncid.variables['f_vol'][:] = f_vol[:]
            ncid.variables['f_geo'][:] = f_geo[:]
            
            # Close file
            ncid.close()
    
    def add_brdf_snapshot_mcd43gfcmg(self,ncid,time,bands=[1,2,3,4]):
        
        ''' Add a time sample to the climatology from the MODIS MCD43 Gap Filled Climate modeling grid product
            
            ARGS:
                ncid (netCDF4 Dataset Class):


                brdf_iso[b] ('pyhdf SDS class'): HDF Field corresponding to Isotropic BRDF Kernel amplitude
                brdf_vol[b] ('pyhdf SDS class'): HDF Field corresponding to Volumetric (RossThick) BRDF Kernel amplitude (hd)
                brdf_geo[b] ('pyhdf SDS class'): HDF Field corresponding to Geometric (LiSparse) BRDF Kernel amplitude 
                time: time of snapshot (GEOS Tau time - hours since 1/1/1985 00:00 UTC)
                
                where the dimensions are
                b - Band
                
                Note that the time of the added snapshot must be greater than those of previous 
                snapshots added to the climatology
                
        '''
        
        
        pass
        
    def finish_write(self):
        
        from netCDF4 import Dataset
        import numpy as np

        # Open information file
        ncid = Dataset(self.basedir+'brdf_grid_info.nc','w')
        
        # Create dimensions
        ncid.createDimension('x',self.imx)
        ncid.createDimension('y',self.jmx)
        ncid.createDimension('t',self.tmx)
        ncid.createDimension('w',self.wmx)
        ncid.createDimension('b',self.bmx)
        ncid.createDimension('o',1)
        
        ncid.createVariable('lon'    ,np.float64,('x'))
        ncid.createVariable('lat'    ,np.float64,('y'))
        ncid.createVariable('lat_min',np.float64,('t'))
        ncid.createVariable('lat_max',np.float64,('t'))
        ncid.createVariable('time'   ,np.float64,('t'))
        ncid.createVariable('wvl'    ,np.float64,('w'))
        ncid.createVariable('rsr'    ,np.float64,('b','w'))
        ncid.createVariable('is_clim',np.int16,('o'))
        
        # Write variables
        ncid.variables['lon'    ][:] = self.lon
        ncid.variables['lat'    ][:] = self.lat
        ncid.variables['lat_min'][:] = self.lat_min
        ncid.variables['lat_max'][:] = self.lat_max
        ncid.variables['time'   ][:] = self.time
        ncid.variables['wvl'    ][:] = self.wvl
        ncid.variables['rsr'    ][:] = self.rsr.T
        
        if(self.climatology):
            ncid.variables['is_clim'][:] = 1
        else:
            ncid.variables['is_clim'][:] = 0
        
        # Close file
        ncid.close()

def kernel_to_snapshot(outfile_pre,lon,lat,time,brdf_iso,brdf_vol,brdf_geo):

    ''' Write a snapshot of the BRDF climatology to be combined later

        ARGS:
          outfile_pre (str): Output file string (full output name = <outfile_pre>_Band<b>.nc)
          lon[x] ('numpy float'): Longitude grid [deg]
          lat[y] ('numpy float'): Latitude grid [deg]
          time ('float'): Time of snapshot [GEOS Tau Format - hrs. since 1/1/1985 00:00:00 UTC]
          brdf_iso[x,y,b] ('numpy float'): Isotropic BRDF Kernel amplitude 
          brdf_vol[x,y,b] ('numpy float'): Volumetric (RossThick) BRDF Kernel amplitude 
          brdf_geo[x,y,b] ('numpy float'): Geometric (LiSparse) BRDF Kernel amplitude 
                
          where the dimensions are
                x - Longitude
                y - Latitude
                b - Band

    '''

    import numpy as np
    from netCDF4 import Dataset

    # Get dimensions
    imx = lon.shape[0] ; jmx = lat.shape[0] ; bmx = brdf_iso.shape[2]

    # Fill value
    fill_value = -32767

    # Write the output files
    for b in range(bmx):
            
        # Output file name
        outfile = outfile_pre + '_Band'+str(b+1)+'.nc'
        
        # Kernels
        f_iso = np.array( np.round( brdf_iso[:,:,b].squeeze()*1000.0 ),dtype=np.int16)
        f_vol = np.array( np.round( brdf_vol[:,:,b].squeeze()*1000.0 ),dtype=np.int16)
        f_geo = np.array( np.round( brdf_geo[:,:,b].squeeze()*1000.0 ),dtype=np.int16)
            
        # Insert fill values
        f_iso[f_iso<0] = fill_value
        f_vol[f_vol<0] = fill_value
        f_geo[f_geo<0] = fill_value
        
        # Write the snapshot
        band_kernel_to_snapshot(outfile_pre,lon,lat,time,b+1,f_iso,f_vol,f_geo)
        
def band_kernel_to_snapshot(outfile_pre,lon,lat,time,band,f_iso,f_vol,f_geo):

    ''' Write a snapshot of the BRDF climatology to be combined later

        ARGS:
          outfile_pre (str): Output file string (full output name = <outfile_pre>_Band<b>.nc)
          lon[x] ('numpy float'): Longitude grid [deg]
          lat[y] ('numpy float'): Latitude grid [deg]
          time ('float'): Time of snapshot [GEOS Tau Format - hrs. since 1/1/1985 00:00:00 UTC]
          band (int): Band index (starting at 1)
          f_iso[x,y] ('numpy int'): Isotropic BRDF Kernel amplitude *1000
          f_vol[x,y] ('numpy int'): Volumetric (RossThick) BRDF Kernel amplitude *1000
          f_geo[x,y] ('numpy int'): Geometric (LiSparse) BRDF Kernel amplitude *1000 

          where the dimensions are
                x - Longitude
                y - Latitude

    '''

    import numpy as np
    from netCDF4 import Dataset

    # Get dimensions
    imx = lon.shape[0] ; jmx = lat.shape[0]

    # Determine the max/min latitude for sample with valid data
    ts = f_iso.max(axis=0)
    idv = ts > 0
    minlat = np.min(lat[idv])
    maxlat = np.max(lat[idv])

    # Fill value    
    fill_value = -32767

    # Output file name
    outfile = outfile_pre + '_Band'+str(band)+'.nc'
        
    # Create file
    ncid = Dataset(outfile,'w')
            
    # Ensure filling is on
    ncid.set_fill_on()

    # Define dimensions
    ncid.createDimension('x',imx)
    ncid.createDimension('y',jmx)
    ncid.createDimension('o',1)

    # Create variables
    ncid.createVariable('f_iso',np.int16,('y','x'),fill_value=fill_value,zlib=True)
    ncid.createVariable('f_vol',np.int16,('y','x'),fill_value=fill_value,zlib=True)
    ncid.createVariable('f_geo',np.int16,('y','x'),fill_value=fill_value,zlib=True)
            
    # Write variables
    ncid.variables['f_iso'][:] = f_iso.T
    ncid.variables['f_vol'][:] = f_vol.T
    ncid.variables['f_geo'][:] = f_geo.T
            
    # Save additional metadata needed to combine snapshots
    v = ncid.createVariable('lon',np.float,('x')) ; v[:] = lon
    v = ncid.createVariable('lat',np.float,('y')) ; v[:] = lat
    v = ncid.createVariable('time',np.float,('o')) ; v[:] = time
    v = ncid.createVariable('band_index',np.int16,('o')) ; v[:] = band+1
    v = ncid.createVariable('lat_min',np.float,('o')) ; v[:] = minlat
    v = ncid.createVariable('lat_max',np.float,('o')) ; v[:] = maxlat

    # Close file
    ncid.close()

def mcd43gf_05cmg_snapshots(indir,outdir,replace=False):

    ''' Convert MCD43GF v006 0.05deg CMG product to a set of snapshots

        ARGS:
          indir (str): Base path with operational files
          outdir (str): Output to put converted snapshots
          
    '''

    import os
    import numpy as np
    from fnmatch import fnmatch
    from netCDF4 import Dataset
    import pysplat
    
    # Hardcode CMG vars
    nband = 7
    
    # fill value
    fill_value = -32767
    
    # CMG Grid
    imx = 7200 ; jmx = 3600
    lon = np.arange(imx)*0.05-180.0+0.025
    lat = np.arange(jmx)*0.05-90.0+0.025

    # Check output directory exists
    if(not os.path.exists(outdir)):
        os.makedirs(outdir)

    # Find operational files in directory
    for root, _, files in os.walk(indir):
        for test_file in files:

            # Example file - MCD43C1.A2018175.006.2018186220321.hdf  
            if(fnmatch(test_file,'MCD43C1.*.hdf')):
                
                # Determine input files
                fpre,_ = os.path.splitext(test_file)
                infile = os.path.join(root,test_file)
                outfile = os.path.join(outdir,fpre,'.nc')

                # Get the time
                frag = test_file.split('.')
                yyyy = frag[1][1:5]
                doy = int(frag[1][5:])
                nymd0 = int(yyyy+'0101')
                time = pysplat.time.nymd2tau(nymd0)+float(doy-1)*24.0
                ymd = pysplat.time.tau2yymmdd(time)
                nymd_str = str(ymd['Year'][0]) \
                         + str(ymd['Month'][0]).zfill(2) \
                         + str(ymd['Day'][0]).zfill(2)

                # Open operational format file
                hdf = Dataset(infile,'r')

                # Output PRE string
                outfile_pre = os.path.join(outdir,'MCD43GF_CMG_'+nymd_str)
                
                for b in range(nband):

                    # Band String
                    bstr = str(b+1)

                    # Output filename
                    outfile = outfile_pre + '_Band'+bstr+'.nc'
                    
                    # Create file
                    print('Creating '+outfile)
                    ncid = Dataset(outfile,'w')
                
                    # Ensure filling is on
                    ncid.set_fill_on()

                    # Define dimensions
                    ncid.createDimension('x',imx)
                    ncid.createDimension('y',jmx)
                    ncid.createDimension('o',1)
                    
                    # Create variables
                    v_iso = ncid.createVariable('f_iso',np.int16,('y','x'),fill_value=fill_value,zlib=True)
                    v_vol = ncid.createVariable('f_vol',np.int16,('y','x'),fill_value=fill_value,zlib=True)
                    v_geo = ncid.createVariable('f_geo',np.int16,('y','x'),fill_value=fill_value,zlib=True)
                    
                    # Load Isotropic field (Parameter 1)
                    fldname = 'BRDF_Albedo_Parameter1_Band'+bstr
                    ts = np.array(hdf.variables[fldname][:]*1e3,dtype=np.int16)
                    ts = ts[::-1,:] ; ts[ts==hdf.variables[fldname]._FillValue] = fill_value
                    v_iso[:] = ts
                    
                    # from matplotlib import pyplot as plt
                    # fig = plt.figure()
                    # plt.hist(ts[ts>=0].flatten(),bins=100)
                    # fig.show()
                    # break

                    # Get latitude extent
                    n_valid = np.zeros(jmx)
                    for j in range(jmx):
                        ts_y = ts[j,:].squeeze()
                        n_valid[j] = ((ts_y>0) & (ts_y<1000)).sum()
                    idx = np.where(n_valid > 0.0)
                    minlat = lat[np.min(idx)]
                    maxlat = lat[np.max(idx)]
                    
                    # Load Volumetric Field
                    fldname = 'BRDF_Albedo_Parameter2_Band'+bstr
                    ts = np.array(hdf.variables[fldname][:]*1e3,dtype=np.int16)
                    ts = ts[::-1,:] ; ts[ts==hdf.variables[fldname]._FillValue] = fill_value
                    v_vol[:] = ts

                    # Load Geometric Field
                    fldname = 'BRDF_Albedo_Parameter3_Band'+bstr
                    ts = np.array(hdf.variables[fldname][:]*1e3,dtype=np.int16)
                    ts = ts[::-1,:] ; ts[ts==hdf.variables[fldname]._FillValue] = fill_value
                    v_geo[:] = ts

                    # Save additional metadata needed to combine snapshots
                    v = ncid.createVariable('lon',np.float,('x')) ; v[:] = lon
                    v = ncid.createVariable('lat',np.float,('y')) ; v[:] = lat
                    v = ncid.createVariable('time',np.float,('o')) ; v[:] = time
                    v = ncid.createVariable('band_index',np.int16,('o')) ; v[:] = b+1
                    v = ncid.createVariable('lat_min',np.float,('o')) ; v[:] = minlat
                    v = ncid.createVariable('lat_max',np.float,('o')) ; v[:] = maxlat

                    # Close file
                    ncid.close()
                
                # Close file
                hdf.close()

def mcd43gf_30arc_snapshots(indir,outdir,replace=False):

    ''' Convert MCD43GF v006 30 Arcsecond product to a set of snapshots

        ARGS:
          indir (str): Base path with operational files
          outdir (str): Output to put converted snapshots
          
    '''

    import os
    import numpy as np
    from fnmatch import fnmatch
    from netCDF4 import Dataset
    import pysplat

    def albvarname(varlist):
        for name in varlist:
            if(name[0:6] == 'Albedo'):
                return name
    
    # Check output directory exists
    if(not os.path.exists(outdir)):
        os.makedirs(outdir)

    # Find operational files in directory
    outpre = [] ; time = [] ; lon = None ; lat = None
    lat_max = [] ; lat_min = []
    for root, dirs, files in os.walk(indir):
        for test_file in files:
            
            # Example file - MCD43GF_iso_Band1_001_2006_V006.hdf  
            if(fnmatch(test_file,'MCD43GF_iso_*.hdf')):
                
                # Get vol and geo kernels (assumed same root path)
                frag = test_file.split('_') ; nf = len(frag)
                vol_file = frag[0] 
                geo_file = frag[0]
                for f in frag[1:nf-1]:
                    if(f == 'iso'):
                        vol_file += '_' + 'vol'
                        geo_file += '_' + 'geo'
                    else:
                        vol_file += '_' + f
                        geo_file += '_' + f
                vol_file += '_' + frag[-1]
                geo_file += '_' + frag[-1]

                # Add root directory
                iso_file = os.path.join(root,test_file)
                vol_file = os.path.join(root,vol_file)
                geo_file = os.path.join(root,geo_file)
                
                if(os.path.exists(vol_file) and os.path.exists(geo_file)):

                    # Get Time DOY, Year and Band Index
                    band = int(frag[2][4:])
                    doy = int(frag[3])
                    nymd = int(frag[4]+'0101')

                    # Tau time
                    time = pysplat.time.nymd2tau(nymd)+float(doy-1)*24.0
                    ymd = pysplat.time.tau2yymmdd(time)
                    nymd_str = str(ymd['Year'][0]) \
                             + str(ymd['Month'][0]).zfill(2) \
                             + str(ymd['Day'][0]).zfill(2)

                    # Output file
                    outfile_pre = os.path.join(outdir,'MCD43GF_' + nymd_str)
                    
                    # Open the iso file and get the grid
                    hdf = Dataset(iso_file,'r')
                    lat = hdf.variables['Latitude'][::-1]
                    lon = hdf.variables['Longitude'][:]
                    
                    # For some reason the last latitude is NaN
                    if(not np.isfinite(lat[0])):
                        lat[0] = -90.0
                    
                    # Get the albedo variable name
                    iso_name = albvarname(list(hdf.variables.keys()))

                    # Get dimensions
                    imx = lon.shape[0] ; jmx = lat.shape[0]

                    alb = np.zeros((jmx,imx),dtype=np.int16)

                    # Determine the max/min latitude for sample with valid data
                    # ts = f_iso.max(axis=0)
                    # idv = ts > 0
                    # minlat = np.min(lat[idv])
                    # maxlat = np.max(lat[idv])

                    # Fill value    
                    fill_value = -32767

                    # Output file name
                    outfile = outfile_pre + '_Band'+str(band)+'.nc'

                    if(not os.path.exists(outfile)):

                        print('Creating '+outfile)
                        # Create file
                        ncid = Dataset(outfile,'w')
                
                        # Ensure filling is on
                        ncid.set_fill_on()

                        # Define dimensions
                        ncid.createDimension('x',imx)
                        ncid.createDimension('y',jmx)
                        ncid.createDimension('o',1)

                        # Create variables
                        v_iso = ncid.createVariable('f_iso',np.int16,('y','x'),fill_value=fill_value,zlib=True)
                        v_vol = ncid.createVariable('f_vol',np.int16,('y','x'),fill_value=fill_value,zlib=True)
                        v_geo = ncid.createVariable('f_geo',np.int16,('y','x'),fill_value=fill_value,zlib=True)

                        # Write the iso field
                        print(' -- Reading Isotropic Field')
                        n_valid = np.zeros(jmx)
                        for j in range(jmx):
                            
                            # Latitudes in file are High -> Low
                            j_in = jmx - j - 1
                            ts = hdf.variables[iso_name][j_in,:].squeeze()
                            alb[j,:] = ts
                            n_valid[j] = ((ts.data>0) & (ts.data<1000)).sum()
                        
                        # Get minimum latitude
                        idx = np.where(n_valid > 0.0)
                        minlat = lat[np.min(idx)]
                        maxlat = lat[np.max(idx)]
                        
                        print(' -- Writing Isotropic Field')
                        v_iso[:,:] = alb[:,:]

                        # Close isotropic and open geometric
                        hdf.close()
                        hdf = Dataset(geo_file,'r')

                        # Read geometric field name
                        print(' -- Reading Geometric Field')
                        alb_name = albvarname(list(hdf.variables.keys()))
                        for j in range(jmx):
                            j_in = jmx - j - 1
                            ts = hdf.variables[alb_name][j_in,:].squeeze()
                            alb[j,:] = ts

                        print(' -- Writing Geometric Field')
                        v_geo[:,:] = alb[:,:]
                        
                        # Close isotropic and open geometric
                        hdf.close()
                        hdf = Dataset(vol_file,'r')

                        # Read volumetric field name
                        print(' -- Reading Volumetric Field')
                        alb_name = albvarname(list(hdf.variables.keys()))
                        for j in range(jmx):
                            j_in = jmx - j - 1
                            ts = hdf.variables[alb_name][j_in,:].squeeze()
                            alb[j,:] = ts

                        print(' -- Writing Volumetric Field')
                        v_vol[:,:] = alb[:,:]
                
                        # Save additional metadata needed to combine snapshots
                        v = ncid.createVariable('lon',np.float,('x')) ; v[:] = lon
                        v = ncid.createVariable('lat',np.float,('y')) ; v[:] = lat
                        v = ncid.createVariable('time',np.float,('o')) ; v[:] = time
                        v = ncid.createVariable('band_index',np.int16,('o')) ; v[:] = band
                        v = ncid.createVariable('lat_min',np.float,('o')) ; v[:] = minlat
                        v = ncid.createVariable('lat_max',np.float,('o')) ; v[:] = maxlat

                        # Close file
                        ncid.close()
                    
                    hdf.close()

def combine_snapshot_to_fa_clim(indir,outdir,wvl,rsr,band_idx,srchstr='*.nc',is_clim=False,band_uncertainty=None,symlink=True):
    
    ''' Create fa-brdf climatology from a series of archived snapshots

        ARGS:
          indir (str): Base directory with BRDF snapshots
          outdir (str): Output directory
          wvl[w] (numpy float): Wavelength grid for the relative spectral response functions [nm]
          rsr[w,b] (numpy float): Relative spectral response function for each band
          band_idx[b] (list): The band indices to include in the hyperspectral extension (starting at 1)
          
        OPT ARGS:
          srchstr(str): Unix-wildcard based search string 
          is_clim(bool): If True, splat will interpolate over day of year rather than 
                         a specific UTC time, enabling the specification of climatologies
                         with yearly cycles
          band_uncertainty[b]: Standard deviation of band observations. If set will consider this in the gain matrix calc.
          symlink(bool): If True will create symbolic links to BRDF files in input to output directory
                         If False will copy the files

    '''

    import os
    import numpy as np
    from fnmatch import fnmatch
    from netCDF4 import Dataset
    from pysplat.time import tau_doy
    
    # Check band uncertainty matches band index
    if(not band_uncertainty is None and len(band_idx) != len(band_uncertainty)):
        raise Exception('band_idx and band_uncertainty must be of the same dimension')

    # Absolute path to indir
    indir_abs = os.path.abspath(indir)

    # Find all files
    outpre = [] ; time = [] ; lon = None ; lat = None
    lat_max = [] ; lat_min = []
    for root, dirs, files in os.walk(indir):
        for file in files:
            if(fnmatch(file,srchstr)):
                
                # Reconstruct "pre-name" for file
                frag = file.split('_')
                this_outpre = frag[0]#os.path.join(root,frag[0])
                for n in range(1,len(frag)-1):
                    this_outpre = this_outpre + '_' + frag[n]
                print(this_outpre)

                # Update list if unique file
                if(not this_outpre in outpre):
                    outpre.append(this_outpre)

                    # Get time stamp
                    d = Dataset(os.path.join(root,file),'r')
                    time.append(d.variables['time'][0])
                    lat_min.append(d.variables['lat_min'][0])
                    lat_max.append(d.variables['lat_max'][0])

                    # Use first file to get lon/lat
                    if(lon is None):
                        lon = d.variables['lon'][:]
                        lat = d.variables['lat'][:]
                    d.close()

    # Convert lists to numpy arrys
    time = np.array(time)
    outpre = np.array(outpre)
    lat_min = np.array(lat_min)
    lat_max = np.array(lat_max)

    # Sort in ascending time order
    if(is_clim):
        # Sort by DOY
        doy = np.array([tau_doy(t) for t in time])
        ids = np.argsort(time)

        # Normalize time to year 1985
        time = np.array([(day-1.0)*24.0 for day in doy])
        
    else:
        ids = np.argsort(time)

    # Re-sort arrays
    time = time[ids]
    outpre = outpre[ids]
    lat_max = lat_max[ids]
    lat_min = lat_min[ids]

    # Create path to output directory if it does not exist
    path = '' ; dirs = outdir.split('/')
    for dir in dirs:
        path  = os.path.join(path,dir)
        if(not os.path.exists(path)):
            os.mkdir(path)
    
    # Dimensions
    imx = lon.shape[0]
    jmx = lat.shape[0]
    tmx = time.shape[0]
    wmx = rsr.shape[0]
    bmx = len(band_idx)

    # Create Information file
    ncid = Dataset(os.path.join(outdir,'brdf_grid_info.nc'),'w')
        
    # Create dimensions
    ncid.createDimension('x',imx)
    ncid.createDimension('y',jmx)
    ncid.createDimension('t',tmx)
    ncid.createDimension('w',wmx)
    ncid.createDimension('b',bmx)
    ncid.createDimension('o',1)
        
    ncid.createVariable('lon'    ,np.float64,('x'))
    ncid.createVariable('lat'    ,np.float64,('y'))
    ncid.createVariable('lat_min',np.float64,('t'))
    ncid.createVariable('lat_max',np.float64,('t'))
    ncid.createVariable('time'   ,np.float64,('t'))
    ncid.createVariable('wvl'    ,np.float64,('w'))
    ncid.createVariable('rsr'    ,np.float64,('b','w'))
    ncid.createVariable('is_clim',np.int16,('o'))
        
    # Write variables
    ncid.variables['lon'    ][:] = lon
    ncid.variables['lat'    ][:] = lat
    ncid.variables['lat_min'][:] = lat_min
    ncid.variables['lat_max'][:] = lat_max
    ncid.variables['time'   ][:] = time
    ncid.variables['wvl'    ][:] = wvl
    ncid.variables['rsr'    ][:] = rsr.T
    
    # Write band uncertainty if set
    if(not band_uncertainty is None):
        v = ncid.createVariable('band_uncertainty',np.float64,('b'))
        v[:] = np.array(band_uncertainty)
        
    if(is_clim):
        ncid.variables['is_clim'][:] = 1
    else:
        ncid.variables['is_clim'][:] = 0
        
    # Close file
    ncid.close()
    
    # Check method for linking
    if(symlink):
        link_cmd = 'ln -f -s '
    else:
        link_cmd = 'cp '
    
    # Link the snapshots
    for t in range(tmx):
        for b in range(bmx):
            
            # Output file name
            infile = os.path.join(indir_abs,outpre[t]+'_Band'+str(band_idx[b])+'.nc')
            symfile = os.path.join(outdir,'BRDF_Band' + str(b+1) + '_Time' + str(t+1) + '.nc')
            os.system(link_cmd + infile+' '+symfile)
            
def write_brdf_clim( outfile, lon, lat, wvl, idx, amp, par ):

    ''' Write BRDF climatology file (Option )
    
        ARGS:
            outfile: The base directory name for the climatology
            lon[x] ('numpy float'): Longitude midpoints [degrees]
            lat[x] ('numpy float'): Latitude midpoints [degrees]
            wvl[w] ('numpy float'): Wavelength grid for instrument relative response function
            idx[k] ('numpy float'): Kernel Indexes from VLIDORT [*]
            amp[] ('numpy float'): Kernel Amplitudes
            par[] ('numpy float'): Kernel Parameters

            where the dimensions are
              x - Longitude
              y - Latitude
              w - Wavelength
              k - Kernel
              p - Max Kernel Par.

        [*] These come from the VLIDORT BRDF Supplement
               #   Name
              1  - Lambertian 
              2  - Ross Thin (1)
              3  - Ross Thick (1)
              4  - Li Sparse 
              5  - Li Dense
              6  - Hapke (3 Par)
              7  - Roujean
              8  - Rahman
              9  - Cox-Munk
              10 - Giss Cox-Munk
              11 - Giss Cox-Munk Cri
              12 - BPDF Soil
              13 - BPDF Vegetation
              14 - BPDF NDVI
              15 - NewCMGlint
              16 - Hapke 5 Par.
    '''
    import numpy as np
    from netCDF4 import Dataset

    # Open file for write
    ncid = Dataset(outfile,'w',clobber=True)

    # Define dimensions
    ncid.createDimension('x',par.shape[0])
    ncid.createDimension('y',par.shape[1])
    ncid.createDimension('w',par.shape[2])
    ncid.createDimension('k',par.shape[3])
    ncid.createDimension('p',par.shape[4])

    # Create variables
    vid = ncid.createVariable('clim_wvl',np.float64,('w'))
    ncid.variables['clim_wvl'][:] = wvl
    vid = ncid.createVariable('clim_lon',np.float64,('x'))
    ncid.variables['clim_lon'][:] = lon
    vid = ncid.createVariable('clim_lat',np.float64,('y'))
    ncid.variables['clim_lat'][:] = lat
    vid = ncid.createVariable('fkern_idx', np.int32,('k'))
    ncid.variables['fkern_idx'][:] = idx
    vid = ncid.createVariable('fkern_amp', np.float32,('k','w','y','x'))
    ncid.variables['fkern_amp'][:,:,:,:] = np.transpose(amp,(3,2,1,0))
    vid = ncid.createVariable('fkern_par', np.float32,('p','k','w','y','x'))
    ncid.variables['fkern_par'][:,:,:,:,:] = np.transpose(par,(4,3,2,1,0))

    # Close file
    ncid.close()



    