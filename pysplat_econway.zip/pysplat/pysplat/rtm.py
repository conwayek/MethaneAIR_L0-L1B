''' Routines for running splat within python

'''

def sed_template(template_file,outfile,var):
    
    import os

    sed_cmd  = 'sed '
    for name in var.keys():
        sed_cmd += '-e "s=%'+name+'%='+str(var[name])+'=g" '
    sed_cmd +=  template_file + ' > ' + outfile
    os.system(sed_cmd)

# Run simulation and attach output file
def run_model(control_template,outfile,vars,return_output=False,clean_template=False):

    ''' Wrapper Around SPLAT RTM
      
      ARGS:
        control_template (str): Path to control file template
        outfile (str): Ouput file name
        vars (dict): Variable names (will be substituted into control file)
      
      OPT ARGS:
        return_output(bool): If set to true will return attached output file
        clean_template(bool): Remove template after simulation completes
      
      -----------------------------
      Notes on the control template
      -----------------------------

      This is a regular splat control file, with some variables that can be replaced

      (1) The output file (outfile) must be set in the file by using %OUTFILE% key. For example:

        1 <Description of input file goes here>
        2 --------------------------------+------------------------------------------------------
        3 %%% RETRIEVAL MENU %%%          :
        4 Calculation Mode                : FORWARD
        5 Output File                     : %OUTFILE%
        6 Compute all pixels              : T
        7  (F) - X Retrieval Range        : 1 1
        8      - Y Retrieval Range        : 1 1
        9      - Output to XY?            : T
       10         (T) Use file lock?      : F
       11             Overwrite Existing? : T
       12             Only Create file    : F
       13 Root data directory             : ../data
       14 Switch on debug?                : T
       15 Debug filename                  : debug_fp.log

    Any additional keys that need to be substituted must use the vars dictionary. E.G. I could replace 
    the path to the root data directory by first editing the template input file e.g. template.control

        1 <Description of input file goes here>
        2 --------------------------------+------------------------------------------------------
        3 %%% RETRIEVAL MENU %%%          :
        4 Calculation Mode                : FORWARD
        5 Output File                     : %OUTFILE%
        6 Compute all pixels              : T
        7  (F) - X Retrieval Range        : 1 1
        8      - Y Retrieval Range        : 1 1
        9      - Output to XY?            : T
       10         (T) Use file lock?      : F
       11             Overwrite Existing? : T
       12             Only Create file    : F
       13 Root data directory             : %DATA_DIR%
       14 Switch on debug?                : T
       15 Debug filename                  : debug_fp.log

    Here the key "DATA_DIR" is signaled by bracketing it with perecent characters. To input a value 
    the vars dictionary is set. 

      In [1]: vars = {}                                                                                                                                            
      In [2]: vars['DATA_DIR'] = '../data'         
    
    Thats all there is to it. A full example of running the above:

      In [1]: import pysplat                                                                                                                                       
      In [2]: outfile = 'example.nc'                                                                                                                               
      In [3]: control_template = 'template.control'                                                                                                                
      In [4]: vars = {} ; vars['DATA_DIR'] = '../data'                                                                                                             
      In [5]: pysplat.rtm.run_model(control_template,outfile,vars) 

    '''
    
    import os
    from netCDF4 import Dataset
    
    # Path to splat executable
    scriptdir = os.path.dirname(os.path.abspath(__file__))
    splat_path = os.path.join(scriptdir,'lib/splat.exe')
    
    # Create Control file name
    fpre,_ = os.path.splitext(outfile)
    ctrlfile = fpre + '.control'
    
    # Sed template to control file
    var = vars ; var['OUTFILE'] = outfile
    sed_template(control_template,ctrlfile,var) 
    
    # Run SPLAT
    splat_cmd = splat_path + ' ' + ctrlfile
    os.system(splat_cmd)

    # Attach file
    if(return_output):
        return Dataset(outfile,'r')
    else:
        return None