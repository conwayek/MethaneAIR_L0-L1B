def write_irradiance(outfile,wvl,irr):

    ''' Write an irradiance spectrum in splat format

      ARGS:
        outfile (str): Path to write file to
        wvl[w] (numpy float): Wavlength grid [nm]
        irr[w] (numpy float): Solar Irradiance [photons/s/cm2/nm]

    '''

    from netCDF4 import Dataset
    import numpy as np 
    # Check array dimensions match
    if(len(wvl) != len(irr)):
        raise Exception('Wavelength and Irradiance arrays must be same dimension')

    # Write file
    d =  Dataset(outfile,'w')
    d.createDimension('w',len(wvl))
    v = d.createVariable('Wavelength',np.float64,('w')) ; v[:] = wvl[:]
    v = d.createVariable('Irradiance',np.float64,('w')) ; v[:] = irr[:]
    d.close()

