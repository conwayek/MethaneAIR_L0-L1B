# -*- coding: iso-8859-1 -*-

class level1(object):

    '''
    The level1 class used to create "SPLAT: format level-1 files
    
    
    [long descript goes here]
    
    Note:
        

    Attributes:
    
    '''
    
    def __init__(self,outfile,lon,lat,obsalt,time,aclon,aclat,ac_pos,ac_surfalt,ac_altsurf,ac_bore,optbenchT=None,clon=None,clat=None):
        
        ''' Initialize the level-1 SPLAT File generator

            ARGS:
                lon[x,y] (numpy 'float'): Longitude Midpoints of observation pixels [degrees]
                lat[x,y] (numpy 'float'): Latitude Midpoints of observation pixels [degrees]
                obsalt[y] (numpy 'float'): Altitude of observing instrument [km]
                time[y]  (numpy 'float'): Time of observation [GEOS-5 Tau - Hours since 1/1/1985 00:00 UTC]
            OPTIONAL:
                clon[x,y,4] (numpy 'float'): Pixel Corner longitudes (C/W from bottom left) [degrees]
                clat[x,y,4] (numpy 'float'): Pixel Corner longitudes (C/W from bottom left) [degrees]
                optbenchT[y] (numpy 'float'): Optical Bench Temperature [K]
            Here x corresponds to the cross-track pixel position
                 y corresponds to the along-track pixel position

        '''
        
        from netCDF4 import Dataset
        import numpy as np
        # Keep track of bands
        self.nband = 0 # Radiance Bands
        self.nband_brdf = 0 # For BRDF on L2 grid
        
        # Save copy of lat/lon/obsalt/time in object
        self.lat = lat ; self.lon = lon ; self.obsalt = obsalt ; self.time = time
     
        # Get dimensions from lon
        self.imx = lon.shape[0]
        self.jmx = lon.shape[1]
        self.cmx = 4
        self.eci = 3
        # Flag to check if profile is set
        self.is_prof_set = False
        self.is_prof_cld_set = False # Flag for profile flags set
        # Check the dimensions of input variables
        self.check_field_dim('Latitude', lat, [self.imx,self.jmx],checkopen=False)
        self.check_field_dim('ObservationAltitude', obsalt, [self.jmx],checkopen=False)
        self.check_field_dim('Time', time, [self.jmx],checkopen=False)
        if(not clon is None):
            self.check_field_dim('CornerLongitude', clon, [self.imx,self.jmx,self.cmx],checkopen=False)
        if(not clat is None):
            self.check_field_dim('CornerLatitude', clat, [self.imx,self.jmx,self.cmx],checkopen=False)
        if(not optbenchT is None):
            self.check_field_dim('OpticalBenchTemperature', optbenchT, [self.jmx],checkopen=False)
        
        # Open output file
        self.ncid = Dataset(outfile,'w')

        # List to hold radiance band netCDF groups
        self.ncrad = []

        # List to hold surface band netCDF groups
        self.ncalb = []

        # Define dimensions
        self.ncid.createDimension('x',self.imx) # Cross Track
        self.ncid.createDimension('y',self.jmx) # Along Track
        self.ncid.createDimension('c',self.cmx) # Corner Indices
        self.ncid.createDimension('o',       1) # Unit dimension
        self.ncid.createDimension('eci',       self.eci) # ECI dimension
        
        # Profile parameterizations
        self.ncid.createDimension('p1',1)
        self.ncid.createDimension('p2',2)
        self.ncid.createDimension('p3',3)

        # Create integer to hold number of bands
        self.ncid.createVariable('NumberOfBands',np.int16,('o'))

        # Define Geolocation Fields
        self.ncgeo = self.ncid.createGroup('Geolocation')
        self.ncgeo.createVariable('Longitude',np.float32,('y','x'))
        self.ncgeo.createVariable('Latitude',np.float32,('y','x'))
        self.ncgeo.createVariable('CornerLongitude',np.float32,('c','y','x'))
        self.ncgeo.createVariable('CornerLatitude',np.float32,('c','y','x'))
        self.ncgeo.createVariable('SolarZenithAngle',np.float32,('y','x'))
        self.ncgeo.createVariable('ViewingZenithAngle',np.float32,('y','x'))
        self.ncgeo.createVariable('SolarAzimuthAngle',np.float32,('y','x'))
        self.ncgeo.createVariable('ViewingAzimuthAngle',np.float32,('y','x'))
        self.ncgeo.createVariable('RelativeAzimuthAngle',np.float32,('y','x'))
        self.ncgeo.createVariable('SurfaceAltitude',np.float32,('y','x'))
        self.ncgeo.createVariable('ObservationAltitude',np.float32,('y'))
        self.ncgeo.createVariable('Time',np.float64,('y'))
        self.ncgeo.createVariable('OpticalBenchTemperature',np.float32,('y'))
        self.ncgeo.createVariable('Aircraft_Longitude',np.float32,('y'))
        self.ncgeo.createVariable('Aircraft_Latitude',np.float32,('y'))
        self.ncgeo.createVariable('Aircraft_AltitudeAboveSurface',np.float32,('y'))
        self.ncgeo.createVariable('Aircraft_SurfaceAltitude',np.float32,('y'))
        self.ncgeo.createVariable('Aircraft_PixelBore',np.float32,('eci','y','x'))
        self.ncgeo.createVariable('Aircraft_Pos',np.float32,('eci','y'))
         
 


        # Track if field has been set
        self.geo_is_set = {}
        for name in self.ncgeo.variables.keys():
            self.geo_is_set[name] = False

        # Define Auxliary Fields
        self.ncaux = self.ncid.createGroup('SupportingData')
        self.ncaux.createVariable('CloudFraction',np.float64,('y','x'))
        self.ncaux.createVariable('CloudPressure',np.float64,('y','x'))
        self.ncaux.createVariable('WindSpeed',np.float64,('y','x'))
        self.ncaux.createVariable('WindDirection',np.float64,('y','x'))
        self.ncaux.createVariable('Chlorophyll',np.float64,('y','x'))
        self.ncaux.createVariable('OceanSalinity',np.float64,('y','x'))
        self.ncaux.createVariable('SnowFraction',np.float64,('y','x'))
        self.ncaux.createVariable('SeaIceFraction',np.float64,('y','x'))
        self.ncaux.createVariable('ZonalWind',np.float64,('y','x'))
        self.ncaux.createVariable('MeridionalWind',np.float64,('y','x'))
        self.ncaux.createVariable('SkinTemperature',np.float64,('y','x'))
        self.ncaux.createVariable('SIF_734nm',np.float64,('y','x'))
        self.ncaux.createVariable('TropopausePressure',np.float64,('y','x'))

        # Define Quality Flag
        self.ncid.createVariable('MainDataQualityFlag',np.int16,('y','x'))
        self.ncid.variables['MainDataQualityFlag'][:] = 0

        # Create Empty profile group
        self.ncprf = self.ncid.createGroup('Profile')

        # Track if auxiliary field has been set
        self.aux_is_set = {}
        for name in self.ncaux.variables.keys():
            self.aux_is_set[name] = False
        print(ac_bore.shape)
        # Set Longitude and Latitude
        self.ncgeo.variables['Longitude'][:] = lon.T ; self.geo_is_set['Longitude'] = True
        self.ncgeo.variables['Latitude' ][:] = lat.T ; self.geo_is_set['Latitude' ] = True
        self.ncgeo.variables['Time'     ][:] = time  ; self.geo_is_set['Time'     ] = True
        self.ncgeo.variables['ObservationAltitude'][:] = obsalt  ; self.geo_is_set['ObservationAltitude'] = True
        self.ncgeo.variables['Aircraft_Longitude'][:] = aclon    ; self.geo_is_set['Aircraft_Longitude'] = True
        self.ncgeo.variables['Aircraft_Latitude'][:] = aclat     ; self.geo_is_set['Aircraft_Latitude'] = True
        self.ncgeo.variables['Aircraft_AltitudeAboveSurface'][:] = ac_altsurf     ; self.geo_is_set['Aircraft_AltitudeAboveSurface'] = True
        self.ncgeo.variables['Aircraft_SurfaceAltitude'][:] = ac_surfalt     ; self.geo_is_set['Aircraft_SurfaceAltitude'] = True
        self.ncgeo.variables['Aircraft_PixelBore'][:,:,:] = ac_bore.T     ; self.geo_is_set['Aircraft_PixelBore'] = True
        self.ncgeo.variables['Aircraft_Pos'][:,:] = ac_pos.T     ; self.geo_is_set['Aircraft_Pos'] = True
        
        if(not clon is None):
            self.ncgeo.variables['CornerLongitude'][:] = clon.T ; self.geo_is_set['CornerLongitude'] = True
        if(not clat is None):
            self.ncgeo.variables['CornerLatitude'][:] = clat.T ; self.geo_is_set['CornerLatitude'] = True
        if(not optbenchT is None):
            self.ncgeo.variables['OpticalBenchTemperature'][:] = optbenchT
            self.geo_is_set['OpticalBenchTemperature'] = True

        # Quality Flag
        self.qf_is_set = False

        # Valid pressure adjustment options
        self.valid_sigma = ['BACKGROUND','SIGMA','HYBRID']
        
    def add_sat_earth_viewgeo(self,obslon,obslat):

        ''' Sets the viewing geometry for an Earth viewing instrument given its lon and lat

            ARGS:
                obslon[y] (numpy 'float'): instrument longitude [degrees]
                obslat[y] (numpy 'float'): instrument latitudes [degrees]

                Here y corrsponds to the along track pixel dimension
        '''

        import numpy as np
        from pysplat.time import tau_doy, tau_hod

        # Check the dimensions of the inputs


        # Earth radius in km
        earthradius = 6378.1 

        # Init view geometry object
        sat_geom = ViewGeoObj()

        sza = np.zeros((self.imx,self.jmx)) ; vza = np.zeros((self.imx,self.jmx))
        saa = np.zeros((self.imx,self.jmx)) ; vaa = np.zeros((self.imx,self.jmx))
        aza = np.zeros((self.imx,self.jmx))
        for j in range(self.jmx):
            doy = tau_doy(self.time[j])
            hod = tau_hod(self.time[j])
            # print(self.obsalt[j],earthradius,doy,hod)
            for i in range(self.imx):
                # print('--->',self.lon[i,j],self.lat[i,j],obslon[j],obslat[j])
                sat_geom.compute_geom(self.lon[i,j],self.lat[i,j],obslon[j],\
                                      obslat[j],self.obsalt[j],earthradius,doy,hod[0])
                sza[i,j] = sat_geom.sza ; vza[i,j] = sat_geom.vza
                saa[i,j] = sat_geom.saa ; vaa[i,j] = sat_geom.vaa
                aza[i,j] = sat_geom.aza
        
        # Write geolocation to disk
        self.set_2d_geofield('SolarZenithAngle',sza)
        self.set_2d_geofield('ViewingZenithAngle',vza)
        self.set_2d_geofield('SolarAzimuthAngle',saa)
        self.set_2d_geofield('ViewingAzimuthAngle',vaa)
        self.set_2d_geofield('RelativeAzimuthAngle',aza)

        return sza,vza,saa,vaa,aza
        
    def set_2d_geofield(self,varname,var):
        
        ''' Sets values for optional 2D geolocation field variables

            ARGS:
                varname ('string'): Name of the level1 geolocation field
                var[x,y] (numpy 'float'): Values for the level1 geolocation field
            
            Here x corresponds to the cross-track pixel position
                 y corresponds to the along-track pixel position

            The following fields are predefined - Fill values used if not set
            _________________________________________________________________________
            | varname              | Description
            _________________________________________________________________________
            | SolarZenithAngle     | Solar Zenith Angle in Degrees
            | ViewingZenithAngle   | Viewing Zenith Angle in Degrees
            | SolarAzimuthAngle    | Solar Azimuth Angle in Degrees
            | ViewingAzimuthAngle  | Viewing Azimuth Angle in Degrees
            | RelativeAzimuthAngle | Relative Azimuth Angle ([*] VLIDORT Def.) in degrees
            | SurfaceAltitude      | Surface elevations in km
            |_________________________________________________________________________
            
            [*] VLIDORT defines relative azimuth between 0-360 degrees 
                Backscatter occurs at 0 degrees (opposite to typical definitions)

        '''

        # Check field
        self.check_field_dim(varname, var, [self.imx,self.jmx],checkdef='Geolocation')
        
        # Set field
        self.ncgeo.variables[varname][:] = var.T
        
        # Flag field as set
        self.geo_is_set[varname] = True
        
    def set_2d_supportfield(self,varname,var):
        
        ''' Sets values for optional 2D support data field variables

            ARGS:
                varname ('string'): Name of the level1 suport data field
                var[x,y] (numpy 'float'): Values for the level1 support data field
            
            Here x corresponds to the cross-track pixel position
                 y corresponds to the along-track pixel position
                 
        '''
        
        # Check field
        self.check_field_dim(varname, var, [self.imx,self.jmx],checkdef='SupportingData')

        # Set field
        self.ncaux.variables[varname][:] = var.T

        # Flag field as set
        self.aux_is_set[varname] = True

    def set_main_qf(self,qf):

        ''' Sets quality flag values that can aid filtering in SPLAT

          ARGS:
            qf[x,y] (numpy int): Values of the quality flag 0=Best

          Here x corresponds to the cross-track pixel position
                 y corresponds to the along-track pixel position
        '''
        
        # Check Field
        self.check_field_dim('MainDataQualityFlag', qf, [self.imx,self.jmx])

        # Set field
        self.ncid.variables['MainDataQualityFlag'][:] = qf.T

        # Flag field as set
        self.qf_is_set = True

    def add_profile_met(self,pedge,Tedge,rh=None,zsurf=None,eta=None,eta_trop=None,ptrop=None):
        
        ''' Sets p,T,z information when adding profile group to l1 file

            ARGS:
                pedge[x,y,z+1] ('float'): Pressure Edges at grid box center [hPa]
                Tedge[x,y,z+1] ('float'): Temperature Edges at grid box center [K]
            OPTIONAL:
                rh[x,y,z] ('float'): Relative Humidity [%] (defaults to zero otherwise)
                zsurf[x,y] ('float'): Surface Altitude [km] 
                eta[z+1,:2] ('float'): eta grid coefficients
                eta_trop[z+1,:3] ('float'): eta-tropopause grid coefficients
                ptrop[x,y] ('float'): Tropopause Pressure [hPa]
            
                  - Only one of eta and eta_trop can be set
                  - ptrop must be set when using eta_trop

            where the dimensions are
                x,y: across and along track dimensions 
                z: Vertical grid dimension

            ----------------------------
            Note on the eta coefficients
            ----------------------------

            Let psurf[x,y] be the surface pressure at pixel x,y

            The pressure edge at level l will be
            pedge[x,y,l] = eta[l,0] + psurf[x,y]*eta[l,1]

            ---------------------------------
            Note on the eta_trop coefficients
            ---------------------------------
            
            Let ptrop[x,y] be the tropopause pressure at pixel x,y

            The pressure edge at level l will be
            pedge[x,y,l] = eta[l,0] + ptrop[x,y]*eta[l,1] + (psurf[x,y]-ptrop[x,y])*eta[l,2]
            
        '''

        import numpy as np
        
        # Check if set
        if('pedge' in self.ncprf.variables.keys()):
            raise Exception('Met profile has already been set')
        
        # Logic for which grid
        isEta = True ; isEtaTrop = True
        if( eta is None ): isEta = False
        if( eta_trop is None): isEtaTrop = False

        # Check that both eta and eta_trop not set
        if(isEta and isEtaTrop):
            raise Exception('eta and eta_trop both set (can only set 1)')
        
        # Check tropopause pressure is set when using eta_trop
        if(isEtaTrop and ptrop is None):
            raise Exception('ptrop must be set when using eta_trop')

        # Get dimension 
        self.lmx = pedge.shape[2]-1

        # Check Variable dimensions
        self.check_field_dim('pedge',pedge,[self.imx,self.jmx,self.lmx+1])
        self.check_field_dim('Tedge',Tedge,[self.imx,self.jmx,self.lmx+1])
        if(not zsurf is None):
            self.check_field_dim('zsurf',zsurf,[self.imx,self.jmx])
        if(isEta):
            self.check_field_dim('eta',eta,[self.lmx+1,2])
        if(isEtaTrop):
            self.check_field_dim('eta_trop',eta_trop,[self.lmx+1,3])

        # Check grid definition
        self.GridTopToBot = pedge[0,0,0] < pedge[0,0,1]
        dl=-1 
        if(self.GridTopToBot): dl=1
        
        # Create dimensions
        self.ncid.createDimension('z',self.lmx)
        self.ncid.createDimension('ze',self.lmx+1)

        # Write Pressure
        self.ncprf.createVariable('VerticalGridType',np.int16,('o'))
        if(isEta or isEtaTrop):
            
            if(isEta):
                this_eta = eta
            else:
                this_eta = eta_trop

            var = self.ncprf.createVariable('psurf',np.float64,('y','x'))
            if(self.GridTopToBot):
                var[:] = pedge[:,:,-1].squeeze().T
            else:
                var[:] = pedge[:,:,0].squeeze().T
            var = self.ncprf.createVariable('ap',np.float64,('ze'))
            var[:] = this_eta[::dl,0].squeeze()
            var = self.ncprf.createVariable('bp',np.float64,('ze'))
            var[:] = this_eta[::dl,1].squeeze()
            if(isEta):
                self.ncprf.variables['VerticalGridType'][0] = 2
            else:
                self.ncprf.variables['VerticalGridType'][0] = 3
                var = self.ncprf.createVariable('cp',np.float64,('ze'))
                var[:] = this_eta[::dl,2].squeeze()
                var = self.ncprf.createVariable('ptrop',np.float64,('y','x'))
                var[:] = ptrop.T

        else:
            self.ncprf.variables['VerticalGridType'][0] = 1
            var = self.ncprf.createVariable('pedge',np.float64,('ze','y','x')) 
            var[:] = pedge[:,:,::dl].T

        # Write Temperature
        var = self.ncprf.createVariable('Tedge',np.float64,('ze','y','x'))
        var[:] = Tedge[:,:,::dl].T

        # Usurp whatever altitude grid information if set
        if(not zsurf is None):
            self.ncgeo.variables['SurfaceAltitude'][:] = zsurf.T
            self.geo_is_set['SurfaceAltitude'] = True
        
        if(not rh is None):
            var = self.ncprf.createVariable('RH',np.float64,('z','y','x')) 
            var[:] = rh[:,:,::dl].T

        # If no exceptions raised then the profile is set
        self.is_prof_set = True

        # Set some logic to flag whether cloud fields have been set
        var = self.ncprf.createVariable('LambertianCloudSet',np.int16,('o'))
        var[:] = 0
        var = self.ncprf.createVariable('ScatteringCloudSet',np.int16,('o'))
        var[:] = 0

    def add_3d_profilefield(self,varname,fld3d,default_sigma='BACKGROUND',bgrd=None):
        
        ''' Sets p,T,z information when adding profile group to l1 file

            ARGS:
                varname ('string'): Name of 3D output field
                fld3d[x,y,z] ('float'): 3D field to add to profile

            OPTIONAL ARGS:

                default_sigma: This is the profile adjustment method to employ when 
                               correcting for a surface pressure/terrain height change
                               There are 3 Options:
                               = 'BACKGROUND' (default): Profile is treated as background
                                 In this case after a terrain adjustment the original 
                                 profile is interpolated to the new vertical grid in 
                                 pressure space
                               = 'SIGMA': The layer vertical column density between the original 
                                 grid and new vertical grids is preserved
                               = 'HYBRID': A combination of BACKGROUND and SIGMA
                                  The bgrd argument must be specified - This will be subject to 
                                  the background adjustment. The remaining (var-bgrd) component 
                                  will be subject to the SIGMA adjustment

                bgrd[x,y,z] (optional, numpy float): 'Background' - will not be
                    subject to hypsometric adjustment when layer pressures are adjusted 
                    to a surface pressure change
                
                where the dimensions are - 
                    x - Cross track
                    y - Along track 
                    z - Altitude

        '''

        import numpy as np
        
        # Check if set default sigma is valid
        if( not  any(default_sigma == s for s in self.valid_sigma)):
            raise Exception(default_sigma + ' is not a valid default_sigma choice')
            
        # Check for background write
        if(default_sigma == 'HYBRID'):

            # Check field is defined
            if(bgrd is None):
                raise Exception('default sigma is set to HYBRID but bgrd is not defined!')
            # Set 
            write_bgrd =  True
        else:
            write_bgrd = False
        
        # Check if profile set
        if(not self.is_prof_set):
            raise Exception('must set met profile before defining 3D fields (add_profile_met)')

        # Check dimensions of input field
        self.check_field_dim(varname,fld3d,[self.imx,self.jmx,self.lmx])
        
        # Check Background dimensions
        if(write_bgrd):
            self.check_field_dim(varname+'_Background',bgrd,[self.imx,self.jmx,self.lmx])
        
        # Check vertical grid ordering
        dl=-1 
        if(self.GridTopToBot): dl=1

        # Write the data
        if(varname in self.ncprf.variables.keys()):
            self.ncprf.variables[varname][:] = fld3d[:,:,::dl].T
            if(write_bgrd):
                self.ncprf.variables[varname+'_Background'][:] = bgrd[:,:,::dl].T
        else:
            var = self.ncprf.createVariable(varname,np.float64,('z','y','x'))
            var[:] = fld3d[:,:,::dl].T
            var = self.ncprf.createVariable(varname+'_ErrorCovarType',np.int16,('o'))
            var[:] = -1
            var = self.ncprf.createVariable(varname+'_StateType',np.int16,('o'))
            var[:] = 1
            self.ncprf.createVariable(varname+'_SigmaAdjustType',np.int16,('o'))
            if(write_bgrd):
                var = self.ncprf.createVariable(varname+'_Background',np.float64,('z','y','x'))
                var[:] = bgrd[:,:,::dl].T
            
        # Set Profile adjustment type
        ct = 0
        for signame in self.valid_sigma:
            ct+=1
            if(default_sigma == signame):
                self.ncprf.variables[varname+'_SigmaAdjustType'][:] = ct

    def add_diagonal_prof_prior(self, name, Sdiag, checkDim=True,checkProf=True):
    
        ''' Adds a diagonal prior covariance matrix to a profile variable

            Args:
                name('str'): Name of profile variable
                Sdiag[x,y,z]: Diagonal elements of covariance matrix (along z)
                checkDim: Set to true to check if input field dimensions are correct (default:True)
                checkProf: Set to true to check if StateType is a profile variable

            where the dimensions are - 
                    x - Cross Track
                    y - Along Track
                    z - Altitude
            x,y,z can have dimension 1 : interpreted as a constant along the respective dimension

        '''
        
        import numpy as np
        
        # Check that the profile field has been defined
        priorname = name+'_ErrorCovarType'
        
        if not any(priorname in s for s in self.ncprf.variables.keys()):
            raise Exception('Cannot add prior as '+name+' has not been defined')
        
        # This should only apply for profile variables
        if(self.ncprf.variables[name+'_StateType'][0] != 1 and checkProf):
            raise Exception('Cannot add prior as '+name+' is not a profile variable')
        
        # Define Error covariance name
        sname = name + '_ErrorCovar'

        # Correct dimensions for output field
        outdim = [self.imx,self.jmx,self.lmx]
        
        # Check dimensions
        if(checkDim):
            self.check_field_dim(sname,Sdiag,outdim,allow_unit_dim=True)
        
        # Update the field Type
        self.ncprf.variables[priorname][:] = 1

        # Determine field dimensions
        outdim = ['x','y','z']
        for n in range(3):
            if( Sdiag.shape[n] == 1 ): outdim[n] = 'o'
                
        # Define field
        self.ncprf.createVariable(sname,np.float64,tuple(outdim[::-1]))
        
        # Check if its a profile variable - If so then check vertical dimension order
        dl = 1
        if(self.ncprf.variables[name+'_StateType'][0] == 1):
            if(not self.GridTopToBot): dl = -1
        
        # Write the covariance matrix
        self.ncprf.variables[sname][:,:,:] = Sdiag[:,:,::dl].T

    def add_correlated_prof_prior(self,name,Sdiag,corrlen,checkDim=True):
        
        ''' Adds a prior covariance matrix to a profile variable 

            Matrix includes correlations between layers defined by corrlen

            Args:
                name('str'): Name of profile variable
                Sdiag[x,y,z]: Diagonal elements of covariance matrix (along z)
                corrlen[x,y]: Correlation length scale (km)
                checkDim: Set to true to check if input field dimensions are correct (default:True)
            where the dimensions are -
                    x - Longitude
                    y - Latitude
                    z - Altitude
            x and y can have dimension 1: interpreted as a constant along the respective dimension

        '''

        import numpy as np
        
        # This should only apply for profile variables
        if(self.ncprf.variables[name+'_StateType'][0] != 1):
            raise Exception('Cannot add prior as '+name+' is not a profile variable')
        
        # Check that the profile field has been defined
        priorname = name+'_ErrorCovarType'
        if not any(priorname in s for s in self.ncprf.variables.keys()):
            raise Exception('Cannot add prior as '+name+' has not been defined')
        
        # Define Error covariance name
        sname = name + '_ErrorCovar'
        
        # Check dimensions of diagonal covariance elements
        if(checkDim):
            outdim = [self.imx,self.jmx,self.lmx]
            self.check_field_dim(sname,Sdiag,outdim,allow_unit_dim=True)
            
            # Now Check the correlation length scale field
            outdim = [self.imx,self.jmx]
            self.check_field_dim(name+'_CorrelationLength',corrlen,outdim,allow_unit_dim=True)
        
        # Update the field Type
        self.ncprf.variables[priorname][:] = 2

        # Determine field dimensions and define
        outdim = ['x','y','z']
        for n in range(3):
            if( Sdiag.shape[n] == 1 ): outdim[n] = 'o'
        self.ncprf.createVariable(sname,np.float64,tuple(outdim[::-1]))
        
        # Do the same for the corrlen field
        outdim = ['x','y']
        for n in range(2):
            if( corrlen.shape[n] == 1 ): outdim[n] = 'o'
        self.ncprf.createVariable(name+'_CorrelationLength',np.float64,tuple(outdim[::-1]))
        
        # Check if its a profile variable - If so then check vertical dimension order
        dl = 1
        if(self.ncprf.variables[name+'_StateType'][0] == 1):
            if(not self.GridTopToBot): dl = -1
        
        # Write fields
        self.ncprf.variables[sname][:,:,:] = Sdiag[:,:,::dl].T
        self.ncprf.variables[name+'_CorrelationLength'][:,:] = corrlen.T
        
    def add_custom_prior(self, name, Scov, checkDim=True):
        
        ''' Adds fully specified Covariance matrix to any variable type

            Args:
                name('str'): Name of profile variable
                Scov[x,y,z,z]: Covariance matrix
                checkDim: Set to true to check if input field dimensions are correct (default:True)
                
            where the dimensions are - 
                    x - Cross track
                    y - Along track
                    z - Altitude or Parameters
            x,y, and t can have dimension 1: interpreted as a constant along the respective dimension


        '''
        
        import numpy as np
        
        # Check that the profile field has been defined
        priorname = name+'_ErrorCovarType'
        if not any(priorname == s for s in self.ncprf.variables.keys()):
            raise Exception('Cannot add prior as '+name+' has not been defined')
        
        # Define Error covariance name
        sname = name + '_ErrorCovar'
        
        # Correct dimensions for output field
        dl = 1
        if(self.ncprf.variables[name+'_StateType'][0] == 1):
            
            # Get variable dimemension
            v = self.lmx ; vstr = 'z' ; strict_idx = []
            
            # Force index order TOA -> Surface
            if(not self.GridTopToBot): dl = -1
            
        elif(self.ncprf.variables[name+'_StateType'][0] == 2):
            v = 4 ; vstr = 'p3' ; strict_idx = [2,3]
        elif(self.ncprf.variables[name+'_StateType'][0] == 3):
            v = 3 ; vstr = 'p2' ; strict_idx = [2,3]
        elif(self.ncprf.variables[name+'_StateType'][0] == 4):
            v = 2 ; vstr = 'p1' ; strict_idx = [2,3]
        else:
            raise Exception('Unrecognized profile type index for '+name)
        
        # Check dimensions
        if(checkDim):
            outdim = [self.imx,self.jmx,v,v]
            self.check_field_dim(sname,Scov,outdim,strict_idx=strict_idx,allow_unit_dim=True)
        
        # Update the field Type
        self.ncprf.variables[priorname][:] = 3
        
        # Determine field dimensions
        outdim = ['x','y',vstr,vstr]
        
        for n in range(4):
            if( Scov.shape[n] == 1 ): outdim[n] = 'o'
                
        # Define field
        self.ncprf.createVariable(sname,np.float64,tuple(outdim[::-1]))

        # Write the covariance matrix
        self.ncprf.variables[sname][:,:,:,:] = Scov[:,:,::dl,::dl].T

    def write_nc_fld(self,ncid,name,var,outdim,dtype=None):
        
        import numpy as np

        if(dtype is None): dtype=np.float64

        # Get dimensions
        outdim_mod = outdim[:]
        ndim = len(outdim_mod)

        # Find unit dimension
        for n in range(ndim):
            if( var.shape[n] == 1 ): outdim_mod[n] = 'o'
        
        # Create the field (transpose dimensions for FORTRAN order)
        ncid.createVariable(name,dtype,tuple(outdim[::-1]))

        # Write field
        ncid.variables[name][:] = var.T

    def add_gdf_aerosol(self, name, aod, zmin, zmax, pkhght, pkwdth):
        
        ''' Add profile parameterized by gen. distr. function to output array

            Args:
                name ('str'): Name of trace gas
                aod[x,y] (numpy float): Column aerosol optical depth
                zmin[x,y] (numpy float): Minimum Height (km)
                zmax[x,y] (numpy float): Maximum Height (km)
                pkhght[x,y] (numpy float): Peak Height (km)
                pkwdth[x,y] (numpy float): Peak Width (km)

                where the dimensions are - 
                    x - Cross track
                    y - Along track

        '''
        import numpy as np

        # Correct dimensions for output field
        outdim = [self.imx,self.jmx]

        # Check field dimensions
        self.check_field_dim(name,aod,outdim)
        self.check_field_dim(name+'_zmin',zmin,outdim)
        self.check_field_dim(name+'_zmax',zmax,outdim)
        self.check_field_dim(name+'_pkh',pkhght,outdim)
        self.check_field_dim(name+'_pkw',pkwdth,outdim)

        # Output field dimensions
        outdim = ['x','y']

        # Write fields
        self.write_nc_fld(self.ncprf,name,aod,outdim)
        self.write_nc_fld(self.ncprf,name+'_zmin',zmin,outdim)
        self.write_nc_fld(self.ncprf,name+'_zmax',zmax,outdim)
        self.write_nc_fld(self.ncprf,name+'_pkh',pkhght,outdim)
        self.write_nc_fld(self.ncprf,name+'_pkw',pkwdth,outdim)

        # Initialize Error Covariance Type
        self.ncprf.createVariable(name+'_ErrorCovarType',np.int16,('o'))
        self.ncprf.createVariable(name+'_StateType',np.int16,('o'))
        self.ncprf.variables[name+'_ErrorCovarType'][:] = -1
        self.ncprf.variables[name+'_StateType'][:] = 2 # StateType = 2 => GDF

    def add_gdf_prior(self, name, aod_err, pkhght_err, pkwdth_err):
    
        ''' Add error associated with profile parameterized by an box function to output array

            Args:
                name ('str'): Name of trace gas
                aod_err[x,y] (numpy float): Column aerosol optical error
                pkhght_err[x,y] (numpy float): Peak Height error (km)
                pkwdth_err[x,y] (numpy float): Peak Width error (km)
                zmin[x,y] (numpy float): Minimum Height (km)
                zmax[x,y] (numpy float): Maximum Height (km)

                where the dimensions are -
                    x - Longitude
                    y - Latitude
        '''
        
        import numpy as np
        
        # Check that the profile field has been defined
        priorname = name+'_ErrorCovarType'
        
        if not any(priorname in s for s in self.ncprf.variables.keys()):
            raise Exception('Cannot add prior as '+name+' has not been defined')
        
        # This should only apply for box profile variables
        if(self.ncprf.variables[name+'_StateType'][0] != 2):
            raise Exception('Cannot add prior as '+name+' is not a gdf profile variable')
        
        # Check that dimensions are the same
        if(not np.logical_and.reduce(aod_err.shape==pkhght_err.shape)):
            raise Exception('Cannot add prior as aod and pkhght dimensions are different')
        if(not np.logical_and.reduce(aod_err.shape==pkwdth_err.shape)):
            raise Exception('Cannot add prior as aod and pkwdth dimensions are different')
            
        # Define Error covariance name
        sname = name + '_ErrorCovar'
        
        # Correct dimensions for output field
        outdim = [self.imx,self.jmx]

        # Check field dimensions
        self.check_field_dim(sname,aod_err,outdim)
        
        # Update the field Type (Use diagonal index)
        self.ncprf.variables[priorname][:] = 1
        
        # Allocate error 
        Sdim = [outdim[0],outdim[1],3]
        
        # Output field dimensions
        outdim_name = ['x','y','p3']
        for n in range(3):
            if( Sdim[n] == 1 ): 
                outdim_name[n] = 'o'
                Sdim[n] = 1
        
        # Define field
        self.ncprf.createVariable(sname,np.float64,tuple(outdim_name[::-1]))
        
        # Set diagonal error
        Sdiag = np.zeros((Sdim))
        Sdiag[:,:,0] = aod_err[:,:]
        Sdiag[:,:,1] = pkhght_err[:,:]
        Sdiag[:,:,2] = pkwdth_err[:,:]
        
        # Write the covariance matrix
        self.ncprf.variables[sname][:,:,:] = Sdiag[:,:,:].T

    def add_exp_aerosol(self, name, aod, zmin, zmax, rxhght):
        
        ''' Add profile parameterized by an exponential function to output array

            Args:
                name ('str'): Name of trace gas
                aod[x,y] (numpy float): Column aerosol optical depth
                zmin[x,y] (numpy float): Minimum Height (km)
                zmax[x,y] (numpy float): Maximum Height (km)
                rxhght[x,y] (numpy float): Relaxation Height (km)

                where the dimensions are - 
                    x - Longitude
                    y - Latitude

        '''
        
        import numpy as np

        # Correct dimensions for output field
        outdim = [self.imx,self.jmx]

        # Check field dimensions
        self.check_field_dim(name,aod,outdim)
        self.check_field_dim(name+'_zmin',zmin,outdim)
        self.check_field_dim(name+'_zmax',zmax,outdim)
        self.check_field_dim(name+'_rxh',rxhght,outdim)

        # Output field dimensions
        outdim = ['x','y']

        # Write fields
        self.write_nc_fld(self.ncprf,name,aod,outdim)
        self.write_nc_fld(self.ncprf,name+'_zmin',zmin,outdim)
        self.write_nc_fld(self.ncprf,name+'_zmax',zmax,outdim)
        self.write_nc_fld(self.ncprf,name+'_rxh',rxhght,outdim)

        # Initialize Error Covariance Type
        self.ncprf.createVariable(name+'_ErrorCovarType',np.int16,('o'))
        self.ncprf.createVariable(name+'_StateType',np.int16,('o'))
        self.ncprf.variables[name+'_ErrorCovarType'][:] = -1
        self.ncprf.variables[name+'_StateType'][:] = 3 # StateType = 3 => EXP

    def add_exp_prior(self, name, aod_err, rxhght_err):
    
        ''' Add error associated with profile parameterized by an box function to output array

            Args:
                name ('str'): Name of trace gas
                aod_err[x,y] (numpy float): Column aerosol optical error
                rxhght_err[x,y] (numpy float): Relax. Height error (km)
                zmin[x,y] (numpy float): Minimum Height (km)
                zmax[x,y] (numpy float): Maximum Height (km)

                where the dimensions are -
                    x - Longitude
                    y - Latitude
        '''
        
        import numpy as np
        
        # Check that the profile field has been defined
        priorname = name+'_ErrorCovarType'
        
        if not any(priorname in s for s in self.ncprf.variables.keys()):
            raise Exception('Cannot add prior as '+name+' has not been defined')
        
        # This should only apply for box profile variables
        if(self.ncprf.variables[name+'_StateType'][0] != 3):
            raise Exception('Cannot add prior as '+name+' is not a exp profile variable')
        
        # Check that dimensions are the same
        if(not np.logical_and.reduce(aod_err.shape==rxhght_err.shape)):
            raise Exception('Cannot add prior as aod and rxhght dimensions are different')
        
        # Define Error covariance name
        sname = name + '_ErrorCovar'
        
        # Correct dimensions for output field
        outdim = [self.imx,self.jmx]

        # Check field dimensions
        self.check_field_dim(sname,aod_err,outdim)
        
        # Update the field Type (Use diagonal index)
        self.ncprf.variables[priorname][:] = 1
        
        # Allocate error 
        Sdim = [outdim[0],outdim[1],2]
        
        # Output field dimensions
        outdim_name = ['x','y','p2']
        for n in range(4):
            if( Sdim[n] == 1 ): 
                outdim_name[n] = 'o'
                Sdim[n] = 1
        
        # Define field
        self.ncprf.createVariable(sname,np.float64,tuple(outdim_name[::-1]))
        
        # Set diagonal error
        Sdiag = np.zeros((Sdim))
        Sdiag[:,:,0] = aod_err[:,:]
        Sdiag[:,:,1] = rxhght_err[:,:]
        
        # Write the covariance matrix
        self.ncprf.variables[sname][:,:,:] = Sdiag[:,:,:].T
    
    def add_box_aerosol(self, name, aod, zmin, zmax):
        
        ''' Add profile parameterized by an box function to output array

            Args:
                name ('str'): Name of trace gas
                aod[x,y] (numpy float): Column aerosol optical depth
                zmin[x,y] (numpy float): Minimum Height (km)
                zmax[x,y] (numpy float): Maximum Height (km)

                where the dimensions are - 
                    x - Across Track
                    y - Along Track
        '''
        
        import numpy as np

        # Correct dimensions for output field
        outdim = [self.imx,self.jmx]

        # Check field dimensions
        self.check_field_dim(name,aod,outdim)
        self.check_field_dim(name+'_zmin',zmin,outdim)
        self.check_field_dim(name+'_zmax',zmax,outdim)

        # Output field dimensions
        outdim = ['x','y']

        # Write fields
        self.write_nc_fld(self.ncprf,name,aod,outdim)
        self.write_nc_fld(self.ncprf,name+'_zmin',zmin,outdim)
        self.write_nc_fld(self.ncprf,name+'_zmax',zmax,outdim)

        # Initialize Error Covariance Type
        self.ncprf.createVariable(name+'_ErrorCovarType',np.int16,('o'))
        self.ncprf.createVariable(name+'_StateType',np.int16,('o'))
        self.ncprf.variables[name+'_ErrorCovarType'][:] = -1
        self.ncprf.variables[name+'_StateType'][:] = 4 # StateType = 4 => BOX
    
    def add_box_prior(self, name, aod_err):
    
        ''' Add error associated with profile parameterized by an box function to output array

            Args:
                name ('str'): Name of trace gas
                aod_err[x,y] (numpy float): Column aerosol optical error (km)
                zmin[x,y] (numpy float): Minimum Height (km)
                zmax[x,y] (numpy float): Maximum Height (km)

                where the dimensions are -
                    x - Longitude
                    y - Latitude
        '''
        
        import numpy as np
        
        # Check that the profile field has been defined
        priorname = name+'_ErrorCovarType'
        
        if not any(priorname in s for s in self.ncprf.variables.keys()):
            raise Exception('Cannot add prior as '+name+' has not been defined')
        
        # This should only apply for box profile variables
        if(self.ncprf.variables[name+'_StateType'][0] != 4):
            raise Exception('Cannot add prior as '+name+' is not a box profile variable')
        
        # Define Error covariance name
        sname = name + '_ErrorCovar'
        
        # Correct dimensions for output field
        outdim = [self.imx,self.jmx]

        # Check field dimensions
        self.check_field_dim(sname,aod_err,outdim)
        
        # Update the field Type (Use diagonal index)
        self.ncprf.variables[priorname][:] = 1
        
        # Allocate error 
        Sdim = [outdim[0],outdim[1],1]
        
        # Output field dimensions
        outdim_name = ['x','y','p1']
        for n in range(3):
            if( Sdim[n] == 1 ): 
                outdim_name[n] = 'o'
                Sdim[n] = 1
        
        # Define field
        self.ncprf.createVariable(sname,np.float64,tuple(outdim_name[::-1]))
        
        # Set diagonal error
        Sdiag = np.zeros((Sdim))
        Sdiag[:,:,0] = aod_err[:,:]
        
        # Write the covariance matrix
        self.ncprf.variables[sname][:,:,:] = Sdiag[:,:,:].T
    
    def add_cloud_to_profile(self,cf,pcld=None,cod=None,cld_types=None):

        ''' Add cloud fields 
          
          Args:
              cf[x,y,c] (numpy float): Sub-pixel cloud fraction
          Opt Args:
              pcld[x,y,c] (numpy float): Sub-pixrl cloud pressure [hPa]
              cod[x,y,z,c,s] (numpy float): Cloud optical depths []
              cld_types[s] (s): Cloud type names
          
          - To set lambertian cloud fields then pcld must be set
          - To set scattering clouds then cod or cld_types must be set
          - It is ok to set both, but at a minimum one option must be set
         
          where the dimensions are -
                    x - Longitude
                    y - Latitude
                    z - Altitude
                    c - Maximum # cloud sub-pixels
                    s - Number of cloud species

                    
        '''
        
        import numpy as np

        # Checks for profile
        if(not self.is_prof_set):
            raise Exception('profile must be set before adding clouds')
        if(self.is_prof_cld_set):
            raise Exception('profile clouds have already been set!!!')
        if( cod is None and not cld_types is None):
            raise Exception('cod must be set because cld_types has been')
        if( not cod is None and cld_types is None):
            raise Exception('cld_types must be set because cod has been')
        
        # cloud sub pixel max dimension
        self.cmx = cf.shape[2]

        # Check dimensions of input field
        self.check_field_dim('cf',cf,[self.imx,self.jmx,self.cmx])

        # Check the fields are the correct dimension
        do_lam = False ; do_scat = False
        if(not pcld is None):
            self.check_field_dim('pcld',pcld,[self.imx,self.jmx,self.cmx])
            do_lam = True
        if(not cod is None):
            nspc = cod.shape[4]
            self.check_field_dim('cod',cod,[self.imx,self.jmx,self.lmx,self.cmx,nspc])
            self.check_field_dim('cld_types',np.array(cld_types),[nspc])
            do_scat = True
        
        # Define subpixel dimension
        self.ncid.createDimension('cld',self.cmx)

        # Write cloud fraction
        v = self.ncprf.createVariable('subpix_cf',np.float64,('cld','y','x'))
        v[:] = cf.T

        # Count the number of clouds
        tmp = np.zeros(cf.shape,dtype=np.int)
        tmp[cf > 0.0] = 1
        ncld = np.array(np.sum(tmp,axis=2),dtype=np.int16)
        v = self.ncprf.createVariable('n_subpix',np.int16,('y','x'))
        v[:] = ncld.T
        
        # We are now ready to set the fields
        if(do_lam):
            self.ncprf.variables['LambertianCloudSet'][:] = 1
            v = self.ncprf.createVariable('subpix_pcld',np.float64,('cld','y','x'))
            v[:] = pcld.T
        
        # Check vertical grid ordering
        dl=-1 
        if(self.GridTopToBot): dl=1

        if(do_scat):
            self.ncprf.variables['ScatteringCloudSet'][:] = 1
            for n,varname in zip(range(nspc),cld_types):
                v = self.ncprf.createVariable(varname,np.float64,('cld','z','y','x'))
                v[:] = cod[:,:,::dl,:,n].squeeze().T

        # If succesful set cloud flag
        self.is_prof_cld_set = True
        
    def echo_unset_fields(self):
        
        ''' Echos the fields that have yet to be set by user - 
            These are not necessarily required by splat 

        '''

        print('\nThe following Geolocation fields have not been set:')
        for name in self.geo_is_set.keys():
            if(not self.geo_is_set[name]):
                print(' - '+name)
        
        print('\nThe following Supporting Data fields have not been set:')
        for name in self.aux_is_set.keys():
            if(not self.aux_is_set[name]):
                print(' - '+name)
        
        if(not self.qf_is_set):
            print('\nThe Quality Flag Field has not been set: All data will be assumed good\n')

    def check_field_dim(self, outname, outfld, outdim, dimname=None,checkdef='',checkopen=True,allow_unit_dim=False,strict_idx=[]):
        
        ''' Generic function to check field names
            
            Args:
                outname ('str'): Name of field
                outfld[dim1,..dimn] (numpy float): Field to be output
                outdim[ndim] (numpy int): Output field Dimensions
                dimname[ndim] (optional,str): Names of dimensions
                checkdef(string): Raise exception if field has NOT been defined in netCDF group name = checkdef
                checkopen: Raise exception if file is shut
                allow_unit_dim: If a dimension = 1 let it pass test
                strict_idx: List of indices that cannot have dimension 1 (if allow unit dim set)
            Note:
                Field dimensions size of 1 interpretted as constant across dimension
        '''
        
        # Number of dimensions
        ndim = len(outfld.shape)

        # Check if field has the correct number of dimensions
        if(len(outdim) != ndim):
            raise Exception(outname + ' is the wrong dimension')

        # Check for optional name inputs
        if(dimname is None):
            dimname = []
            for n in range(ndim): dimname.append('Dimension '+str(n))
        
        # Check Dimensions
        if(allow_unit_dim):
            for n in range(len(outdim)):
                if(n in strict_idx): 
                    valid_list = [outdim[n]]
                else:
                    valid_list = [1,outdim[n]]
                if( not outfld.shape[n] in valid_list ): 
                    raise Exception(dimname[n]+' does not match for ' + outname)
        else:
            for n in range(len(outdim)):
                if( outfld.shape[n] !=  outdim[n]): 
                    raise Exception(dimname[n]+' does not match for ' + outname)

        # Check if field is already defined
        if(checkdef != ''):

            if(not any(outname == s for s in self.ncid.groups[checkdef].variables.keys())):
                raise Exception(outname + ' is not a valid level1 field name')
        
        # Check if NetCDF file is open
        if(checkopen):
            if(self.ncid.isopen() == False):
                raise Exception(outname + ' cannot be written as nc file closed')
        
    def add_radiance_band(self,wvl,rad,unit='photons/cm2/s/nm/sr',rad_err=None,rad_flag=None,sza=None,vza=None,aza=None,obsalt=None,use_zlib=False,is_upwelling=True):
        
        ''' Add a radiance band to the level1 output file
            
            ARGS:
                wvl[x,y,w] (numpy float): Wavelength [nm] [See [1]]
                rad[x,y,w] (numpy float): Radiance [units set by "unit" argument]
            OPTIONAL:
                unit (str): Unit of input radiance [See [2]]
                rad_err[x,y,w] (numpy float): Radiance Error Standard Deviation [photons/s/cm2/Sr/nm]
                rad_flag[x,y,w] (numpy int): Radiance Flag [Good=0]
                sza[x,y] (numpy float): If set, usurps SZA from Geolocation group in RTM calculations
                vza[x,y] (numpy float): If set, usurps VZA from Geolocation group in RTM calculations
                aza[x,y] (numpy float): If set, usurps AZA from Geolocation group in RTM calculations
                obsalt[y] (numpy float): If set, usurps OBS. Altitude from Geolocation group in RTM calculations
                use_zlib (bool): Flag to use zlib compression for radiance/wavelength fields
                is_upwelling (bool): upwelling radiance (i.e. observation is looking downward)

            Here x corresponds to the cross-track pixel position
                 y corresponds to the along-track pixel position
                 w corresponds to the wavelength position
            
            Footnotes:
              [1] The along track and across track wavelength dependence can be dropped (in that order)
                  i.e. wvl[x,w] and wvl[w] are also valid inputs for cases where there is no dependence 
                  on the dropped dimension. 
              [2] Valid Units are:
                    'photons/cm2/s/nm/sr': Default unit
                    '1/sr': i.e. value if I0 = 1 for all input TOA Fluxes

             If the radiance flag array is not set then it is assumed that all pixels are valid

        '''

        import numpy as np

        # Get wavelength dimension for band
        wmx = rad.shape[2]
        
        # Determine wavelength type
        nwdim = len(wvl.shape)

        # Check variables to see if they are consistent
        if(nwdim == 3):
            self.check_field_dim('Wavelength', wvl, [self.imx,self.jmx,wmx])
        elif(nwdim == 2):
            self.check_field_dim('Wavelength', wvl, [self.imx,wmx])
        elif(nwdim == 1):
            self.check_field_dim('Wavelength', wvl, [wmx])
        else:
            raise Exception('# of wavelength dimensions must be 1 - 3')
        self.check_field_dim('Radiance'  , rad, [self.imx,self.jmx,wmx])
        if(not rad_err is None):
            self.check_field_dim('RadianceUncertainty', rad_err, [self.imx,self.jmx,wmx])
        if(not rad_flag is None):
            self.check_field_dim('RadianceFlag', rad_flag, [self.imx,self.jmx,wmx])
        if(not sza is None):
             self.check_field_dim('SZA', sza, [self.imx,self.jmx])
        if(not vza is None):
             self.check_field_dim('VZA', vza, [self.imx,self.jmx])
        if(not aza is None):
             self.check_field_dim('AZA', aza, [self.imx,self.jmx])
        if(not obsalt is None):
             self.check_field_dim('ObsAlt', obsalt, [self.jmx])

        # Increment band number if dimension check passed
        self.nband += 1

        # Create wavelength band dimension
        wdim = 'w' + str(self.nband)
        self.ncid.createDimension(wdim,wmx)

        # Define Group
        self.ncrad.append(self.ncid.createGroup('Band'+str(self.nband)))
        
        # Set Up/Downwelling flag
        v = self.ncrad[self.nband-1].createVariable('ViewDirectionIndex',np.int16,('o')) 
        if(is_upwelling):
            v[:] = 1
        else:
            v[:] = 2
        
        # Define Group Type index
        v = self.ncrad[self.nband-1].createVariable('BandTypeIndex',np.int16,('o')) ; v[:] = 1

        # Define fields
        if(nwdim == 3):
            v = self.ncrad[self.nband-1].createVariable('Wavelength',np.float32,(wdim,'y','x'),zlib=use_zlib)
        elif(nwdim == 2):
            v = self.ncrad[self.nband-1].createVariable('Wavelength',np.float32,(wdim,'x'),zlib=use_zlib)
        else:
            v = self.ncrad[self.nband-1].createVariable('Wavelength',np.float32,(wdim),zlib=use_zlib)
        v = self.ncrad[self.nband-1].createVariable('Radiance',np.float32,(wdim,'y','x'),zlib=use_zlib)
        v.unit = unit
        v = self.ncrad[self.nband-1].createVariable('RadianceUncertainty',np.float32,(wdim,'y','x'),zlib=use_zlib)
        v.unit = unit
        self.ncrad[self.nband-1].createVariable('RadianceFlag',np.int16,(wdim,'y','x'),zlib=use_zlib)
        
        # Set Fields
        self.ncrad[self.nband-1].variables['Wavelength'][:] = wvl.T
        self.ncrad[self.nband-1].variables['Radiance'][:] = rad.T
        if(rad_err is None):
            self.ncrad[self.nband-1].variables['RadianceUncertainty'][:] = 0.0
        else:
            self.ncrad[self.nband-1].variables['RadianceUncertainty'][:] = rad_err.T
        if(rad_flag is None):
            self.ncrad[self.nband-1].variables['RadianceFlag'][:] = 0
        else:
            self.ncrad[self.nband-1].variables['RadianceFlag'][:] = rad_flag.T

        # Optional geometries
        # -------------------
        v = self.ncrad[self.nband-1].createVariable('ReplaceGeolocationSZA',np.int16,('o')) ; v[:] = 0
        v = self.ncrad[self.nband-1].createVariable('ReplaceGeolocationVZA',np.int16,('o')) ; v[:] = 0
        v = self.ncrad[self.nband-1].createVariable('ReplaceGeolocationAZA',np.int16,('o')) ; v[:] = 0
        v = self.ncrad[self.nband-1].createVariable('ReplaceGeolocationObsAlt',np.int16,('o')) ; v[:] = 0

        # Solar Zenith angle
        if(not sza is None):
            self.ncrad[self.nband-1].variables['ReplaceGeolocationSZA'][:] = 1
            v = self.ncrad[self.nband-1].createVariable('SZA',np.float64,('y','x'))
            v[:] = sza.T

        # Viewing Zenith angle
        if(not sza is None):
            self.ncrad[self.nband-1].variables['ReplaceGeolocationVZA'][:] = 1
            v = self.ncrad[self.nband-1].createVariable('VZA',np.float64,('y','x'))
            v[:] = vza.T

        # Relative Azimuth angle
        if(not aza is None):
            self.ncrad[self.nband-1].variables['ReplaceGeolocationAZA'][:] = 1
            v = self.ncrad[self.nband-1].createVariable('AZA',np.float64,('y','x'))
            v[:] = aza.T
        
        # Observation Altitude
        if(not obsalt is None):
            self.ncrad[self.nband-1].variables['ReplaceGeolocationObsAlt'][:] = 1
            v = self.ncrad[self.nband-1].createVariable('ObsAlt',np.float64,('y'))
            v[:] = obsalt.T

    def add_directflux_band(self,wvl,dflx,unit='photons/cm2/s/nm',dflx_err=None,dflx_flag=None,sza=None,obsalt=None,use_zlib=False):

        ''' Add a (downwelling) direct flux band to the level1 output file
            
            ARGS:
                wvl[x,y,w] (numpy float): Wavelength [nm] [See [1]]
                dflx[x,y,w] (numpy float): Direct Flux [units set by "unit" argument]
            OPTIONAL:
                unit (str): Unit of input direct flux [See [2]]
                dflx_err[x,y,w] (numpy float): Direct Flux Error Standard Deviation [photons/s/cm2/Sr/nm]
                dflyx_flag[x,y,w] (numpy int): Direct Flux Flag [Good=0]
                sza[x,y] (numpy float): If set, usurps SZA from Geolocation group in RTM calculations
                obsalt[y] (numpy float): If set, usurps OBS. Altitude from Geolocation group in RTM calculations
                use_zlib (bool): Flag to use zlib compression for direct flux/wavelength fields
            Here x corresponds to the cross-track pixel position
                 y corresponds to the along-track pixel position
                 w corresponds to the wavelength position
            
            Footnotes:
              [1] The along track and across track wavelength dependence can be dropped (in that order)
                  i.e. wvl[x,w] and wvl[w] are also valid inputs for cases where there is no dependence 
                  on the dropped dimension. 
              [2] Valid Units are:
                    'photons/cm2/s/nm': Default unit
                    '1': i.e. value if I0 = 1 for all input TOA Fluxes

             If the radiance flag array is not set then it is assumed that all pixels are valid
        '''

        import numpy as np

        # Get wavelength dimension for band
        wmx = dflx.shape[2]
        
        # Determine wavelength type
        nwdim = len(wvl.shape)

        # Check variables to see if they are consistent
        if(nwdim == 3):
            self.check_field_dim('Wavelength', wvl, [self.imx,self.jmx,wmx])
        elif(nwdim == 2):
            self.check_field_dim('Wavelength', wvl, [self.imx,wmx])
        elif(nwdim == 1):
            self.check_field_dim('Wavelength', wvl, [wmx])
        else:
            raise Exception('# of wavelength dimensions must be 1 - 3')
        self.check_field_dim('DirectFlux'  , dflx, [self.imx,self.jmx,wmx])
        if(not dflx_err is None):
            self.check_field_dim('DirectFluxUncertainty', dflx_err, [self.imx,self.jmx,wmx])
        if(not dflx_flag is None):
            self.check_field_dim('DirectFluxFlag', dflx_flag, [self.imx,self.jmx,wmx])
        if(not sza is None):
             self.check_field_dim('SZA', sza, [self.imx,self.jmx])
        if(not obsalt is None):
             self.check_field_dim('ObsAlt', obsalt, [self.jmx])
             
        # Increment band number if dimension check passed
        self.nband += 1

        # Create wavelength band dimension
        wdim = 'w' + str(self.nband)
        self.ncid.createDimension(wdim,wmx)

        # Define Group
        self.ncrad.append(self.ncid.createGroup('Band'+str(self.nband)))
        
        # Define Group Type index
        v = self.ncrad[self.nband-1].createVariable('BandTypeIndex',np.int16,('o')) ; v[:] = 2
        
        # Set Up/Downwelling flag
        v = self.ncrad[self.nband-1].createVariable('ViewDirectionIndex',np.int16,('o'))
        v[:] = 2

        # Define fields
        if(nwdim == 3):
            v = self.ncrad[self.nband-1].createVariable('Wavelength',np.float64,(wdim,'y','x'),zlib=use_zlib)
        elif(nwdim == 2):
            v = self.ncrad[self.nband-1].createVariable('Wavelength',np.float64,(wdim,'x'),zlib=use_zlib)
        else:
            v = self.ncrad[self.nband-1].createVariable('Wavelength',np.float64,(wdim),zlib=use_zlib)
        v = self.ncrad[self.nband-1].createVariable('DirectFlux',np.float64,(wdim,'y','x'),zlib=use_zlib)
        v.unit = unit
        v = self.ncrad[self.nband-1].createVariable('DirectFluxUncertainty',np.float64,(wdim,'y','x'),zlib=use_zlib)
        v.unit = unit
        self.ncrad[self.nband-1].createVariable('DirectFluxFlag',np.int16,(wdim,'y','x'),zlib=use_zlib)
        
        # Set Fields
        self.ncrad[self.nband-1].variables['Wavelength'][:] = wvl.T
        self.ncrad[self.nband-1].variables['DirectFlux'][:] = dflx.T
        if(dflx_err is None):
            self.ncrad[self.nband-1].variables['DirectFluxUncertainty'][:] = 0.0
        else:
            self.ncrad[self.nband-1].variables['DirectFluxUncertainty'][:] = dflx_err.T
        if(dflx_flag is None):
            self.ncrad[self.nband-1].variables['DirectFluxFlag'][:] = 0
        else:
            self.ncrad[self.nband-1].variables['DirectFluxFlag'][:] = dflx_flag.T

        # Optional geometries
        # -------------------
        v = self.ncrad[self.nband-1].createVariable('ReplaceGeolocationSZA',np.int16,('o')) ; v[:] = 0
        v = self.ncrad[self.nband-1].createVariable('ReplaceGeolocationObsAlt',np.int16,('o')) ; v[:] = 0

        # Solar Zenith angle
        if(not sza is None):
            self.ncrad[self.nband-1].variables['ReplaceGeolocationSZA'][:] = 1
            v = self.ncrad[self.nband-1].createVariable('SZA',np.float64,('y','x'))
            v[:] = sza.T

        # Observation Altitude
        if(not obsalt is None):
            self.ncrad[self.nband-1].variables['ReplaceGeolocationObsAlt'][:] = 1
            v = self.ncrad[self.nband-1].createVariable('ObsAlt',np.float64,('y'))
            v[:] = obsalt

    def add_lambertian_alb(self,wvl,alb,cheb_order=None):

        ''' Add a lambertian alebdo band to the level1 output file

            ARGS:
              wvl[w] (numpy float): Wavelength [nm]
              alb[x,y,w] (numpy float): Albedo
            
            OPT ARGS:
              cheb_order (int): If set, will parameterize input albedos
                                using a chebyshev polynomial
            
        '''

        import numpy as np
        from numpy.polynomial.chebyshev import chebfit

        # Wavelength dimension
        wmx = wvl.shape[0]

        # Make sure albedo is consistent with the input dimension
        self.check_field_dim('Albedo', alb, [self.imx,self.jmx,wmx])

        # Increment band number if dimension check passed
        self.nband_brdf += 1

        # Define Group
        self.ncalb.append(self.ncid.createGroup('Surface_Band'+str(self.nband_brdf)))

        # Create wavelength band dimension
        wdim = 'w' + str(self.nband_brdf) + '_alb'
        kdim = 'k' + str(self.nband_brdf) + '_alb'
        pdim = 'p' + str(self.nband_brdf) + '_alb'
        self.ncid.createDimension(wdim,wmx)
        self.ncid.createDimension(kdim,  1)
        self.ncid.createDimension(pdim,  1)

        # Write Wavelength/Kernel Index/Lambertian Flag
        v = self.ncalb[-1].createVariable('Wavelength',np.float64,(wdim))
        v[:] = wvl
        v = self.ncalb[-1].createVariable('kern_idx',np.int16,(kdim))
        v[:] = 1
        v = self.ncalb[-1].createVariable('isLambertian',np.int16,('o'))
        v[:] = 1

        # If not parameterizing
        if(cheb_order is None):
            
            # Write kernel
            v = self.ncalb[-1].createVariable('kern_amp',np.float64,(kdim,wdim,'y','x'))
            v[0,:,:,:] = alb.T
            
            # Use lambertian flag to check whether this is needed - otherwise waste of space
            # v = self.ncrad[-1].createVariable('kern_par',np.float64,(pdim,kdim,wdim,'y','x'))
            # v[0,0,:,:,:] = 0
            
            # Set Chebyshev Flag
            v = self.ncalb[-1].createVariable('isChebyshevParam',np.int16,('o'))
            v[:] = 0
            
        else:
            
            # Create wavelength band dimension
            cdim = 'w' + str(self.nband) + '_cheb'
            self.ncid.createDimension(cdim,cheb_order+1)

            wmin = wvl.min() ; wmax = wvl.max()
            x = 2.0*(wvl - wmin)/(wmax-wmin) -1.0

            # Define chebyshev 
            v = self.ncalb[-1].createVariable('kern_amp',np.float64,(kdim,cdim,'y','x'))
            alb_reshape = alb.T.reshape([wmx,self.jmx*self.imx])

            coeff = chebfit(x,alb_reshape,cheb_order)
            v[:] = coeff[0:cheb_order+1,:].reshape([cheb_order+1,self.jmx,self.imx])
            v.wmin = wmin
            v.wmax = wmax

            # Set Chebyshev Flag
            v = self.ncalb[-1].createVariable('isChebyshevParam',np.int16,('o'))
            v[:] = 1

    def close(self,verbose=True):
        
        # Save number of bands
        self.ncid.variables['NumberOfBands'][:] = self.nband

        # Echo fields that have not been set
        if(verbose):
            self.echo_unset_fields()

        # Close output netCDF
        self.ncid.close()

def atan_idl( y, x ):
    
    import numpy as np

    arr = np.zeros(x.shape)
    idx = np.where( x == 0 )
    if( arr[idx].shape[0] > 0 ):
        arr[idx] = np.pi/2.0
    idx = np.where( x != 0 )
    if( arr[idx].shape[0] > 0 ):
        arr[idx] = np.arctan(y/x)
    
    # Check quadrants
    idx = np.where ( (y > 0) & (x < 0) )
    if( arr[idx].shape[0] > 0 ):
        arr[idx] = np.pi- arr[idx]
    idx = np.where ( (y < 0) & (x < 0) )
    if( arr[idx].shape[0] > 0 ):
        arr[idx] = arr[idx]-np.pi
    
    return arr
    
class ViewGeoObj(object):

    def __init__(self):
        
        import numpy as np
        from scipy.interpolate import CubicSpline
        
        # Define some parameters for zensun
        self.nday=np.array([  1.0,   6.0,  11.0,  16.0,  21.0,  26.0,  31.0,  36.0,  41.0,  46.0,\
                             51.0,  56.0,  61.0,  66.0,  71.0,  76.0,  81.0,  86.0,  91.0,  96.0,\
                            101.0, 106.0, 111.0, 116.0, 121.0, 126.0, 131.0, 136.0, 141.0, 146.0,\
                            151.0, 156.0, 161.0, 166.0, 171.0, 176.0, 181.0, 186.0, 191.0, 196.0,\
                            201.0, 206.0, 211.0, 216.0, 221.0, 226.0, 231.0, 236.0, 241.0, 246.0,\
                            251.0, 256.0, 261.0, 266.0, 271.0, 276.0, 281.0, 286.0, 291.0, 296.0,\
                            301.0, 306.0, 311.0, 316.0, 321.0, 326.0, 331.0, 336.0, 341.0, 346.0,\
                            351.0, 356.0, 361.0, 366.0])
        
        self.eqt=np.array([ -3.23, -5.49, -7.60, -9.48,-11.09,-12.39,-13.34,-13.95,-14.23,-14.19,\
                           -13.85,-13.22,-12.35,-11.26,-10.01, -8.64, -7.18, -5.67, -4.16, -2.69,\
                            -1.29, -0.02,  1.10,  2.05,  2.80,  3.33,  3.63,  3.68,  3.49,  3.09,\
                             2.48,  1.71,  0.79, -0.24, -1.33, -2.41, -3.45, -4.39, -5.20, -5.84,\
                            -6.28, -6.49, -6.44, -6.15, -5.60, -4.82, -3.81, -2.60, -1.19,  0.36,\
                             2.03,  3.76,  5.54,  7.31,  9.04, 10.69, 12.20, 13.53, 14.65, 15.52,\
                            16.12, 16.41, 16.36, 15.95, 15.19, 14.09, 12.67, 10.93,  8.93,  6.70,\
                             4.32,  1.86, -0.62, -3.23])

        self.dec=np.array([-23.06,-22.57,-21.91,-21.06,-20.05,-18.88,-17.57,-16.13,-14.57,-12.91,\
                           -11.16, -9.34, -7.46, -5.54, -3.59, -1.62,  0.36,  2.33,  4.28,  6.19,\
                             8.06,  9.88, 11.62, 13.29, 14.87, 16.34, 17.70, 18.94, 20.04, 21.00,\
                            21.81, 22.47, 22.95, 23.28, 23.43, 23.40, 23.21, 22.85, 22.32, 21.63,\
                            20.79, 19.80, 18.67, 17.42, 16.05, 14.57, 13.00, 11.33,  9.60,  7.80,\
                             5.95,  4.06,  2.13,  0.19, -1.75, -3.69, -5.62, -7.51, -9.36,-11.16,\
                           -12.88,-14.53,-16.07,-17.50,-18.81,-19.98,-20.99,-21.85,-22.52,-23.02,\
                           -23.33,-23.44,-23.35,-23.06])
        
        # Create spline objects
        self.cs_eqt = CubicSpline( self.nday, self.eqt )
        self.cs_dec = CubicSpline( self.nday, self.dec )
         
    def zensun(self,day,time,lat,lon,local=False):
        
        import numpy as np
        
        ####################################
        # compute the subsolar coordinates #
        ####################################
        
        # Fractional day number wirht 1 Jan 12 am = 1
        tt = ( ( np.fix(day)+time/24.-1 ) % 365.25 ) + 1.
        
        #
        eqtime = self.cs_eqt( tt ) / 60.0
        decang = self.cs_dec( tt )
        
        latsun = decang
        
        if( local ):
            #
            lonorm=((lon + 360 + 180 ) % 360 ) - 180.
            tzone=np.fix((lonorm+7.5)/15)
            index = np.where( lonorm < 0 )
            if( lonorm[index].shape[0] > 0 ):
                tzone[index] = np.fix((lonorm[index]-7.5)/15)
            ut=(time-tzone+24.) % 24.
            noon=tzone+12.-lonorm/15.
        else:
            # 
            ut=time
            noon=12.-lon/15.
        
        lonsun=-15.*(ut-12.+eqtime)

        # compute the solar zenith, azimuth and flux multiplier
        dtor = np.pi / 180.0
        t0=(90.-lat)*dtor                            # colatitude of point
        t1=(90.-latsun)*dtor                         # colatitude of sun

        p0=lon*dtor                                  # longitude of point
        p1=lonsun*dtor                               # longitude of sun

        zz=np.cos(t0)*np.cos(t1)+np.sin(t0)*np.sin(t1)*np.cos(p1-p0) # up          \
        xx=np.sin(t1)*np.sin(p1-p0)                                  # east-west    > rotated coor
        yy=np.sin(t0)*np.cos(t1)-np.cos(t0)*np.sin(t1)*np.cos(p1-p0) # north-south /
        
        
        self.saa =atan_idl(xx,yy)/dtor 
        self.sza=np.arccos(zz)/dtor                        # solar zenith

        rsun=1.-0.01673*np.cos(.9856*(tt-2.)*dtor)      # earth-sun distance in AU
        self.solfac=zz/np.power(rsun,2)                 # flux multiplier
        
        angsun = 0.
        arg=-(np.sin(angsun)+np.cos(t0)*np.cos(t1))/(np.sin(t0)*np.sin(t1))
        self.sunrise = np.zeros(arg.shape)  
        self.sunset  = np.ones(arg.shape)*24. 
        index = np.where(abs(arg) < 1.0)
        if( arg[index].shape[0] > 0 ):
            dtime=np.arccos(arg[index])/(dtor*15)
            self.sunrise[index]=noon-dtime-eqtime[index]
            self.sunset[index] =noon+dtime-eqtime[index]
            
    def zenview(self,lonp, latp, lonss, latss, h, re):
        
        import numpy as np
        
        # Degrees to radians
        DtoR = np.pi / 180.0
        
        # sin(angular radius of Earth at height h)
        srho = re/(re+h)
        
        deltaL = abs(lonss-lonp)
        cdeltaL = np.cos(deltaL * DtoR)
        clatss = np.cos(latss * DtoR)
        slatss = np.sin(latss * DtoR)
        clatp = np.cos(latp * DtoR)
        slatp = np.sin(latp * DtoR)
        
        # Find lambda, central angle of great circle arc connecting P and SSP.
        # use Law of Cosines for spherical triangle with vertices P, SSP, and North Pole.
        # sides are central angles (great circle arcs) 90-LatP, 90-LatSS, and Lambda.
        # Law of Cosines: cos(c) = cos(a) cos(b) +sin(a) sin(b) cos(C),
        # where a, b, c are the sides and C is the corner angle opposite side c.
        
        # cos(lambda)
        clambda = slatss * slatp + clatss * clatp * cdeltaL
        
        # sin(lambda) 
        slambda = np.sin(np.arccos(clambda))
        
        
        # cos phiv (Phi_V is azimuth of satellite measured from North at target P).
        # Use Law of Cosines on Spherical Triangle formed by P, North Pole, SSP.
        
        cphiv = (slatss - slatp * clambda) / ( clatp * slambda)
        if( cphiv > 1.0 ):
            cphiv = 1.0
        if( cphiv < -1.0 ):
            cphiv = -1.0
            
        phiv = np.arccos(cphiv)
        
        # tan eta
        
        taneta = srho * slambda / (1.0 - srho * clambda)
        eta = np.arctan(taneta)
        
        # cos epsilon
        
        ceps = np.sin(eta)/srho
        eps = np.arccos(ceps)
        
        self.vaa = phiv / DtoR
        if( lonp-lonss > 0.0 ):
            self.vaa = 360.0 - self.vaa
        self.vza = eps / DtoR
        
        # Check for spacecraft below horizon at target
        
        lambda1 = np.arccos(clambda) / DtoR
        lambda0 = np.arccos(srho) / DtoR
        if( lambda1 > lambda0 ):
            #print, 'WARNING: SPACECRAFT BELOW HORIZON AT TARGET'
            #print, 'Lambda  (Central Angle between Target and SSP) = ', lambda
            #print, 'Lambda0 (Central Angle Visible to Spacecraft)  = ', lambda0
            self.vza = -self.vza
        
        
        self.vza = 90.0 - self.vza

    def compute_geom(self, lon, lat, satlon, satlat, satalt, \
                         earthradius, jday, utc):
         
        import numpy as np
        
        # Zensun requires np arrays
        self.lon    = np.array( [lon]  )
        self.lat    = np.array( [lat]    )
        self.satlon = np.array( [satlon] )
        self.satlat = np.array( [satlat] )
        self.satalt = np.array( [satalt] )
        self.earthradius = np.array( [earthradius] )
        self.jday   = np.array([jday])
        self.utc    = np.array([utc] )
        
        # Compute viewing geom
        self.zenview( self.lon, self.lat, self.satlon, self.satlat, \
                      self.satalt, self.earthradius)
            
        # Compute solar geometry
        self.zensun(self.jday, self.utc, self.lat, self.lon)
            
        # Compute relative azimuth
        self.aza = self.vaa - (180. + self.saa)
        if( self.aza < 0.0 ):
            self.aza = self.aza + 360.0
        if( self.aza > 360.0 ):
            self.aza = self.aza - 360.0

def noise_model(wvl,rad,I=2e13,A=12.56637,dt=1.0/7.0,dx=0.2,dy=-1.0,H=460.0,eta=0.65, dx0=1,dy0=-1.0,Nr=30.0,Nd_per_s=2500.0,dl=-1.0):

        ''' SNR Model 

        ARGS:
          wvl[w] (numpy float): wavelength grid
          rad[w] (numpy float): Radiance (photons/nm/cm2/s)
        OPT ARGS:
          I        - Reference radiance [photons/cm2/s/nr/Sr]
          A        - Telescope area   [cm^2]
          dt       - Integration time [s]
          dx       - Native pixel size [km]
          dy       - Native pixel size [km]
          H        - Orbit height [km]
          eta      - Instrument efficiency
          dx0      - Target cross track position
          dy0      - ?
          Nr       - Readout rms electron/pixel/readout
          Nd_per_s - dark current, electrons per pixel per exposure

          w indicates the wavelength dimension

        '''
        
        import numpy as np

        # Get sampling from observation vector input
        nwvl = len(wvl)
        dlambda = np.mean(wvl[1:]-wvl[0:nwvl-1])

        # Set default values if keywords not set
        if( dy < 0.0 ):
            dy = dx
        if( dy0 < 0.0 ):
            dy0 = dt/(1.0/7.0)
        if( dl < 0.0 ):
            dl = dlambda

        # Footprint solid angle [Sr]
        Omega = (dx/H)*(dy/H)

        # Number of along track averaging
        n1 = dy0/7.0/dt

        # Number of cross track averaging
        n = dx0/dx

        # Signal
        S = I*A*dt*dlambda*Omega*eta

        # Dark current, electrons/pixel/exposure
        Nd = Nd_per_s*dt

        # Noise
        N = np.sqrt( (np.power(Nr,2)+Nd+S)/n/n1 )
        SNRe_shot = np.sqrt(S*n*n1)
        SNRe = S/N

        # Calculate radiance needed for SNR in photon units
        tmpS = rad*A*dt*dl*Omega*eta
        tmpN = np.sqrt( (np.power(Nr,2)+Nd+tmpS)/n/n1 )

        # Now return information
        output = {}
        output['wsnr']        = tmpS/tmpN
        output['wsnr_single'] = tmpS/np.sqrt(np.power(Nr,2)+Nd+tmpS)
        output['wsnr_shot']   = SNRe_shot*np.sqrt(rad/I*dl/dlambda)
        output['A']           = A
        output['dx']          = dx
        output['H']           = H

        return output
