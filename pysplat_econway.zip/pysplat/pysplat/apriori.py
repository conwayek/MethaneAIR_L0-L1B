# -*- coding: iso-8859-1 -*-
class profile(object):
    
    '''
    The profile class used in the apriori climatology input to SPLAT-VLIDORT
    
    The profile class type covers the case where we match observation times to 
    to the closest point in time in the a priori. 
    
    Note:
        (1) For using climatological priors, use the climatology class.
        (2) Indices are transposed when writing to disk to account for FORTRAN 
            index order
        (3) StateTypes for profile variables
              1 - Profile Variable
              2 - GDF
              3 - EXP
              4 - BOX
        

    Attributes:
        imx ('int'): Longitudinal Dimension of a priori profiles
        jmx ('int'): Latitudinal Dimension of a priori profiles
        lmx ('int'): Longitudinal Dimension of a priori profiles
        tmx ('int'): Time Dimension of a priori profiles
    '''
    
    def __init__(self,outfile,xmid,ymid,time,xedge,yedge,pedge,Tedge,zsurf,rh=None,eta=None,eta_trop=None,ptrop=None):
        
        '''Initialize profile class type for use in SPLAT-VLIDORT

        The __init__ method takes the minimum set of arguments needed to 
        describe the apriori profiles, as described in the Args section. 
        
        Note:
            SPLAT-VLIDORT expects profile from top to bottom of atmosphere
            The class will automatically flip the indices based on the input 
            pressure edges. 

        Args:
            outfile ('str'): Output a priori file name (netCDF)
            xmid[x] ('float'): Longitude Midpoints [degrees]
            ymid[y] ('float'): Latitude Midpoints [degrees]
            xedge[x+1] ('float'): Longitude Edges [degrees]
            yedge[y+1] ('float'): Latitude Edges [degrees]
            time[t] ('float'): Time [GEOS-Tau - Hours since 1/1/1985, 00:00:00 UTC]
            pedge[x,y,z+1,t] ('float'): Pressure Edges at grid box center [hPa]
            Tedge[x,y,z+1,t] ('float'): Temperature Edges at grid box center [K]
            zsurf[x,y] ('float'): Surface Altitude [km]
            rh[x,y,z,t] ('float'): Relative Humidity [%] [Defaults to 0 if not set]
            where the dimensions are - 
                x - Longitude
                y - Latitude
                z - Altitude
                t - Time

        Opt Args:
            eta[z+1,:2] ('float'): eta grid coefficients
            eta_trop[z+1,:3] ('float'): eta-tropopause grid coefficients
            ptrop[x,y,t] ('float'): Tropopause Pressure [hPa]

                - Only one of eta and eta_trop can be set
                - ptrop must be set when using eta_trop
        
            ----------------------------
            Note on the eta coefficients
            ----------------------------

            Let psurf[x,y] be the surface pressure at gridbox x,y

            The pressure edge at level l will be
            pedge[x,y,l] = eta[l,0] + psurf[x,y]*eta[l,1]

            ---------------------------------
            Note on the eta_trop coefficients
            ---------------------------------
            
            Let ptrop[x,y] be the tropopause pressure at gridbox x,y

            The pressure edge at level l will be
            pedge[x,y,l] = eta[l,0] + ptrop[x,y]*eta[l,1] + (psurf[x,y]-ptrop[x,y])*eta[l,2]
            
        '''
        
        import numpy as np
        from netCDF4 import Dataset
        
        isEta = True ; isEtaTrop = True
        if( eta is None ): isEta = False
        if( eta_trop is None): isEtaTrop = False
        
        # Check that both eta and eta_trop not set
        if(isEta and isEtaTrop):
            raise Exception('eta and eta_trop both set (can only set 1)')
        
        # Check tropopause pressure is set when using eta_trop
        if(isEtaTrop and ptrop is None):
            raise Exception('ptrop must be set when using eta_trop')

        # Get dimensions
        self.imx = xmid.shape[0]
        self.jmx = ymid.shape[0]
        self.tmx = time.shape[0]


        # Get vertical dimension and check order
        if(isEta):
            self.eta = eta
            self.lmx = eta.shape[0]-1
            self.GridTopToBot = self.eta[0,1] < self.eta[1,1]
        elif(isEtaTrop):
            self.eta = eta_trop
            self.lmx = eta_trop.shape[0]-1
            self.GridTopToBot = self.eta[0,2] < self.eta[1,2]
        else:
            self.lmx = pedge.shape[2]-1
            self.GridTopToBot = pedge[0,0,0,0] < pedge[0,0,1,0]
        
        # Force grid from TOA -> Surface
        dl=-1 
        if(self.GridTopToBot): dl=1

        # Open file for write
        self.ncid = Dataset(outfile,'w')
        
        # Create output file dimensions
        self.ncid.createDimension('i',self.imx)
        self.ncid.createDimension('j',self.jmx)
        self.ncid.createDimension('ie',self.imx+1)
        self.ncid.createDimension('je',self.jmx+1)
        self.ncid.createDimension('l',self.lmx)
        self.ncid.createDimension('le',self.lmx+1)
        self.ncid.createDimension('t',self.tmx)
        self.ncid.createDimension('o',1)
        self.ncid.createDimension('p1',1)
        self.ncid.createDimension('p2',2)
        self.ncid.createDimension('p3',3)
        
        # Create Variables x,y,t
        self.ncid.createVariable('xmid',np.float64,('i')) ; self.ncid.variables['xmid'][:] = xmid
        self.ncid.createVariable('ymid',np.float64,('j')) ; self.ncid.variables['ymid'][:] = ymid
        self.ncid.createVariable('xedge',np.float64,('ie')) ; self.ncid.variables['xedge'][:] = xedge
        self.ncid.createVariable('yedge',np.float64,('je')) ; self.ncid.variables['yedge'][:] = yedge
        self.ncid.createVariable('time',np.float64,('t')) ; self.ncid.variables['time'][:] = time
        self.ncid.createVariable('zsurf',np.float64,('j','i')) ; self.ncid.variables['zsurf'][:,:] = zsurf.T
        
        # Descriptions for potential state vector variables
        self.state_descript = {}
        
        # Vertical grid 
        self.ncid.createVariable('VerticalGridType',np.int16,('o'))
        if(isEta or isEtaTrop):
            psurf = np.zeros((self.imx,self.jmx,self.tmx))
            if(self.GridTopToBot):
                for t in range(self.tmx):
                    psurf[:,:,t] = pedge[:,:,-1,t]
            else:
                for t in range(self.tmx):
                    psurf[:,:,t] = pedge[:,:,0,t]
            self.write_nc_fld('psurf',psurf,['i','j','t'])
            self.write_nc_fld('ap',self.eta[::dl,0].squeeze(),['le'])
            self.write_nc_fld('bp',self.eta[::dl,1].squeeze(),['le'])
            if(isEta):
                self.ncid.variables['VerticalGridType'][0] = 2
            else:
                self.ncid.variables['VerticalGridType'][0] = 3
                self.write_nc_fld('cp',self.eta[::dl,2].squeeze(),['le'])
                self.write_nc_fld('ptrop',ptrop,['i','j','t'])
        else:
            self.write_nc_fld('pedge',pedge[:,:,::dl,:],['i','j','le','t'])
            self.ncid.variables['VerticalGridType'][0] = 1
        
        # Write temperature
        self.write_nc_fld('Tedge',Tedge[:,:,::dl,:],['i','j','le','t'])
        
        # Write RH
        if(rh is None):
            rh_tmp = np.zeros((1,1,1,1))
            self.write_nc_fld('RH',rh_tmp,['i','j','l','t'])
        else:
            self.write_nc_fld('RH',rh,['i','j','l','t'])
        
        # Temperature @ layer midpoint covariance
        self.ncid.createVariable('Tmid_ErrorCovarType',np.int16,('o'))
        self.ncid.createVariable('Tmid_StateType',np.int16,('o'))
        self.state_descript['Tmid'] = 'Temperature at grid box midpoint [Error Unit: K]'
        
        # Initialize
        self.ncid.variables['Tmid_ErrorCovarType'][:] = -1
        self.ncid.variables['Tmid_StateType'][:] = 1
        
        # Surface pressure covariance
        self.ncid.createVariable('psurf_ErrorCovarType',np.int16,('o'))
        self.ncid.createVariable('psurf_StateType',np.int16,('o'))
        self.state_descript['psurf'] = 'Surface pressure [Error Unit: hPa]'
        
        # Initialize
        self.ncid.variables['psurf_ErrorCovarType'][:] = -1
        self.ncid.variables['psurf_StateType'][:] = -1
        
        # Surface pressure covariance
        self.ncid.createVariable('Tshift_ErrorCovarType',np.int16,('o'))
        self.ncid.createVariable('Tshift_StateType',np.int16,('o'))
        self.state_descript['Tshift'] = 'Temperature profile shift uncertainty [K]'
        
        # Initialize
        self.ncid.variables['Tshift_ErrorCovarType'][:] = -1
        self.ncid.variables['Tshift_StateType'][:] = -1
        
        # Optional footprint variables
        self.opt2d_descript= {} ; self.opt2d_dtype = {} ; self.opt2d_default = {}
        self.opt2d_default['wdir'   ] = 1.0 ; self.opt2d_dtype['wdir'   ] = np.float64 ; self.opt2d_descript['wdir'   ] = 'Wind direction [degrees C/W from north]'
        self.opt2d_default['wspd'   ] = 5.0 ; self.opt2d_dtype['wspd'   ] = np.float64 ; self.opt2d_descript['wspd'   ] = 'Surface wind speed [m/s]'
        self.opt2d_default['chphyl' ] = 0.0 ; self.opt2d_dtype['chphyl' ] = np.float64 ; self.opt2d_descript['chphyl' ] = 'Ocean chlorophyll concentration [mg/m3]'
        self.opt2d_default['ocsal'  ] = 0.0 ; self.opt2d_dtype['ocsal'  ] = np.float64 ; self.opt2d_descript['ocsal'  ] = 'Ocean Salinity [mg/m3]'
        self.opt2d_default['snwdpth'] = 0.0 ; self.opt2d_dtype['snwdpth'] = np.float64 ; self.opt2d_descript['snwdpth'] = 'Snow Depth [m]'
        self.opt2d_default['snwfrc' ] = 0.0 ; self.opt2d_dtype['snwfrc' ] = np.float64 ; self.opt2d_descript['snwfrc']  = 'Snow Cover Fraction'
        self.opt2d_default['snwage' ] = 0.0 ; self.opt2d_dtype['snwage' ] = np.float64 ; self.opt2d_descript['snwage' ] = 'Snow age [days]'
        self.opt2d_default['cftot'  ] = 0.0 ; self.opt2d_dtype['cftot'  ] = np.float64 ; self.opt2d_descript['cftot'  ] = 'Total cloud fraction'
        self.opt2d_default['ncpix'  ] =   0 ; self.opt2d_dtype['ncpix'  ] = np.int16   ; self.opt2d_descript['ncpix'  ] = 'Number of cloud subpixels'
        self.opt2d_default['pcld'   ] = 500.; self.opt2d_dtype['pcld'   ] = np.float64 ; self.opt2d_descript['pcld'   ] = 'Cloud Top Pressure for lambertian case [hPa]'
        
        # Valid pressure adjustment options
        self.valid_sigma = ['BACKGROUND','SIGMA','HYBRID']

    def check_field_dim( self, outname, outfld, outdim, dimname=None, strict_idx=[],checkdef=True ):
        
        ''' Generic function to check field names
            
            Args:
                outname ('str'): Name of field
                outfld[dim1,..dimn] (numpy float): Field to be output
                outdim[ndim] (numpy int): Output field Dimensions
                dimname[ndim] (optional,str): Names of dimensions
                strict_idx[:] (optional,logical): Don't check if dimension is 1 for indices in list
                checkdef: Raise exception if field has already been defined in netCDF file
            Note:
                Field dimensions size of 1 interpretted as constant across dimension
        '''
        
        # Number of dimensions
        ndim = len(outfld.shape)

        # Check if field has the correct number of dimensions
        if(len(outdim) != ndim):
            raise Exception(outname + ' is the wrong dimension')

        # Check for optional name inputs
        if(dimname is None):
            dimname = []
            for n in range(ndim): dimname.append('Dimension '+str(n))
        
        # Check Dimensions
        for n in range(ndim):

            # Check if index is strict
            if any(n in s for s in strict_idx):
                if( outfld.shape[n] !=  outdim[n] ):
                    raise Exception(dimname[n]+' does not match for ' + outname)
            else:
                if( outfld.shape[n] !=  outdim[n] and outfld.shape[n] != 1 ): 
                    raise Exception(dimname[n]+' does not match for ' + outname)

        # Check if field is already defined
        if( checkdef and any(outname == s for s in self.ncid.variables.keys())):
            raise Exception(outname + 'has already been defined')
        
        # Check if NetCDF file is open
        if(self.ncid.isopen() == False):
            raise Exception(outname + 'cannot be written as nc file closed')
    
    def add_earth_bulk_composition(self,co2=408.0e-6):
        
        ''' Add default global average gas composition
            
            Optional Argument:
                co2: CO2 concentration [v/v]
        '''
        
        import numpy as np
        
        vmr = np.zeros((1,1,1,1))
        
        # Add Major Component gases
        vmr[0,0,0,0] = 0.78084 ; self.add_profile_var('N2', vmr)
        vmr[0,0,0,0] = 0.20946 ; self.add_profile_var('O2', vmr)
        vmr[0,0,0,0] = 0.00934 ; self.add_profile_var('Ar', vmr)
        vmr[0,0,0,0] = co2     ; self.add_profile_var('CO2',vmr)
        
        # Echo added gases
        print('Added N2,O2,Ar, and CO2 to climatology')
        
    def add_footprint_var(self, name, var, dtype=None):

        ''' Add a footprint variable to output array

            Args:
                name ('str'): Name of field
                var[x,y,t] (numpy float): Field
                where the dimensions are - 
                    x - Longitude
                    y - Latitude
                    t - Time
        '''

        import numpy as np
        
        if(dtype is None):
            dtype = np.float64

        # Correct dimensions for output field
        outdim = [self.imx,self.jmx,self.tmx]

        # Check field dimensions
        self.check_field_dim(name,var,outdim)

        # Determine field dimensions
        outdim = ['i','j','t']
        for n in range(3):
            if( var.shape[n] == 1 ): outdim[n] = 'o'
        
        # Define field
        self.ncid.createVariable(name,dtype,tuple(outdim[::-1]))
        self.ncid.createVariable(name+'_ErrorCovarType',np.int16,('o'))
        self.ncid.createVariable(name+'_StateType',np.int16,('o'))

        # Write field
        self.ncid.variables[name][:,:,:] = var[:,:,:].T

        # Initialize Error Covariance Type
        self.ncid.variables[name+'_ErrorCovarType'][:] = -1
        self.ncid.variables[name+'_StateType'][:] = 0 # StateType = 0 => Footprint

        # Update state description list
        if( any(name == s for s in self.opt2d_descript.keys()) ):
            self.state_descript[name] = self.opt2d_descript[name]
        else:
            self.state_descript[name] = ''
    
    def add_profile_var(self, name, var, default_sigma='BACKGROUND',bgrd=None):
        
        ''' Add profile variable to output array

            Note:
                x,y,t dimensions can be skipped - to do so replace the size of the field 
                in the corresponding dimension by a size of 1. 
                
                e.g. for a zonal climatology
                var[x,y,z,t] -> var[1,y,z,t]
                
                And for constant VMRS (e.g. N2)
                var[x,y,z,t] -> var[1,1,z,1]
            
            Args:
                name ('str'): Name of field
                var[x,y,z,t] (numpy float): Trace gas or aerosol profile
            Optional Args:

                default_sigma: This is the profile adjustment method to employ when 
                               correcting for a surface pressure/terrain height change
                               There are 3 Options:
                               = 'BACKGROUND' (default): Profile is treated as background
                                 In this case after a terrain adjustment the original 
                                 profile is interpolated to the new vertical grid in 
                                 pressure space
                               = 'SIGMA': The layer vertical column density between the original 
                                 grid and new vertical grids is preserved
                               = 'HYBRID': A combination of BACKGROUND and SIGMA
                                  The bgrd argument must be specified - This will be subject to 
                                  the background adjustment. The remaining (var-bgrd) component 
                                  will be subject to the SIGMA adjustment

                bgrd[x,y,z,t] (optional, numpy float): 'Background' - will not be
                    subject to hypsometric adjustment when layer pressures are adjusted 
                    to a surface pressure change
                
                where the dimensions are - 
                    x - Longitude
                    y - Latitude
                    z - Altitude
                    t - Time

        '''
        
        import numpy as np
        
        # Correct dimensions for output field
        outdim = [self.imx,self.jmx,self.lmx,self.tmx]

        # Check field dimensions
        self.check_field_dim(name,var,outdim)

        # Check if set default sigma is valid
        if( not  any(default_sigma == s for s in self.valid_sigma)):
            raise Exception(default_sigma + ' is not a valid default_sigma choice')
        
        # Check for background write
        if(default_sigma == 'HYBRID'):

            # Check field is defined
            if(bgrd is None):
                raise Exception('default sigma is set to HYBRID but bgrd is not defined!')
            # Set 
            write_bgrd =  True
        else:
            write_bgrd = False

        # Check Background dimensions
        if(write_bgrd):
            self.check_field_dim(name+'_Background',bgrd,outdim)

        # Determine field dimensions
        outdim = ['i','j','l','t']
        for n in range(4):
            if( var.shape[n] == 1 ): outdim[n] = 'o'
        
        # Force grid from TOA -> Surface
        dl=-1 
        if(self.GridTopToBot): dl=1 
        
        # Define field
        self.ncid.createVariable(name,np.float64,tuple(outdim[::-1]))
        self.ncid.createVariable(name+'_ErrorCovarType',np.int16,('o'))
        self.ncid.createVariable(name+'_StateType',np.int16,('o'))
        self.ncid.createVariable(name+'_SigmaAdjustType',np.int16,('o'))

        # Write field
        self.ncid.variables[name][:,:,:,:] = var[:,:,::dl,:].T

        # Initialize Error Covariance Type
        self.ncid.variables[name+'_ErrorCovarType'][:] = -1
        self.ncid.variables[name+'_StateType'][:] = 1 # StateType = 1 => Profile

        # Set Profile adjustment type
        ct = 0
        for signame in self.valid_sigma:
            ct+=1
            if(default_sigma == signame):
                self.ncid.variables[name+'_SigmaAdjustType'][:] = ct

        # Create background if necessary
        if(write_bgrd):

            # Determine field dimensions for background
            outdim = ['i','j','l','t']
            for n in range(4):
                if( bgrd.shape[n] == 1 ): outdim[n] = 'o'
            
            # Define and write field
            self.ncid.createVariable(name+'_Background',np.float64,tuple(outdim[::-1]))
            self.ncid.variables[name+'_Background'][:,:,:,:] = bgrd[:,:,::dl,:].T

        self.state_descript[name] = 'Profile Variable'
    
    def add_cloud_fraction(self,cf):
        
        ''' Sets cloud fraction 
          
           Args:
                cf[x,y,t] (numpy float): Geometric cloud fraction for grid box
           
        '''
        
        import numpy as np
        
        # First compute the number of cloudy pixels
        ncpix = np.zeros(cf.shape,dtype=np.int16)
        ncpix[cf > 0.0] = 1
        
        # write the fields
        self.add_footprint_var('cftot',cf,dtype=np.float64)
        self.add_footprint_var('ncpix',ncpix,dtype=np.int16)
        
    def write_nc_fld(self,name,var,outdim,dtype=None):
        
        import numpy as np

        if(dtype is None): dtype=np.float64

        # Get dimensions
        outdim_mod = outdim[:]
        ndim = len(outdim_mod)

        # Find unit dimension
        for n in range(ndim):
            if( var.shape[n] == 1 ): outdim_mod[n] = 'o'
        
        # Create the field (transpose dimensions for FORTRAN order)
        self.ncid.createVariable(name,dtype,tuple(outdim_mod[::-1])) #tuple(outdim[::-1]))

        # Write field
        self.ncid.variables[name][:] = var.T

    def add_gdf_aerosol(self, name, aod, zmin, zmax, pkhght, pkwdth):
        
        ''' Add profile parameterized by gen. distr. function to output array

            Args:
                name ('str'): Name of trace gas
                aod[x,y,t] (numpy float): Column aerosol optical depth
                zmin[x,y,t] (numpy float): Minimum Height (km)
                zmax[x,y,t] (numpy float): Maximum Height (km)
                pkhght[x,y,t] (numpy float): Peak Height (km)
                pkwdth[x,y,t] (numpy float): Peak Width (km)

                where the dimensions are - 
                    x - Longitude
                    y - Latitude
                    t - Time

        '''
        import numpy as np

        # Correct dimensions for output field
        outdim = [self.imx,self.jmx,self.tmx]

        # Check field dimensions
        self.check_field_dim(name,aod,outdim)
        self.check_field_dim(name+'_zmin',zmin,outdim)
        self.check_field_dim(name+'_zmax',zmax,outdim)
        self.check_field_dim(name+'_pkh',pkhght,outdim)
        self.check_field_dim(name+'_pkw',pkwdth,outdim)

        # Output field dimensions
        outdim = ['i','j','t']

        # Write fields
        self.write_nc_fld(name,aod,outdim)
        self.write_nc_fld(name+'_zmin',zmin,outdim)
        self.write_nc_fld(name+'_zmax',zmax,outdim)
        self.write_nc_fld(name+'_pkh',pkhght,outdim)
        self.write_nc_fld(name+'_pkw',pkwdth,outdim)

        # Initialize Error Covariance Type
        self.ncid.createVariable(name+'_ErrorCovarType',np.int16,('o'))
        self.ncid.createVariable(name+'_StateType',np.int16,('o'))
        self.ncid.variables[name+'_ErrorCovarType'][:] = -1
        self.ncid.variables[name+'_StateType'][:] = 2 # StateType = 2 => GDF

        self.state_descript[name] = 'Aerosol profile parameterized with GDF'

    def add_gdf_prior(self, name, aod_err, pkhght_err, pkwdth_err):
    
        ''' Add error associated with profile parameterized by an box function to output array

            Args:
                name ('str'): Name of trace gas
                aod_err[x,y,t] (numpy float): Column aerosol optical error
                pkhght_err[x,y,t] (numpy float): Peak Height error (km)
                pkwdth_err[x,y,t] (numpy float): Peak Width error (km)
                zmin[x,y,t] (numpy float): Minimum Height (km)
                zmax[x,y,t] (numpy float): Maximum Height (km)

                where the dimensions are -
                    x - Longitude
                    y - Latitude
                    t - Time
        '''
        
        import numpy as np
        
        # Check that the profile field has been defined
        priorname = name+'_ErrorCovarType'
        
        if not any(priorname in s for s in self.ncid.variables.keys()):
            raise Exception('Cannot add prior as '+name+' has not been defined')
        
        # This should only apply for box profile variables
        if(self.ncid.variables[name+'_StateType'][0] != 2):
            raise Exception('Cannot add prior as '+name+' is not a gdf profile variable')
        
        # Check that dimensions are the same
        if(not np.logical_and.reduce(aod_err.shape==pkhght_err.shape)):
            raise Exception('Cannot add prior as aod and pkhght dimensions are different')
        if(not np.logical_and.reduce(aod_err.shape==pkwdth_err.shape)):
            raise Exception('Cannot add prior as aod and pkwdth dimensions are different')
            
        # Define Error covariance name
        sname = name + '_ErrorCovar'
        
        # Correct dimensions for output field
        outdim = [self.imx,self.jmx,self.tmx]

        # Check field dimensions
        self.check_field_dim(sname,aod_err,outdim)
        
        # Update the field Type (Use diagonal index)
        self.ncid.variables[priorname][:] = 1
        
        # Allocate error 
        Sdim = [outdim[0],outdim[1],3,outdim[2]]
        
        # Output field dimensions
        outdim_name = ['i','j','p3','t']
        for n in range(4):
            if( Sdim[n] == 1 ): 
                outdim_name[n] = 'o'
                Sdim[n] = 1
        
        # Define field
        self.ncid.createVariable(sname,np.float64,tuple(outdim_name[::-1]))
        
        # Set diagonal error
        Sdiag = np.zeros((Sdim))
        for t in range(Sdim[-1]):
            Sdiag[:,:,0,t] = aod_err[:,:,t]
            Sdiag[:,:,1,t] = pkhght_err[:,:,t]
            Sdiag[:,:,2,t] = pkwdth_err[:,:,t]
        
        # Write the covariance matrix
        self.ncid.variables[sname][:,:,:,:] = Sdiag[:,:,:,:].T

    def add_exp_aerosol(self, name, aod, zmin, zmax, rxhght):
        
        ''' Add profile parameterized by an exponential function to output array

            Args:
                name ('str'): Name of trace gas
                aod[x,y,t] (numpy float): Column aerosol optical depth
                zmin[x,y,t] (numpy float): Minimum Height (km)
                zmax[x,y,t] (numpy float): Maximum Height (km)
                rxhght[x,y,t] (numpy float): Relaxation Height (km)

                where the dimensions are - 
                    x - Longitude
                    y - Latitude
                    t - Time

        '''
        
        import numpy as np

        # Correct dimensions for output field
        outdim = [self.imx,self.jmx,self.tmx]

        # Check field dimensions
        self.check_field_dim(name,aod,outdim)
        self.check_field_dim(name+'_zmin',zmin,outdim)
        self.check_field_dim(name+'_zmax',zmax,outdim)
        self.check_field_dim(name+'_rxh',rxhght,outdim)

        # Output field dimensions
        outdim = ['i','j','t']

        # Write fields
        self.write_nc_fld(name,aod,outdim)
        self.write_nc_fld(name+'_zmin',zmin,outdim)
        self.write_nc_fld(name+'_zmax',zmax,outdim)
        self.write_nc_fld(name+'_rxh',rxhght,outdim)

        # Initialize Error Covariance Type
        self.ncid.createVariable(name+'_ErrorCovarType',np.int16,('o'))
        self.ncid.createVariable(name+'_StateType',np.int16,('o'))
        self.ncid.variables[name+'_ErrorCovarType'][:] = -1
        self.ncid.variables[name+'_StateType'][:] = 3 # StateType = 3 => EXP

        self.state_descript[name] = 'Aerosol profile parameterized with EXP'

    def add_exp_prior(self, name, aod_err, rxhght_err):
    
        ''' Add error associated with profile parameterized by an box function to output array

            Args:
                name ('str'): Name of trace gas
                aod_err[x,y,t] (numpy float): Column aerosol optical error
                rxhght_err[x,y,t] (numpy float): Relax. Height error (km)
                zmin[x,y,t] (numpy float): Minimum Height (km)
                zmax[x,y,t] (numpy float): Maximum Height (km)

                where the dimensions are -
                    x - Longitude
                    y - Latitude
                    t - Time
        '''
        
        import numpy as np
        
        # Check that the profile field has been defined
        priorname = name+'_ErrorCovarType'
        
        if not any(priorname in s for s in self.ncid.variables.keys()):
            raise Exception('Cannot add prior as '+name+' has not been defined')
        
        # This should only apply for box profile variables
        if(self.ncid.variables[name+'_StateType'][0] != 3):
            raise Exception('Cannot add prior as '+name+' is not a exp profile variable')
        
        # Check that dimensions are the same
        if(not np.logical_and.reduce(aod_err.shape==rxhght_err.shape)):
            raise Exception('Cannot add prior as aod and rxhght dimensions are different')
        
        # Define Error covariance name
        sname = name + '_ErrorCovar'
        
        # Correct dimensions for output field
        outdim = [self.imx,self.jmx,self.tmx]

        # Check field dimensions
        self.check_field_dim(sname,aod_err,outdim)
        
        # Update the field Type (Use diagonal index)
        self.ncid.variables[priorname][:] = 1
        
        # Allocate error 
        Sdim = [outdim[0],outdim[1],2,outdim[2]]
        
        # Output field dimensions
        outdim_name = ['i','j','p2','t']
        for n in range(4):
            if( Sdim[n] == 1 ): 
                outdim_name[n] = 'o'
                Sdim[n] = 1
        
        # Define field
        self.ncid.createVariable(sname,np.float64,tuple(outdim_name[::-1]))
        
        # Set diagonal error
        Sdiag = np.zeros((Sdim))
        for t in range(Sdim[-1]):
            Sdiag[:,:,0,t] = aod_err[:,:,t]
            Sdiag[:,:,1,t] = rxhght_err[:,:,t]
        
        # Write the covariance matrix
        self.ncid.variables[sname][:,:,:,:] = Sdiag[:,:,:,:].T
    
    def add_box_aerosol(self, name, aod, zmin, zmax):
        
        ''' Add profile parameterized by an box function to output array

            Args:
                name ('str'): Name of trace gas
                aod[x,y,t] (numpy float): Column aerosol optical depth
                zmin[x,y,t] (numpy float): Minimum Height (km)
                zmax[x,y,t] (numpy float): Maximum Height (km)

                where the dimensions are - 
                    x - Longitude
                    y - Latitude
                    t - Time
        '''
        
        import numpy as np

        # Correct dimensions for output field
        outdim = [self.imx,self.jmx,self.tmx]

        # Check field dimensions
        self.check_field_dim(name,aod,outdim)
        self.check_field_dim(name+'_zmin',zmin,outdim)
        self.check_field_dim(name+'_zmax',zmax,outdim)

        # Output field dimensions
        outdim = ['i','j','t']

        # Write fields
        self.write_nc_fld(name,aod,outdim)
        self.write_nc_fld(name+'_zmin',zmin,outdim)
        self.write_nc_fld(name+'_zmax',zmax,outdim)

        # Initialize Error Covariance Type
        self.ncid.createVariable(name+'_ErrorCovarType',np.int16,('o'))
        self.ncid.createVariable(name+'_StateType',np.int16,('o'))
        self.ncid.variables[name+'_ErrorCovarType'][:] = -1
        self.ncid.variables[name+'_StateType'][:] = 4 # StateType = 4 => BOX
    
    def add_box_prior(self, name, aod_err):
    
        ''' Add error associated with profile parameterized by an box function to output array

            Args:
                name ('str'): Name of trace gas
                aod_err[x,y,t] (numpy float): Column aerosol optical error (km)
                zmin[x,y,t] (numpy float): Minimum Height (km)
                zmax[x,y,t] (numpy float): Maximum Height (km)

                where the dimensions are -
                    x - Longitude
                    y - Latitude
                    t - Time
        '''
        
        import numpy as np
        
        # Check that the profile field has been defined
        priorname = name+'_ErrorCovarType'
        
        if not any(priorname in s for s in self.ncid.variables.keys()):
            raise Exception('Cannot add prior as '+name+' has not been defined')
        
        # This should only apply for box profile variables
        if(self.ncid.variables[name+'_StateType'][0] != 4):
            raise Exception('Cannot add prior as '+name+' is not a box profile variable')
        
        # Define Error covariance name
        sname = name + '_ErrorCovar'
        
        # Correct dimensions for output field
        outdim = [self.imx,self.jmx,self.tmx]

        # Check field dimensions
        self.check_field_dim(sname,aod_err,outdim)
        
        # Update the field Type (Use diagonal index)
        self.ncid.variables[priorname][:] = 1
        
        # Allocate error 
        Sdim = [outdim[0],outdim[1],1,outdim[2]]
        
        # Output field dimensions
        outdim_name = ['i','j','p1','t']
        for n in range(4):
            if( Sdim[n] == 1 ): 
                outdim_name[n] = 'o'
                Sdim[n] = 1
        
        # Define field
        self.ncid.createVariable(sname,np.float64,tuple(outdim_name[::-1]))
        
        # Set diagonal error
        Sdiag = np.zeros((Sdim))
        for t in range(Sdim[-1]):
            Sdiag[:,:,0,t] = aod_err[:,:,t]
        
        # Write the covariance matrix
        self.ncid.variables[sname][:,:,:,:] = Sdiag[:,:,:,:].T
        
        self.state_descript[name] = 'Aerosol profile parameterized with BOX'

    def add_diagonal_prof_prior(self, name, Sdiag, checkDim=True,checkProf=True):
    
        ''' Adds a diagonal prior covariance matrix to a profile variable

            Args:
                name('str'): Name of profile variable
                Sdiag[x,y,z,t]: Diagonal elements of covariance matrix (along z)
                checkDim: Set to true to check if input field dimensions are correct (default:True)
                checkProf: Set to true to check if StateType is a profile variable

            where the dimensions are - 
                    x - Longitude
                    y - Latitude
                    z - Altitude
                    t - Time
            x,y, and t can have dimension 1 

        '''
        
        import numpy as np
        
        # Check that the profile field has been defined
        priorname = name+'_ErrorCovarType'
        
        if not any(priorname in s for s in self.ncid.variables.keys()):
            raise Exception('Cannot add prior as '+name+' has not been defined')
        
        # This should only apply for profile variables
        if(self.ncid.variables[name+'_StateType'][0] != 1 and checkProf):
            raise Exception('Cannot add prior as '+name+' is not a profile variable')
        
        # Define Error covariance name
        sname = name + '_ErrorCovar'

        # Correct dimensions for output field
        outdim = [self.imx,self.jmx,self.lmx,self.tmx]
        
        # Check dimensions
        if(checkDim):
            self.check_field_dim(sname,Sdiag,outdim)
        
        # Update the field Type
        self.ncid.variables[priorname][:] = 1

        # Determine field dimensions
        outdim = ['i','j','l','t']
        for n in range(4):
            if( Sdiag.shape[n] == 1 ): outdim[n] = 'o'
                
        # Define field
        self.ncid.createVariable(sname,np.float64,tuple(outdim[::-1]))
        
        # Check if its a profile variable - If so then check vertical dimension order
        dl = 1
        if(self.ncid.variables[name+'_StateType'][0] == 1):
            if(not self.GridTopToBot): dl = -1
        
        # Write the covariance matrix
        self.ncid.variables[sname][:,:,:,:] = Sdiag[:,:,::dl,:].T

    def add_correlated_prof_prior(self,name,Sdiag,corrlen,checkDim=True):
        
        ''' Adds a prior covariance matrix to a profile variable 

            Matrix includes correlations between layers defined by corrlen

            Args:
                name('str'): Name of profile variable
                Sdiag[x,y,z,t]: Diagonal elements of covariance matrix (along z)
                corrlen[x,y,t]: Correlation length scale (km)
                checkDim: Set to true to check if input field dimensions are correct (default:True)
            where the dimensions are -
                    x - Longitude
                    y - Latitude
                    z - Altitude
                    t - Time
            x,y, and t can have dimension 1

        '''

        import numpy as np
        
        # This should only apply for profile variables
        if(self.ncid.variables[name+'_StateType'][0] != 1):
            raise Exception('Cannot add prior as '+name+' is not a profile variable')
        
        # Check that the profile field has been defined
        priorname = name+'_ErrorCovarType'
        if not any(priorname in s for s in self.ncid.variables.keys()):
            raise Exception('Cannot add prior as '+name+' has not been defined')
        
        # Define Error covariance name
        sname = name + '_ErrorCovar'
        
        # Check dimensions of diagonal covariance elements
        if(checkDim):
            outdim = [self.imx,self.jmx,self.lmx,self.tmx]
            self.check_field_dim(sname,Sdiag,outdim)
            
            # Now Check the correlation length scale field
            outdim = [self.imx,self.jmx,self.tmx]
            self.check_field_dim(name+'_CorrelationLength',corrlen,outdim)
        
        # Update the field Type
        self.ncid.variables[priorname][:] = 2

        # Determine field dimensions and define
        outdim = ['i','j','l','t']
        for n in range(4):
            if( Sdiag.shape[n] == 1 ): outdim[n] = 'o'
        self.ncid.createVariable(sname,np.float64,tuple(outdim[::-1]))
        
        # Do the same for the corrlen field
        outdim = ['i','j','t']
        for n in range(3):
            if( corrlen.shape[n] == 1 ): outdim[n] = 'o'
        self.ncid.createVariable(name+'_CorrelationLength',np.float64,tuple(outdim[::-1]))
        
        # Check if its a profile variable - If so then check vertical dimension order
        dl = 1
        if(self.ncid.variables[name+'_StateType'][0] == 1):
            if(not self.GridTopToBot): dl = -1
        
        # Write fields
        self.ncid.variables[sname][:,:,:,:] = Sdiag[:,:,::dl,:].T
        self.ncid.variables[name+'_CorrelationLength'][:,:,:] = corrlen.T
        
    def add_custom_prior(self, name, Scov, checkDim=True):
        
        ''' Adds fully specified Covariance matrix to any variable type

            Args:
                name('str'): Name of profile variable
                Scov[x,y,z,z,t]: Covariance matrix
                checkDim: Set to true to check if input field dimensions are correct (default:True)
                
            where the dimensions are - 
                    x - Longitude
                    y - Latitude
                    z - Altitude or Parameters
                    t - Time
            x,y, and t can have dimension 1 

        '''
        
        import numpy as np
        
        # Check that the profile field has been defined
        priorname = name+'_ErrorCovarType'
        if not any(priorname == s for s in self.ncid.variables.keys()):
            raise Exception('Cannot add prior as '+name+' has not been defined')
        
        # Define Error covariance name
        sname = name + '_ErrorCovar'
        
        # Correct dimensions for output field
        dl = 1
        if(self.ncid.variables[name+'_StateType'][0] == 1):
            
            # Get variable dimemension
            v = self.lmx ; vstr = 'l' ; strict_idx = []
            
            # Force index order TOA -> Surface
            if(not self.GridTopToBot): dl = -1
            
        elif(self.ncid.variables[name+'_StateType'][0] == 2):
            v = 4 ; vstr = 'p3' ; strict_idx = [2,3]
        elif(self.ncid.variables[name+'_StateType'][0] == 3):
            v = 3 ; vstr = 'p2' ; strict_idx = [2,3]
        elif(self.ncid.variables[name+'_StateType'][0] == 4):
            v = 2 ; vstr = 'p1' ; strict_idx = [2,3]
        else:
            raise Exception('Unrecognized profile type index for '+name)
        
        # Check dimensions
        if(checkDim):
            outdim = [self.imx,self.jmx,v,v,self.tmx]
            self.check_field_dim(sname,Scov,outdim,strict_idx=strict_idx)
        
        # Update the field Type
        self.ncid.variables[priorname][:] = 3
        
        # Determine field dimensions
        outdim = ['i','j',vstr,vstr,'t']
        
        for n in range(5):
            if( Scov.shape[n] == 1 ): outdim[n] = 'o'
                
        # Define field
        self.ncid.createVariable(sname,np.float64,tuple(outdim[::-1]))

        # Write the covariance matrix
        self.ncid.variables[sname][:,:,:,:,:] = Scov[:,:,::dl,::dl,:].T
    
    def add_T_prior(self,Tmid_err,ErrorType='DIAGONAL',corrlen=None):
        
        ''' Adds a temperature a priori covariance matrix

        Args:
                Tmid_err (numpy float): Error standard deviation
                ErrorType: String listing the type of error output
                           Can be any one of:
                             'DIAGONAL' Diagonal Covariance matrix
                                        Tmid_err[x,y,z,t] corresponds to diagonal elements
                             'ZCORRELATED' Diagonal Covariance matrix 
                                           Tmid_err[x,y,z,t] corresponds to diagonal elements
                                           corrlen[x,y,t] defines the correlation length scale
                             'SPECIFIED' Fully Specified Error Covariance
                                           Tmid_err[x,y,z,z,t] specifies the full covariance matrix
                                           where the z,z elements correspond to the covar matrix at x,y,t

        '''
        
        # Number of dimensions
        if(ErrorType == 'SPECIFIED' and ndim != 5):
            ndim = 5
            outdim = [self.imx,self.jmx,self.lmx,self.lmx,self.tmx]
            
        else:
            ndim = 4
            outdim = [self.imx,self.jmx,self.lmx,self.tmx]
            
        # Check dimension
        if(len(Tmid_err.shape) != ndim):
            raise Exception('Tmid_err is the wrong dimension for chosen covariance matrix type')

        # Check dimensions of diagonal covariance elements
        self.check_field_dim('Tmid_ErrorCovar',Tmid_err,outdim)

        # Check if corrlen has been specified
        if(ErrorType == 'ZCORRELATED' and corrlen is None):
            raise Exception('corrlen must be specified when using ZCORRELATED ErrorType')
        
        # Check corrlen dimensions 
        if(ErrorType == 'ZCORRELATED'):
            self.check_field_dim('Tmid_CorrelationLength',corrlen,\
                                 [self.imx,self.jmx,self.tmx]     )

        if(ErrorType == 'DIAGONAL'):
            self.add_diagonal_prof_prior('Tmid', Tmid_err, checkDim=False)
        elif(ErrorType == 'ZCORRELATED'):
            self.add_correlated_prof_prior('Tmid',Tmid_err,corrlen,checkDim=False)
        elif(ErrorType == 'SPECIFIED'):
            self.add_custom_prior('Tmid', Tmid_err, checkDim=False)
        else:
            raise Exception (ErrorType+'is not a valid ErrorType')

    def add_footprintvar_prior(self,name,err):

        ''' Adds an a priori covariance matrix for a footprint element
            
        Args:
                name: Name of footprint variable
                err[x,y,t] (numpy float): Error standard deviation for footprint var
            
        '''

        import numpy as np

        # Check that the profile field has been defined
        priorname = name+'_ErrorCovarType'
        if(not any(priorname == s for s in self.ncid.variables.keys())):
            raise Exception('Cannot add prior as '+name+' has not been defined')
        
        # Check dimension
        if(len(err.shape) != 3):
            raise Exception(name+'_err is the wrong dimension')
        
        # Now Check the correlation length scale field
        outdim = [self.imx,self.jmx,self.tmx]
        self.check_field_dim(name+'_ErrorCovar',err,outdim)

        # Do the same for the corrlen field
        outdim = ['i','j','t']
        for n in range(3):
            if( err.shape[n] == 1 ): outdim[n] = 'o'
        self.ncid.createVariable(name+'_ErrorCovar',np.float64,tuple(outdim[::-1]))
        
        # Write field
        self.ncid.variables[name+'_ErrorCovar'][:,:,:] = np.power(err.T,2)
        
        # Update error covariance type
        self.ncid.variables[priorname][:] = 0

    def add_psurf_prior(self,psurf_err):
        
        ''' Adds a surface pressure a priori covariance matrix
            
        Args:
                psurf_err[x,y,t] (numpy float): Error standard deviation
            
        '''
        
        # Add the error
        self.add_footprintvar_prior('psurf',psurf_err)
    
    def add_Tshift_prior(self,Tshift_err):
        
        ''' Adds a Temperature profile shift a priori covariance matrix
            
        Args:
                Tshift_err[x,y,t] (numpy float): Error standard deviation
            
        '''
        
        # Add the error
        self.add_footprintvar_prior('Tshift',Tshift_err)
        
    def close(self):
        
        '''Closes SPLAT profile input file'''
        
        import numpy as np

        # Wirte optional variables that have not yet been set to default values
        for name in self.opt2d_descript.keys():
            if(not any(name == s for s in self.ncid.variables.keys())):
                fld = np.zeros([1,1,1]) ; fld[:] = self.opt2d_default[name]
                self.add_footprint_var(name,fld,dtype=self.opt2d_dtype[name])

        # Close file
        self.ncid.close()