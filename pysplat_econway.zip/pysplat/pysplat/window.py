class isrf(object):

    '''
    The isrf class is used to create "SPLAT: format ISRF input files
    
    
    [long descript goes here]
    
    Note:
        

    Attributes:
    
    '''

    def __init__(self,outfile):

        ''' Initializes a file containing band information

            ARGS:
                 outfile (str): Name of output file
        '''

        from netCDF4 import Dataset
        import numpy as np

        # Set 
        self.outfile = outfile
        self.nband = 0

        # Open file
        self.ncid = Dataset(outfile,'w')

        # Create unit dimension
        self.ncid.createDimension('o',1)

        # Variable to track number of bands
        self.ncid.createVariable('NumberOfBands',np.int16,('o'))

    def add_supergauss_band_isrf(self,wvl,hw1e,asym,shap,bandname=None):

        ''' Adds the Supergaussian ISRF information for a given band

            The definition of the (unnormalized) Supergaussian g(x) is
                        _                                            _
                       |   |            x^2                  |^shap   |
           g(x) =  EXP | - |---------------------------------|        |
                       |_  | (hw1e * (1 + SIGN(x)*asym))     |       _|
     

            ARGS:
                wvl[w]   (numpy 'float'): Wavelength grid [nm]
                hw1e[w,x](numpy 'float'): The half width at 1/e for each pixel in the band
                asym[w,x](numpy 'float'): The asymmetry parameter of the supergaussian
                shap[w,x](numpy 'float'): The shape parameter of the supergaussian
            OPTIONAL:
                bandname (str): A description of the band to add as an attribute to the file

            Where the dimensions are
              w - Wavelength Pixel Dimension
              x - Cross track dimension

        '''

        import numpy as np

        # Make sure dimensions check out

        if(wvl.shape[0] != hw1e.shape[0]):
            raise Exception('wvl w dimension does not agree with hw1e')
        if(asym.shape[0] != hw1e.shape[0]):
            raise Exception('asym w dimension does not agree with hw1e')
        if(shap.shape[0] != hw1e.shape[0]):
            raise Exception('shap w dimension does not agree with hw1e')
        if(asym.shape[1] != hw1e.shape[1]):
            raise Exception('asym x dimension does not agree with hw1e')
        if(shap.shape[1] != hw1e.shape[1]):
            raise Exception('shap x dimension does not agree with hw1e')

        # Increment number of bands
        self.nband = self.nband + 1

        # Create w/T band dimension
        wdim = 'w' + str(self.nband)
        self.ncid.createDimension(wdim,hw1e.shape[0])
        xdim = 'x' + str(self.nband)
        self.ncid.createDimension(xdim,hw1e.shape[1])
        Tdim = 'T' + str(self.nband)
        self.ncid.createDimension(Tdim,1)
        pdim = 'p' + str(self.nband)
        self.ncid.createDimension(pdim,3)

        # Define Group
        gid = self.ncid.createGroup('Band'+str(self.nband))
        if(not bandname is None):
            gid.band_description = bandname

        # Set Definitions
        v = gid.createVariable('ISRFTypeIndex',np.int16,('o')) ; v[:] = 1
        v.description = 'Wavelength-dependent Supergaussian ISRF'

        # Write the band information
        v = gid.createVariable('Wavelength',np.float64,(wdim)) ; v[:] = wvl
        v = gid.createVariable('Temperature',np.float64,(Tdim))
        v = gid.createVariable('ISRFParameters',np.float64,(pdim,Tdim,xdim,wdim))
        v[0,0,:,:] = hw1e.T
        v[1,0,:,:] = asym.T
        v[2,0,:,:] = shap.T

    def add_supergauss_band_isrf_Tdep(self,wvl,hw1e,asym,shap,temp,bandname=None):

        ''' Adds the Supergaussian ISRF information for a given band

            The definition of the (unnormalized) Supergaussian g(x) is
                        _                                            _
                       |   |            x^2                  |^shap   |
           g(x) =  EXP | - |---------------------------------|        |
                       |_  | (hw1e * (1 + SIGN(x)*asym))     |       _|
     

            ARGS:
                wvl[w](numpy 'float'): Wavelength grid [nm]
                hw1e[w,x,T](numpy 'float'): The half width at 1/e for each pixel in the band
                asym[w,x,T](numpy 'float'): The asymmetry parameter of the supergaussian
                shap[w,x,T](numpy 'float'): The shape parameter of the supergaussian
                temp[T](numpy 'float'): A grid of optical bench temperatures [K]
            OPTIONAL:
                bandname (str): A description of the band to add as an attribute to the file

            Where the dimensions are
              w - Wavelength
              x - Cross Track Dime
              T - Optical Bench Temperature
        '''

        import numpy as np

        # Make sure dimensions check out
        if(hw1e.shape[2] != temp.shape[0]):
            raise Exception('hw1e T dimension does not agree with temp')
        if(asym.shape[2] != temp.shape[0]):
            raise Exception('asym T dimension does not agree with temp')
        if(shap.shape[2] != temp.shape[0]):
            raise Exception('shap T dimension does not agree with temp')
        if(asym.shape[0] != hw1e.shape[0]):
            raise Exception('asym w dimension does not agree with hw1e')
        if(shap.shape[0] != hw1e.shape[0]):
            raise Exception('shap w dimension does not agree with hw1e')
        if(asym.shape[1] != hw1e.shape[1]):
            raise Exception('asym x dimension does not agree with hw1e')
        if(shap.shape[1] != hw1e.shape[1]):
            raise Exception('shap x dimension does not agree with hw1e')
        if(wvl.shape[0] != hw1e.shape[0]):
            raise Exception('wvl w dimension does not agree with hw1e')
        
        # Increment number of bands
        self.nband = self.nband + 1

        # Create w/T band dimension
        wdim = 'w' + str(self.nband)
        self.ncid.createDimension(wdim,hw1e.shape[0])
        xdim = 'x' + str(self.nband)
        self.ncid.createDimension(xdim,hw1e.shape[1])
        Tdim = 'T' + str(self.nband)
        self.ncid.createDimension(Tdim,hw1e.shape[2])
        pdim = 'p' + str(self.nband)
        self.ncid.createDimension(pdim,3)

        # Define Group
        gid = self.ncid.createGroup('Band'+str(self.nband))
        if(not bandname is None): 
            gid.band_description = bandname

        # Set Definitions
        v = gid.createVariable('ISRFTypeIndex',np.int16,('o')) ; v[:] = 1
        v.description = 'Wavelength/Temperature-dependent Supergaussian ISRF'

        # Write the band information
        v = gid.createVariable('Wavelength',np.float64,(wdim)) ; v[:] = wvl
        v = gid.createVariable('Temperature',np.float64,(Tdim)) ; v[:] = temp
        v = gid.createVariable('ISRFParameters',np.float64,(pdim,Tdim,xdim,wdim))
        v[0,:,:,:] = hw1e.T
        v[1,:,:,:] = asym.T
        v[2,:,:,:] = shap.T

    def add_tropomi_band_isrf(self,wvl,c0,d,s,w,eta,gamma,m,bandname=None):

        ''' Adds the ISRF information for a given band using the TROPOMI ISRF Parameterization


            The definition of the (~ asymm Voigt) TROPOMI ISRF is given in van Hees et al. AMT, (2018) 
            "Determination of the TROPOMI-SWIR instruemtn spectral response function" Equations (1-13)
            
            Here the arguments of the function adopt the same names as in the paper

            ARGS:
                wvl[w]    (numpy 'float'): Central wavelength grid [nm]
                c0[w,x]   (numpy 'float'): Peak Wavelength (relative to pixel centre)
                d[w,x]    (numpy 'float'): Standard deviation of skew-normal dist.
                s[w,x]    (numpy 'float'): Skewness parameter of skew-normal dist 
                w[w,x]    (numpy 'float'): "block width" of skew-normal dist
                eta[w,x]  (numpy 'float'): Weighting param. between skew-normal and Pearson Type VII dist.
                gamma[w,x](numpy 'float'): Width parameter of the Pearson Type VII dist.
                m[w,x]    (numpy 'float'): Shape parameter of the Pearson Type VII dist.
                
            OPTIONAL:
                bandname (str): A description of the band to add as an attribute to the file
            
            Where the dimensions are
              w - Wavelength Pixel Dimension
              x - Cross track dimension

        '''

        import numpy as np

        # Make sure dimensions check out
        if(s.shape != d.shape):
            raise Exception('s dimension does not agree with d')
        if(w.shape != d.shape):
            raise Exception('w dimension does not agree with d')
        if(eta.shape != d.shape):
            raise Exception('eta dimension does not agree with d')
        if(gamma.shape != d.shape):
            raise Exception('gamma dimension does not agree with d')
        if(m.shape != d.shape):
            raise Exception('m dimension does not agree with d')
        if(c0.shape != d.shape):
            raise Exception('c0 dimension does not agree with d')
        if(wvl.shape[0] != d.shape[0]):
            raise Exception('wvl dimension does not agree with d')

        # Increment number of bands
        self.nband = self.nband + 1

        # Create w/T band dimension
        wdim = 'w' + str(self.nband)
        self.ncid.createDimension(wdim,d.shape[0])
        xdim = 'x' + str(self.nband)
        self.ncid.createDimension(xdim,d.shape[1])
        Tdim = 'T' + str(self.nband)
        self.ncid.createDimension(Tdim,1)
        pdim = 'p' + str(self.nband)
        self.ncid.createDimension(pdim,7)

        # Define Group
        gid = self.ncid.createGroup('Band'+str(self.nband))
        if(not bandname is None):
            gid.band_description = bandname

        # Set Definitions
        v = gid.createVariable('ISRFTypeIndex',np.int16,('o')) ; v[:] = 2
        v.description = 'Wavelength-dependent TROPOMI-Style ISRF'

        # Write the band information
        v = gid.createVariable('Temperature',np.float64,(Tdim))
        v = gid.createVariable('ISRFParameters',np.float64,(pdim,Tdim,xdim,wdim))
        v[0,0,:,:] = c0.T
        v[1,0,:,:] = d.T
        v[2,0,:,:] = s.T
        v[3,0,:,:] = w.T
        v[4,0,:,:] = eta.T
        v[5,0,:,:] = gamma.T
        v[6,0,:,:] = m.T
        v = gid.createVariable('Wavelength',np.float64,(wdim))
        v[:] = wvl

    def add_tropomi_band_isrf_Tdep(self,wvl,d,s,w,eta,gamma,m,c0,temp,bandname=None):

        ''' Adds the ISRF information for a given band using the TROPOMI ISRF Parameterization


            The definition of the (~ asymm Voigt) TROPOMI ISRF is given in van Hees et al. AMT, (2018) 
            "Determination of the TROPOMI-SWIR instruemtn spectral response function" Equations (1-13)
            
            Here the arguments of the function adopt the same names as in the paper

            ARGS:
              wvl[w]      (numpy 'float'): Central wavelength grid [nm]
              d[w,x,T]    (numpy 'float'): Standard deviation of skew-normal dist.
              s[w,x,T]    (numpy 'float'): Skewness parameter of skew-normal dist 
              w[w,x,T]    (numpy 'float'): "block width" of skew-normal dist
              eta[w,x,T]  (numpy 'float'): Weighting param. between skew-normal and Pearson Type VII dist.
              gamma[w,x,T](numpy 'float'): Width parameter of the Pearson Type VII dist.
              m[w,x,T]    (numpy 'float'): Shape parameter of the Pearson Type VII dist.
              c0[w,x,T]   (numpy 'float'): Peak Wavelength (relative to pixel centre)
              temp[T]     (numpy 'float'): A grid of optical bench temperatures
                
            Where the dimensions are
              w - Wavelength
              x - Cross Track Dime
              T - Optical Bench Temperature
        '''

        import numpy as np

        # Make sure dimensions check out
        if(s.shape != d.shape):
            raise Exception('s dimension does not agree with d')
        if(w.shape != d.shape):
            raise Exception('w dimension does not agree with d')
        if(eta.shape != d.shape):
            raise Exception('eta dimension does not agree with d')
        if(gamma.shape != d.shape):
            raise Exception('gamma dimension does not agree with d')
        if(m.shape != d.shape):
            raise Exception('m dimension does not agree with d')
        if(c0.shape != d.shape):
            raise Exception('c0 dimension does not agree with d')
        if(wvl.shape[0] != d.shape[0]):
            raise Exception('wvl dimension does not agree with d')

        # Increment number of bands
        self.nband = self.nband + 1

        # Create w/T band dimension
        wdim = 'w' + str(self.nband)
        self.ncid.createDimension(wdim,d.shape[0])
        xdim = 'x' + str(self.nband)
        self.ncid.createDimension(xdim,d.shape[1])
        Tdim = 'T' + str(self.nband)
        self.ncid.createDimension(Tdim,d.shape[2])
        pdim = 'p' + str(self.nband)
        self.ncid.createDimension(pdim,7)

        # Define Group
        gid = self.ncid.createGroup('Band'+str(self.nband))
        if(not bandname is None): 
            gid.band_description = bandname

        # Set Definitions
        v = gid.createVariable('ISRFTypeIndex',np.int16,('o')) ; v[:] = 2
        v.description = 'Wavelength/Temperature-dependent TROPOMI-Style ISRF'

        # Write the band information
        v = gid.createVariable('Temperature',np.float64,(Tdim)) ; v[:] = temp
        v = gid.createVariable('ISRFParameters',np.float64,(pdim,Tdim,xdim,wdim))
        v[0,:,:,:] = d.T
        v[1,:,:,:] = s.T
        v[2,:,:,:] = w.T
        v[3,:,:,:] = eta.T
        v[4,:,:,:] = gamma.T
        v[5,:,:,:] = m.T
        v[6,:,:,:] = c0.T
        v = gid.createVariable('Wavelength',np.float64,(wdim))
        v[:] = wvl
        
    def add_lut_isrf(self,center_wvl,delta_wvl,isrf,bandname=None):

        ''' Adds the ISRF information for a given band provided as a lookup table

            ISRFs are provided at a set of center wavelengths for each cross track 
            position. ISRFs for wavelengths in between center are linearly interpolated

            ARGS:
              center_wvl[w] (numpy 'float'): Central wavelength corresponding to ISRF 
              delta_wvl[dw] (numpy 'float'): The ISRF Wavelength grid (relative to center wvl)
              isrf[x,w,dw] (numpy 'float'): The ISRF LUT

            Where the dimensions are:
                w - center wavelength
                dw - delta wavelength
                x - Cross Track 

        '''
        import numpy as np

        # Check ISRF dimensions
        if(isrf.shape[1] != center_wvl.shape[0]):
            raise Exception('isrf dimension does not agree with center_wvl')
        if(isrf.shape[2] != delta_wvl.shape[0]):
            raise Exception('isrf dimension does not agree with delta_wvl')
        
        # Increment number of bands
        self.nband = self.nband + 1

        # Define Group
        gid = self.ncid.createGroup('Band'+str(self.nband))
        if(not bandname is None): 
            gid.band_description = bandname

        # Create w/T band dimension
        wdim = 'w' + str(self.nband)
        self.ncid.createDimension(wdim,center_wvl.shape[0])
        dwdim = 'dw' + str(self.nband)
        self.ncid.createDimension(dwdim,delta_wvl.shape[0])
        xdim = 'x' + str(self.nband)
        self.ncid.createDimension(xdim,isrf.shape[0])
        
        # Set Definitions
        v = gid.createVariable('ISRFTypeIndex',np.int16,('o')) ; v[:] = 0
        v.description = 'Lookup Table ISRF'

        # Write the band information
        # --------------------------

        # Wavelength grid
        v = gid.createVariable('CenterWavelength',np.float64,(wdim)) ; v[:] = center_wvl
        v = gid.createVariable('DeltaWavelength',np.float64,(dwdim)) ; v[:] = delta_wvl

        # ISRF
        v = gid.createVariable('ISRF',np.float64,(xdim,wdim,dwdim))
        v[:] = isrf

    def close(self):
        
        ''' Shut isrf input file
        '''

        # Check if anything has been defined
        if(self.nband == 0):
            raise Exception('File is empty - define at least one band ()')
        
        # Write number of bands
        self.ncid.variables['NumberOfBands'][:] = self.nband

        # Close file
        self.ncid.close()

def custom_rtm_grid(wvl,outfile):

    ''' Writes a custom simulation grid for non-convolution RTM simulation case

        The simulation is performed for the specified wavelengths "wvl"
        The RTM results are then splined to the convolution grid before 
        the ISRF is applied
        
        Note that Solar Irradiance input files can also work for custom grids
        (files created with pysplat.solar.write_irradiance)

        ARGS:
          wvl[w] (numpy float): Wavelength grid
          outfile (str): Output file name
          
          w is the wavelength dimension

    '''
    
    from netCDF4 import Dataset
    import numpy as np

    # Number wavelengths
    nwvl = len(wvl)

    # Create file
    d = Dataset(outfile,'w')
    d.createDimension('w',nwvl)
    v = d.createVariable('Wavelength',np.float,('w'))
    v[:] = wvl
    d.close()