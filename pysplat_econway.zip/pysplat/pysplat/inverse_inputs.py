''' Module contains routines for inputs needed in INVERSE calculation mode

'''

def write_eof_input(outfile,eof,wvl=None):

    ''' Writes residual EOF spectra to include in SPLAT fitting

      ARGS:
        outfile (str): Output file path
        eof[x,w,c] (numpy float): Residual EOF Spectra to include in fitting

      OPT ARGS:
        wvl[w] (numpy float): Optional wavelength grid (see [*])

      The dimensions are:
        x - Cross track position
        w - Wavelength position
        c - Number of EOFs
      
      [*] If the wavelength argument is set then the EOFs will be interpolated to 
          the spectrum wavelength grid. Otherwise they will be interpretted as the 
          value at the specific pixel index. Thus in the latter case the eof dimensions 
          must match the detector band dimensions

    '''

    from netCDF4 import Dataset
    import numpy as np

    # Check grid dimension
    if(not wvl is None and wvl.shape[0] != eof.shape[1]):
        raise Exception('wvl and eof dimensions do not agree')
    
    # Write file
    d = Dataset(outfile,'w')

    # Create dimensions
    d.createDimension('x',eof.shape[0])
    d.createDimension('w',eof.shape[1])
    d.createDimension('c',eof.shape[2])

    # Write variables (transpose for FORTRAN ordering)
    v = d.createVariable('EOFSpectrum',np.float64,('c','w','x')) ; v[:] = eof.T
    if(not wvl is None):
        v = d.createVariable('Wavelength',np.float64,('w')) ; v[:] = wvl
    
    # Close file
    d.close()

