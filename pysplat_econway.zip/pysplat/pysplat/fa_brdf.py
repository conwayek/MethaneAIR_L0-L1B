# -*- coding: iso-8859-1 -*-

import numpy as np
from pyhdf import SD
from netCDF4 import Dataset
import os


class fa_brdf(object):
    
    '''
    The fa_brdf class produces a BRDF climatology suitable for use with the 
    Factor analysis hyperspectral interpolation routine
    
    '''
    
    def __init__(self,basedir,lon,lat, wvl, rsr,climatology=False):
        
        ''' Initialize the fa_brdf class type for generating the FA-BRDF climatology
        
        
        ARGS:
            basedir: The base directory name for the climatology
            lon[x] ('numpy float'): Longitude midpoints [degrees]
            lat[x] ('numpy float'): Latitude midpoints [degrees]
            wvl[w] ('numpy float'): Wavelength grid for instrument relative response function
            rsr[w,b] ('numpy float'): Relative response function for imager
        OPTIONAL:
            climatology: Flag that SPLAT interprets to ignore year when doing time interpolation
            
            where the dimensions are
                x - Longitude
                y - Latitude
                w - Wavelength
                b - Band
            
            
        '''
        
        # Store dimensions
        self.imx = lon.shape[0] ; self.lon = lon
        self.jmx = lat.shape[0] ; self.lat = lat
        self.kmx = 3 # Kernel number
        
        # Save the wavelength grid information
        self.wmx = wvl.shape[0] ; self.wvl = wvl
        self.bmx = rsr.shape[1] ; self.rsr = rsr
        
        # Initialize time variable
        self.tmx = 0
        self.time = np.array([])
        
        # Save climatology option
        self.climatology = climatology
        
        # Create base directory if it has not been
        if(not os.path.exists(basedir)):
            os.makedirs(basedir)
        
        # Save base directory
        self.basedir = basedir
        
        # To hold geographic extents of valid data for each snapshot
        self.lat_min = np.array([])
        self.lat_max = np.array([])
        
    def check_brdf_dim(self,brdf):
        
        ''' Makes sure input BRDF array is the correct dimension
            
            
            ARGS:
                brdf[x,y,b]: brdf arrray input to add_brdf_snapshot
           
        '''
        
        pass
    
    def check_lat_lim(self,brdf,valid_range=[0.0,1.0]):
        
        ''' Checks the lower and upper limits where brdf has data
            
            
            ARGS:
                brdf[x,y,b]: brdf arrray input to add_brdf_snapshot
            RETURNS:
                minlat: Minimum latitude where there is data
                maxlat: Maximum latitude where there is data
        '''
        
        # Get the max indices at every latitutde
        ts = brdf.max(axis=0) ; ts = ts.max(axis=1)
        idv = ts > 0

        # Get the bounds
        minlat = np.min(self.lat[idv])
        maxlat = np.max(self.lat[idv])
        
        return minlat,maxlat
       

    def get_hdf_sds_dim(self,sds):
        
        ''' Get the dimensions from a pyhdf SDS object
            
            ARGS:
                SDS: The pyhdf SDS object
            
            RETURNS:
                outdim: A list of dimensions associated with the data field of SDS
        '''
        
        # Read the dimensions
        ndim = len( sds.dimensions() )
    
        # Read the dimensions
        outdim = []
        for n in range(ndim):
            outdim.append(sds.dim(n).length())
        
        return outdim
        
    def add_brdf_snapshot(self,brdf_iso,brdf_vol,brdf_geo,time,chunksize=None):
        
        ''' Add a time sample to the climatology
            
            ARGS:
                brdf_iso[x,y,b] ('numpy float'): Isotropic BRDF Kernel amplitude 
                brdf_vol[x,y,b] ('numpy float'): Volumetric (RossThick) BRDF Kernel amplitude 
                brdf_geo[x,y,b] ('numpy float'): Geometric (LiSparse) BRDF Kernel amplitude 
                time: time of snapshot (GEOS Tau time - hours since 1/1/1985 00:00 UTC)

            OPT ARGS:
                chunksize[2] (int): Chunking dimensions (chunk_x,chunk_y)  
                where the dimensions are
                x - Longitude
                y - Latitude
                b - Band
                
                Note that the time of the added snapshot must be greater than those of previous 
                snapshots added to the climatology

                Missing data is interpretted for brdf_iso < 0.0
                
        '''
        
        # Output is fortran order
        chunksize_T = None
        if(not chunksize is None):
            chunksize_T = [chunksize[1],chunksize[0]]

        # Check the brdf dimensions
        self.check_brdf_dim(brdf_iso)
        self.check_brdf_dim(brdf_vol)
        self.check_brdf_dim(brdf_geo)
        
        # Check that time is ascending
        if(any(t >= time for t in self.time)):
            raise Exception('Snapshots must ascend in time (this one does not)')
        
        # Increment time
        self.tmx += 1 ; self.time = np.append(self.time,time)
        
        # Determine the max/min latitude for sample with valid data
        minlat,maxlat = self.check_lat_lim(brdf_iso,valid_range=[0.0,1.0e3])
        self.lat_min = np.append(self.lat_min,minlat)
        self.lat_max = np.append(self.lat_max,maxlat)

        fill_value = -32767
        # Write the output files
        for b in range(self.bmx):
            
            # Output file name
            outfile = self.basedir + 'BRDF_Band' + str(b+1) + '_Time' + str(self.tmx) + '.nc'
            
            # Kernels
            f_iso = np.array( np.round( brdf_iso[:,:,b].squeeze()*1000.0 ),dtype=np.int16)
            f_vol = np.array( np.round( brdf_vol[:,:,b].squeeze()*1000.0 ),dtype=np.int16)
            f_geo = np.array( np.round( brdf_geo[:,:,b].squeeze()*1000.0 ),dtype=np.int16)
            
            # Insert fill values
            f_iso[f_iso<0] = fill_value
            f_vol[f_vol<0] = fill_value
            f_geo[f_geo<0] = fill_value
            
            # Create file
            ncid = Dataset(outfile,'w')
            
            # Define dimensions
            ncid.createDimension('x',self.imx)
            ncid.createDimension('y',self.jmx)
            
            # Create variables
            ncid.createVariable('f_iso',np.int16,('y','x'),fill_value=fill_value,chunksizes=chunksize_T)
            ncid.createVariable('f_vol',np.int16,('y','x'),fill_value=fill_value,chunksizes=chunksize_T)
            ncid.createVariable('f_geo',np.int16,('y','x'),fill_value=fill_value,chunksizes=chunksize_T)
            
            # Write variables
            ncid.variables['f_iso'][:,:] = f_iso.T
            ncid.variables['f_vol'][:,:] = f_vol.T
            ncid.variables['f_geo'][:,:] = f_geo.T
            
            # Close file
            ncid.close()
    
    def add_brdf_snapshot_mcd43gfcmd(self,brdf_iso,brdf_vol,brdf_geo,time):
        
        ''' Add a time sample to the climatology from the MODIS MCD43 Gap Filled Climate modeling grid product
            
            ARGS:
                brdf_iso[b] ('pyhdf SDS class'): HDF Field corresponding to Isotropic BRDF Kernel amplitude
                brdf_vol[b] ('pyhdf SDS class'): HDF Field corresponding to Volumetric (RossThick) BRDF Kernel amplitude (hd)
                brdf_geo[b] ('pyhdf SDS class'): HDF Field corresponding to Geometric (LiSparse) BRDF Kernel amplitude 
                time: time of snapshot (GEOS Tau time - hours since 1/1/1985 00:00 UTC)
                
                where the dimensions are
                b - Band
                
                Note that the time of the added snapshot must be greater than those of previous 
                snapshots added to the climatology
                
        '''
        
        
        pass
        
        
    
    def finish_write(self):
        
        # Open information file
        ncid = Dataset(self.basedir+'brdf_grid_info.nc','w')
        
        # Create dimensions
        ncid.createDimension('x',self.imx)
        ncid.createDimension('y',self.jmx)
        ncid.createDimension('t',self.tmx)
        ncid.createDimension('w',self.wmx)
        ncid.createDimension('b',self.bmx)
        ncid.createDimension('o',1)
        
        ncid.createVariable('lon'    ,np.float64,('x'))
        ncid.createVariable('lat'    ,np.float64,('y'))
        ncid.createVariable('lat_min',np.float64,('t'))
        ncid.createVariable('lat_max',np.float64,('t'))
        ncid.createVariable('time'   ,np.float64,('t'))
        ncid.createVariable('wvl'    ,np.float64,('w'))
        ncid.createVariable('rsr'    ,np.float64,('b','w'))
        ncid.createVariable('is_clim',np.int16,('o'))
        
        # Write variables
        ncid.variables['lon'    ][:] = self.lon
        ncid.variables['lat'    ][:] = self.lat
        ncid.variables['lat_min'][:] = self.lat_min
        ncid.variables['lat_max'][:] = self.lat_max
        ncid.variables['time'   ][:] = self.time
        ncid.variables['wvl'    ][:] = self.wvl
        ncid.variables['rsr'    ][:] = self.rsr.T
        
        if(self.climatology):
            ncid.variables['is_clim'][:] = 1
        else:
            ncid.variables['is_clim'][:] = 0
        
        # Close file
        ncid.close()
        