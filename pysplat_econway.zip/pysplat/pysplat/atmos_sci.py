''' Contains some common atmospheric science things

'''

def compute_layer_density(pedge,z_idx,Mair=28.97e-3):

    ''' Compute air layer densities (molec/cm2) from a set of pressure edges
      pedge[n1,n2,..,z+1]
      z_idx: Location of z in array
      vert_idx: Index location of the vertical
    '''
    
    # Transpose array to make vertical dimension last
    ndim = len(pedge.shape)
    lmx = pedge.shape[z_idx]-1

    # Transpose dimensions
    Tdim = []
    for n in range(ndim):
        if(n != z_idx):
            Tdim.append(n)
    Tdim.append(z_idx)

    pedge_dimsort = pedge.transpose(Tdim)

    # Air Column
    out_shape = []
    for n in range(ndim-1):
        out_shape.append(pedge_dimsort.shape[n])
    out_shape.append(pedge_dimsort.shape[-1]-1)
    air_layercol = np.zeros(out_shape)

    for l in range(lmx):
        pass
