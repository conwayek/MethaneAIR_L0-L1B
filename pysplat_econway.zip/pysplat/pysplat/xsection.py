# -*- coding: iso-8859-1 -*-



class xsection(object):
    
    # HITRAN ABSCO Tables
    from pysplat.hitran_absco import hitran_absco
    
    def __init__(self):
        
        pass
    
    def write_constant_xs( wvl, spc, outfile, citation='' ):
        
        import numpy as np
        from netCDF4 import Dataset
        
        ncid = Dataset(outfile,'w')
        
        # Dimensions
        ncid.createDimension('w',len(wvl))
        ncid.createDimension('o',1)
        
        # Set attributes
        ncid.setncattr('Citation',citation)
        
        # Create/write variables
        ncid.createVariable('Wavelength',np.float64,('w'))
        ncid.variables['Wavelength'][:] = wvl
        
        ncid.createVariable('XSection',np.float64,('w'))
        ncid.variables['XSection'][:] = spc
        
        # Cross section Type
        ncid.createVariable('TypeID',np.int16,('o'))
        ncid.variables['TypeID'][:] = 1
        
        
        # Close file
        ncid.close()
        
        return 0

    def write_quadraticT_xs( wvl, spc, T0, outfile, citation='' ):
        
        '''
        
        ARGS:
          wvl[w]
          spc[w,x] 
          T0
          outfile
        
        '''
        
        import numpy as np
        from netCDF4 import Dataset
        
        ncid = Dataset(outfile,'w')
        
        # Dimensions
        ncid.createDimension('w',len(wvl))
        ncid.createDimension('x',3)
        ncid.createDimension('o',1)
        
        # Set attributes
        ncid.setncattr('Citation',citation)
        
        # Create/write variables
        ncid.createVariable('Wavelength',np.float64,('w'))
        ncid.variables['Wavelength'][:] = wvl
        
        ncid.createVariable('XSection',np.float64,('x','w'))
        ncid.variables['XSection'][:,:] = spc[:,:].T
        
        # Cross section Type
        ncid.createVariable('TypeID',np.int16,('o'))
        ncid.variables['TypeID'][:] = 2
        
        # Reference Temperature
        ncid.createVariable('ReferenceTemperature',np.float64,('o'))
        ncid.variables['ReferenceTemperature'][:] = T0
        
        # Close file
        ncid.close()
        
        return 0

    def write_linearT_xs( wvl, spc, T0, outfile, citation='' ):
        
        '''
        
        ARGS:
          wvl[w]
          spc[w,x] 
          T0
          outfile
        
        '''
        
        import numpy as np
        from netCDF4 import Dataset
        
        ncid = Dataset(outfile,'w')
        
        # Dimensions
        ncid.createDimension('w',len(wvl))
        ncid.createDimension('x',2)
        ncid.createDimension('o',1)
        
        # Set attributes
        ncid.setncattr('Citation',citation)
        
        # Create/write variables
        ncid.createVariable('Wavelength',np.float64,('w'))
        ncid.variables['Wavelength'][:] = wvl
        
        ncid.createVariable('XSection',np.float64,('x','w'))
        ncid.variables['XSection'][:,:] = spc[:,:].T
        
        # Cross section Type
        ncid.createVariable('TypeID',np.int16,('o'))
        ncid.variables['TypeID'][:] = 4
        
        # Reference Temperature
        ncid.createVariable('ReferenceTemperature',np.float64,('o'))
        ncid.variables['ReferenceTemperature'][:] = T0
        
        # Close file
        ncid.close()
        
        return 0
