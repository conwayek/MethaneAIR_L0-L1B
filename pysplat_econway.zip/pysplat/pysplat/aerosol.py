# -*- coding: iso-8859-1 -*-



class compute_lut( object ):
    
    def __init__( self ):
        
        '''
        Initialization for compute_lut
        Finds path to Mie executable
        '''

        import os

        # Path to mie scattering exe directory
        scriptdir = os.path.dirname(os.path.abspath(__file__))

        # Path to mie scattering exe 
        self.mie_exe_path = os.path.join(scriptdir,'lib/spv_aerosol.exe')

    def mie( self, outfile, wvl, ri_r, ri_i, dist_index, dist_par, rh=[0.0],     \
             r_min=None,r_max=None, tmp_inpfile='spv_aer_inp.nc',remove_lut=False, 
             in_microns=False):
        
        ''' Computes Mie Scattering Lookup Table for SPLAT-VLIDORT
        
        The arguments are -
            wvl[w]: Wavelength grid [nm] (or microns if in_microns=True)
            ri_r[r,w]: Real part of refractive index
            ri_i[r,w]: Imaginary part of refractive index
            dist_index: Index corresponding to aerosol size distribution 
                1: Modified Gamma Distribution
                   n(r) ~ r^a*exp(- (alpha*r^gamma)/(gamma*r_c^gamma) )
                2: Log Normal Distribution 
                   n(r) ~ 1/r*exp( -(ln(r)-ln(r_g))^2/(2*ln(sigma_g)^2) )
                3: Power Law Distribution
                   n(r) ~ r^-3  ... r_1 <= r <= r_2
                        = 0     ... Otherwise
                4: Gamma Distribution
                   n(r) ~ r^((1-3*b)/b)*exp(-r/(a*b))
                5: Modified Power Law Distribution 
                   n(r) = const                ... 0 <= r <= r_1
                        = const*(r/r_1)^alpha  ... r_1 <= r <= r_2
                        = 0                    ... r_2 < r
                6: Bimodal Volume Log Normal Distribution
                   n(r) ~ r^-4*(  exp( -(ln(r)-ln(r_g1))^2/(2*ln(sigma_g1)^2 )  
                                + gamma*exp( -(ln(r)-ln(r_g2))^2/(2*ln(sigma_g2)^2 ) )
                7: Monodisperse Particle
                   n(r) ~ delta(r-r_1)
                In the above - r is the radius [nm] (or microns if in_microns=True)
                             - n(r) is the particle number pdf
            dist_par[r,p] or [p] (no RH input): The distribution parameters for the selected dist_index
                1: dist_par[r,0] = alpha 
                   dist_par[r,1] = r_c
                   dist_par[r,2] = gamma
                2: dist_par[r,0] = r_g
                   dist_par[r,1] = sigma_g
                3: dist_par[r,0] = Effective Radius 
                   dist_par[r,1] = Effective Variance (r_1,r_2 automatically calc)
                4: dist_par[r,0] = a
                   dist_par[r,1] = b
                5: dist_par[r,0] = alpha (r_1,r_2 are automatically calc)
                6: dist_par[r,0] = r_g1
                   dist_par[r,1] = sigma_g1
                   dist_par[r,2] = r_g2
                   dist_par[r,3] = sigma_g2
                   dist_par[r,4] = gamma
                7: dist_par[r,0] = r_1 (The radius of the monodisperse particle)

            r_min: The minimum radius to integrate over the size dist. [nm (or microns if in_microns=True)]
            r_max: The maximum radius to integrate over the size dist. [nm (or microns if in_microns=True)]
            tmp_infile: File name for temporary input file to the executable [TO-DO replace with f2py]
            outfile: File name for temporary output file to the executable (and the LUT)
            rh[r]: Relative Humidity [%]
            in_microns: Set to True if units for all inputs are in microns. False => all units in nm

            NB - Since the routine creates temporary input/output files for the mie code, 
                 when running multiple jobs in the same directory, ensure that each job 
                 has a different tmp_infile+outfile
               - If RH is not set, the RH "r" indexes can be dropped form all the input variables
        '''

        import numpy as np
        from netCDF4 import Dataset
        import os

        # Make sure things are np arrays
        wvl      = np.array( wvl  )
        ri_r     = np.array( ri_r )
        ri_i     = np.array( ri_i )
        rh       = np.array( rh   )
        dist_par = np.array( dist_par )
        
        # Get dimensions
        if( len(wvl.shape) == 0 ):
            nwvl = 1
        else:
            nwvl = len(wvl)
        if( len(rh.shape) == 0 ):
            nrh = 1
        else:
            nrh = len(rh)
        if( len(dist_par.shape) == 0 ):
            npar = 1
        elif(len(dist_par.shape) == 1):
            npar = len(dist_par)
        elif(len(dist_par.shape) == 2):
            npar = dist_par.shape[1]
        
        # Get Limits
        if( r_min is None ):
            
            r_min = np.zeros(nrh)
        else:
            r_min = np.array( r_min )
            if(len(r_min.shape) == 0):
                r_min = np.ones(nrh)*r_min
            else:
                r_min = r_min.reshape((nrh))
    
        if( r_max is None ):
            r_max = np.zeros(nrh)
        else:
            r_max = np.array(r_max)
            if(len(r_max.shape) == 0):
                r_max = np.ones(nrh)*r_max
            else:
                r_max = r_max.reshape((nrh))

        # Enforce the proper dimensions (if single wavelength or RH)
        wvl  = wvl.reshape( nwvl )
        ri_r = ri_r.reshape( (nrh,nwvl) )
        ri_i = ri_i.reshape( (nrh,nwvl) )
        rh   = rh.reshape( nrh )
        dist_par = dist_par.reshape( (nrh,npar) )
        
        # ----------------------------------
        # Write the input file
        # ----------------------------------
        
        # Open file
        ncid = Dataset( tmp_inpfile, 'w' )
        
        # Define Dimension
        ncid.createDimension( 'w', nwvl )
        ncid.createDimension( 'r', nrh  )
        ncid.createDimension( 'p', npar )
        ncid.createDimension( 'o', 1 )
        ncid.createDimension( 't', 2 )
        
        # Create variables
        vid = ncid.createVariable('Wavelength',np.float64,('w'))
        ncid.variables['Wavelength'][:] = wvl[:]
        
        # Mie Theory index = 1
        vid = ncid.createVariable('TheoryIndex',np.int16,('o'))
        ncid.variables['TheoryIndex'][:] = 1
        
        vid = ncid.createVariable('DistributionIndex',np.int16,('o'))
        ncid.variables['DistributionIndex'][:] = dist_index
        
        vid = ncid.createVariable('ParticleRadiusLimits',np.float64,('r','t'))
        ncid.variables['ParticleRadiusLimits'][:,0] = r_min[:]
        ncid.variables['ParticleRadiusLimits'][:,1] = r_max[:]
        
        vid = ncid.createVariable('RelativeHumidity',np.float64,('r'))
        ncid.variables['RelativeHumidity'][:] = rh[:]
        
        vid = ncid.createVariable('RealRefractiveIndex',np.float64,('r','w'))
        ncid.variables['RealRefractiveIndex'][:,:] = ri_r[:,:]
     
        vid = ncid.createVariable('ImaginaryRefractiveIndex',np.float64,('r','w'))
        ncid.variables['ImaginaryRefractiveIndex'][:,:] = ri_i[:,:]

        vid = ncid.createVariable('NumberDistributionParameters',np.float64,('r','p'))
        ncid.variables['NumberDistributionParameters'][:,:] = dist_par[:,:]

        vid = ncid.createVariable('WavelengthInMicrons',np.int16,('o'))
        if(in_microns):
            ncid.variables['WavelengthInMicrons'][:] = 1
        else:
            ncid.variables['WavelengthInMicrons'][:] = 0

        # Close input file
        ncid.close()
        
        # ---------------------------------
        # Run Calculation
        # ---------------------------------
        
        # Run executable
        cmd = self.mie_exe_path + ' ' + tmp_inpfile + ' ' + outfile
        os.system( cmd )
        
        # Cleanup Input file
        cmd = 'rm -f ' + tmp_inpfile
        os.system( cmd )
        
        # ---------------------------------
        # Load Output
        # ---------------------------------
        
        # Read Output file
        ncid  = Dataset(outfile,'r') 
        self.phfcn = ncid.variables['phfcn0'][:,:,:].squeeze()
        self.qext  = ncid.variables['qext0'][:,:].squeeze()
        self.reff  = ncid.variables['reff'][:].squeeze()
        self.ssa   = ncid.variables['ssa0'][:,:].squeeze()
        self.rh    = ncid.variables['rh'][:].squeeze()
        self.wvl   = ncid.variables['wls0'][:].squeeze()
        ncid.close()

        # Remove Output
        if(remove_lut):
            cmd = 'rm -f ' + outfile
            os.system( cmd )
    
    def tmatrix( self, outfile, wvl, ri_r, ri_i, n_p, eps, dist_index, dist_par, rh=[0.0], \
                 r_min=None,r_max=None, tmp_inpfile='spv_aer_inp.nc', remove_lut=False,   \
                 in_microns=False, pdf_r_is_equalvol=True):
        
        ''' Computes T-Matrix Scattering Lookup Table for SPLAT-VLIDORT
        
        The arguments are -
            wvl[w]: Wavelength grid [nm] (or microns if in_microns=True)
            ri_r[r,w]: Real part of refractive index
            ri_i[r,w]: Imaginary part of refractive index
            n_p      : Index that specifies the shape of the particles
                       n_p = -2: Cylinders
                       n_p = -1: Oblate spheroids
                       n_p >  0: Chebyshev particles where n_p=the degree of the chebyshev polynomial
            eps[r]     : Length ratio for the shape of the particles
                       n_p = -2: (Cylinders) Ratio of diameter to length
                       n_p = -1: (Oblate Spheroids) Ratio of horizontal to rotational axes
                       n_p >  0: (Chebyshev) Deformation parameter
            dist_index: Index corresponding to aerosol size distribution 
                1: Modified Gamma Distribution
                   n(r) ~ r^a*exp(- (alpha*r^gamma)/(gamma*r_c^gamma) )
                2: Log Normal Distribution 
                   n(r) ~ 1/r*exp( -(ln(r)-ln(r_g))^2/(2*ln(sigma_g)^2) )
                3: Power Law Distribution
                   n(r) ~ r^-3  ... r_1 <= r <= r_2
                        = 0     ... Otherwise
                4: Gamma Distribution
                   n(r) ~ r^((1-3*b)/b)*exp(-r/(a*b))
                5: Modified Power Law Distribution 
                   n(r) = const                ... 0 <= r <= r_1
                        = const*(r/r_1)^alpha  ... r_1 <= r <= r_2
                        = 0                    ... r_2 < r
                6: Monodisperse Particle
                   n(r) ~ delta(r-r_1)
                In the above - r is the radius [nm] (or microns if in_microns=True)
                             - n(r) is the particle number pdf
            dist_par[r,p]: The distribution parameters for the selected dist_index
                1: dist_par[r,0] = alpha 
                   dist_par[r,1] = r_c
                   dist_par[r,2] = gamma
                2: dist_par[r,0] = r_g
                   dist_par[r,1] = sigma_g
                3: dist_par[r,0] = Effective Radius 
                   dist_par[r,1] = Effective Variance (r_1,r_2 automatically calc)
                4: dist_par[r,0] = a
                   dist_par[r,1] = b
                5: dist_par[r,0] = alpha (r_1,r_2 are automatically calc)
                6: dist_par[r,0] = r_1 (The radius of the monodisperse particle)

            r_min: The minimum radius to integrate over the size dist. [nm (or microns if in_microns=True)]
            r_max: The maximum radius to integrate over the size dist. [nm (or microns if in_microns=True)]
            tmp_infile: File name for temporary input file to the executable [TO-DO replace with f2py]
            outfile: File name for temporary output file to the executable (and the LUT)
            rh[r]: Relative Humidity [%]
            in_microns: Set to True if units for all inputs are in microns. False => all units in nm
            pdf_r_is_equalvol: Set to True if particle size specified in equal-volume-sphere radius
                             : False => Equal surface-area-sphere radius

            NB - Since the routine creates temporary input/output files for the mie code, 
                 when running multiple jobs in the same directory, ensure that each job 
                 has a different tmp_infile+outfile
               - If RH is not set, the RH "r" indexes can be dropped form all the input variables
        '''
        
        import numpy as np
        from netCDF4 import Dataset
        import os

        # Make sure things are np arrays
        wvl      = np.array( wvl  )
        ri_r     = np.array( ri_r )
        ri_i     = np.array( ri_i )
        rh       = np.array( rh   )
        dist_par = np.array( dist_par )
        eps      = np.array( eps )

        # Get dimensions
        if( len(wvl.shape) == 0 ):
            nwvl = 1
        else:
            nwvl = len(wvl)
        if( len(rh.shape) == 0 ):
            nrh = 1
        else:
            nrh = len(rh)
        if( len(dist_par.shape) == 0 ):
            npar = 1
        elif(len(dist_par.shape) == 1):
            npar = len(dist_par)
        elif(len(dist_par.shape) == 2):
            npar = dist_par.shape[1]

        # Get Limits
        if( r_min is None ):
            
            r_min = np.zeros(nrh)
        else:
            r_min = np.array( r_min )
            if(len(r_min.shape) == 0):
                r_min = np.ones(nrh)*r_min
            else:
                r_min = r_min.reshape((nrh))
    
        if( r_max is None ):
            r_max = np.zeros(nrh)
        else:
            r_max = np.array(r_max)
            if(len(r_max.shape) == 0):
                r_max = np.ones(nrh)*r_max
            else:
                r_max = r_max.reshape((nrh))
        
        # Reshape to appropriate dimensions
        wvl  = wvl.reshape( nwvl )
        ri_r = ri_r.reshape( (nrh,nwvl) )
        ri_i = ri_i.reshape( (nrh,nwvl) )
        rh   = rh.reshape( nrh )
        dist_par = dist_par.reshape( (nrh,npar) )
        eps  = eps.reshape( nrh )
        
        # ----------------------------------
        # Write the input file
        # ----------------------------------
        
        # Open file
        ncid = Dataset( tmp_inpfile, 'w' )
        
        # Define Dimension
        ncid.createDimension( 'w', nwvl )
        ncid.createDimension( 'r', nrh  )
        ncid.createDimension( 'p', npar )
        ncid.createDimension( 'o', 1 )
        ncid.createDimension( 't', 2 )
        
        # Create variables
        vid = ncid.createVariable('Wavelength',np.float64,('w'))
        ncid.variables['Wavelength'][:] = wvl[:]
        
        # T-Matrix Theory index = 2
        vid = ncid.createVariable('TheoryIndex',np.int16,('o'))
        ncid.variables['TheoryIndex'][:] = 2
        
        vid = ncid.createVariable('DistributionIndex',np.int16,('o'))
        ncid.variables['DistributionIndex'][:] = dist_index
        
        vid = ncid.createVariable('ParticleRadiusLimits',np.float64,('r','t'))
        ncid.variables['ParticleRadiusLimits'][:,0] = r_min[:]
        ncid.variables['ParticleRadiusLimits'][:,1] = r_max[:]
        
        vid = ncid.createVariable('RelativeHumidity',np.float64,('r'))
        ncid.variables['RelativeHumidity'][:] = rh[:]
        
        vid = ncid.createVariable('RealRefractiveIndex',np.float64,('r','w'))
        ncid.variables['RealRefractiveIndex'][:,:] = ri_r[:,:]
     
        vid = ncid.createVariable('ImaginaryRefractiveIndex',np.float64,('r','w'))
        ncid.variables['ImaginaryRefractiveIndex'][:,:] = ri_i[:,:]

        vid = ncid.createVariable('NumberDistributionParameters',np.float64,('r','p'))
        ncid.variables['NumberDistributionParameters'][:,:] = dist_par[:,:]

        vid = ncid.createVariable('WavelengthInMicrons',np.int16,('o'))
        if(in_microns):
            ncid.variables['WavelengthInMicrons'][:] = 1
        else:
            ncid.variables['WavelengthInMicrons'][:] = 0
        
        # Particle Shape Type
        vid = ncid.createVariable('nP',np.int16,('o'))
        ncid.variables['nP'][:] = n_p
        
        # Particle Shape parameter
        vid = ncid.createVariable('EPS',np.float64,('r'))
        ncid.variables['EPS'][:] = eps[:]
        
        # Equal Volume Sphere
        vid = ncid.createVariable('EqualVolumeSphere',np.int16,('o'))
        if(pdf_r_is_equalvol):
            ncid.variables['EqualVolumeSphere'][:] = 1
        else:
            ncid.variables['EqualVolumeSphere'][:] = 0
            
        # Close input file
        ncid.close()
        

        # ---------------------------------
        # Run Calculation
        # ---------------------------------
        
        # Run executable
        cmd = self.mie_exe_path + ' ' + tmp_inpfile + ' ' + outfile
        os.system( cmd )
        
        # Cleanup Input file
        cmd = 'rm -f ' + tmp_inpfile
        os.system( cmd )
        
        # ---------------------------------
        # Load Output
        # ---------------------------------
        
        # Read Output file
        ncid  = Dataset(outfile,'r') 
        self.phfcn = ncid.variables['phfcn0'][:,:,:].squeeze()
        self.qext  = ncid.variables['qext0'][:,:].squeeze()
        self.reff  = ncid.variables['reff'][:].squeeze()
        self.ssa   = ncid.variables['ssa0'][:,:].squeeze()
        self.rh    = ncid.variables['rh'][:].squeeze()
        self.wvl   = ncid.variables['wls0'][:].squeeze()
        ncid.close()

        # Remove Output
        if(remove_lut):
            cmd = 'rm -f ' + outfile
            os.system( cmd )
        
    def pollack_cuzzi_scalar(self, outfile, wvl, ri_r, ri_i, ssa, a, b, G, r_min, r_max, Rs, theta_min,\
                             x_crit=5.0, x_deg=100, th_deg=360,nmom=1000):
        
        from pollack_cuzzi_1980 import semiempirical_scatter 
        
        '''  Computes a Scalar Aerosol Scattering Lookup Table for SPLAT-VLIDORT
             based on the parameterization from Pollack and Cuzzi 1980
        
        '''
        
        # Compute table
        aerosol = semiempirical_scatter(theta_gr, pdf, r_min, r_max, wvl,\
                                        ri_r, ri_i, Rs, G, theta_min, \
                                        x_crit=x_crit, x_deg=x_deg, th_deg=th_deg,nmom=nmom)
        
        # Write table
        aerosol.lut.write_lut( outfile )
        
    def evaluate_scalar_phase_function( self, theta_grid ):
       
        import numpy as np

        # Theta quadrature grid
        th_deg = 720
        lth_grid, wt_th = np.polynomial.legendre.leggauss( th_deg )
        th_max = np.pi ; th_min = 0.0
        b_th = 2.0/th_max
        a_th = 1.0 - b_th*th_max
        th_grid = (lth_grid-a_th)/b_th
        
        ntheta = len(theta_grid)
        
        if( len(self.phfcn.shape) ==  3):
            ncoeff = self.phfcn.shape[1]
            wmx    = self.phfcn.shape[2]
            coef = np.reshape( self.phfcn[0,:,:].squeeze(), (ncoeff,wmx) )
        else:
            ncoeff = self.phfcn.shape[1]
            wmx    = 1
            coef = np.reshape( self.phfcn[0,:].squeeze(), (ncoeff,wmx) )
        
        
        # Declare output
        P = np.zeros( (ntheta,wmx) )
        
        # Cos theta
        c_theta = np.cos( theta_grid )
        
        for w in range(wmx):
            
            f = np.polynomial.legendre.Legendre( coef[:,w].squeeze() )
                    
            P[:,w] = f( c_theta )
        
        return P.squeeze()
    
class lut_io( object ):
    
    '''
    Class for dealing with LUT input/output
    '''
    def __init__( self, filename=None, lut=None ):
        
        from netCDF4 import Dataset
        
        # Case 1 - Load from file
        if( not filename is None ):
            
            # Load the properties
            ncid  = Dataset(filename,'r') 
            self.phfcn = ncid.variables['phfcn0'][:,:,:]
            self.qext  = ncid.variables['qext0'][:,:]
            self.reff  = ncid.variables['reff'][:]
            self.ssa   = ncid.variables['ssa0'][:,:]
            self.rh    = ncid.variables['rh'][:]
            self.wvl   = ncid.variables['wls0'][:]
            self.nwvl  = len(self.wvl)
            self.nrh   = len(self.nrh)
            self.ngk   = self.phfcn.shape[1]
            self.nmom  = self.phfcn.shape[2]
            ncid.close()
        
        # Case 2 - LUT computed from compute_lut class
        elif(not lut is None):
            self.phfcn = lut.phfcn
            self.qext  = lut.qext
            self.reff  = lut.reff
            self.ssa   = lut.ssa
            self.rh    = lut.rh
            self.wvl   = lut.wvl
            self.nwvl  = len(self.wvl)
            self.nrh   = len(self.nrh)
            self.ngk   = self.phfcn.shape[1]
            self.nmom  = self.phfcn.shape[2]

        # Case 3 - Empty object
        else:
            self.phfcn = None
        
        self.theta = None
        
    def allocate_arrays( self, wvl, rh, nmom ):
        
        import numpy as np

        # Get dimensions
        nrh  = len( rh)
        nwvl = len(wvl)
        ngk  = 6
        
        # Output grid
        self.wvl   = wvl
        self.nwvl  = nwvl
        self.rh    = rh
        self.nrh   = nrh
        self.ngk   = ngk
        self.nmom  = nmom
        
        # Allocate arrays
        self.phfcn = np.zeros((nrh,ngk,nmom,nwvl))
        self.qext  = np.zeros((nrh,nwvl))
        self.reff  = np.zeros((nrh))
        self.ssa   = np.zeros((nrh,nwvl))
        self.rh    = np.zeros((nrh))
        
    def scalar_pfunc_expansion( self, theta ):
        
        import numpy as np

        # Archive grid
        self.theta = theta
        ntheta = len(theta)
        
        # Compute expansion
        x = np.cos( theta )
        
        # Allocate phase function array
        self.Pexp = np.zeros( (ntheta,self.nrh,self.nwvl) )
        
        for r in range( self.nrh ):
            for w in range( self.nwvl ):
                
                # Legendre expansion
                f = np.polynomial.legendre.Legendre( self.phfcn[r,0,:,w].squeeze() )
                
                self.Pexp[:,r,w] = f( x )
        
    def add_scalar_pfunc( self, theta, P ):
        
        import numpy as np

        # Archive original
        self.P     = P
        self.theta = theta
        
        # Array to hold expansion
        self.Pexp = np.zeros( P.shape )
        
        # Legendre grid
        x = np.cos( theta )
        
        for r in range( self.nrh ):
            for w in range( self.nwvl ):
                
                # Compute the fit
                f = np.polynomial.legendre.Legendre.fit( x, P[:,r,w].squeeze(),deg=self.nmom-1 )
                
                # Compute the scaar phase function for validation
                self.Pexp[:,r,w] = f(x)
                
                # Archive expansion
                self.phfcn[r,0,:,w] = f.coef[:] / f.coef[0] # Force normalization
        
    def check_scalar_pfunc_exp( self,r=0,w=0 ):
        
        from matplotlib import pyplot as plt
        from matplotlib import gridspec
        import numpy as np

        fig = plt.figure()
        gs = gridspec.GridSpec(3, 3)
        ax1 = fig.add_subplot(gs[0,:])
        plt.ylabel('Residual')
        ax1.plot(np.rad2deg(self.theta),self.Pexp[:,r,w]-self.P[:,r,w],'b')
        ax2 = fig.add_subplot(gs[1:,:])
        ax2.plot(np.rad2deg(self.theta),self.P[:,r,w], 'b',label='Truth')
        ax2.plot(np.rad2deg(self.theta),self.Pexp[:,r,w], 'r',label='Expansion')
        plt.xlabel('Scattering Angle [deg]')
        plt.ylabel('Phase Function')
        plt.legend()
        gs.update(wspace=0.5, hspace=0.5)
        fig.show()
    
    def write_lut( self, outfile ):
        
        import numpy as np
        from netCDF4 import Dataset

        # Open file for write
        ncid = Dataset( outfile, 'w' )
        
        # Create dimensions
        ncid.createDimension( 'g'  , self.ngk  )
        ncid.createDimension( 'm'  , self.nmom )
        ncid.createDimension( 'r'  , self.nrh  )
        ncid.createDimension( 'w'  , self.nwvl )
        ncid.createDimension( 'one', 1         )
        
        # Write Data
        ncid.createVariable('nmom',np.int32,('one'))
        ncid.variables['nmom'][0] = self.nmom
        ncid.createVariable('nrh',np.int32,('one'))
        ncid.variables['nrh'][0] = self.nrh
        ncid.createVariable('nwls',np.int32,('one'))
        ncid.variables['nwls'][0] = self.nwvl
        ncid.createVariable('phfcn0',np.float64,('r','g','m','w'))
        ncid.variables['phfcn0'][:,:,:,:] = self.phfcn
        ncid.createVariable('qext0',np.float64,('r','w'))
        ncid.variables['qext0'][:,:] = self.qext
        ncid.createVariable('reff',np.float64,('r'))
        ncid.variables['reff'][:] = self.reff
        ncid.createVariable('ssa0',np.float64,('r','w'))
        ncid.variables['ssa0'][:,:] = self.ssa
        ncid.createVariable('wls0',np.float64,('w'))
        ncid.variables['wls0'][:] = self.wvl
        ncid.createVariable('rh',np.float64,('r'))
        ncid.variables['rh'][:] = self.rh
        
        # Close file
        ncid.close()
        
